// ─── Foodie Lover — Server-side Email Helper ────────────────────────────────
// SERVER ONLY — never import this in 'use client' files.
//
// Exports two public functions:
//   enqueueReceiptEmail(orderId) — queue an email for reliable delivery (use this at triggers)
//   sendReceiptEmail(orderId)    — attempt an immediate send (used by the queue worker)
// ────────────────────────────────────────────────────────────────────────────

import { getServerClient, newId, generateSpinToken } from '@/lib/supabase-server';
import { sendEmail } from '@/lib/email';
import { resolveRestaurantName } from '@/lib/config-server';

// ─── Email deduplication log ──────────────────────────────────────────────────
/**
 * logEmail — inserts into email_log with UNIQUE(order_id, event_type) constraint.
 * Also sets dedup_key = `${orderId}:${eventType}` for flexible deduplication.
 * Returns true if the email should be sent (no prior record), false if already sent.
 */
async function logEmail(orderId: string, eventType: string, sentTo: string): Promise<boolean> {
  const sb = getServerClient();
  const dedupKey = `${orderId}:${eventType}`;
  const { error } = await sb.from('email_log').insert({
    id: newId('EML'),
    order_id: orderId,
    event_type: eventType,
    sent_to: sentTo,
    dedup_key: dedupKey,
  });
  // 23505 = unique_violation — already sent, skip
  if (error && error.code === '23505') return false;
  return !error;
}

// ─── Types ────────────────────────────────────────────────────────────────────

export type EnqueueResult =
  | { queued: true }
  | { queued: false; reason: string };

export type SendReceiptResult =
  | { sent: true;  messageId: string }
  | { sent: false; reason: string    };

// ─── Retry delay schedule ─────────────────────────────────────────────────────
// retry_count 0 → try immediately
// retry_count 1 → wait 1 minute  after last failure
// retry_count 2 → wait 5 minutes after last failure
// retry_count >= 3 → permanently failed, no more retries

const RETRY_DELAY_MS = [0, 60_000, 5 * 60_000] as const; // ms per retry slot
const MAX_RETRIES    = 3;

// ─── Brand name + app base URL ────────────────────────────────────────────────
// Restaurant name is resolved per-send via resolveRestaurantName() (ENV
// RESTAURANT_NAME > Admin restaurant_settings.restaurant_name > 'Foodie Lover')
// so an Admin-panel name change reaches the next email sent — no module-level
// constant, no redeploy required. See lib/config-server.ts. Each build*Html()
// helper below takes a `restaurantName` parameter and aliases it to the local
// name `RESTAURANT_NAME` as its first line, so every existing template string
// below is unchanged.

// NEXT_PUBLIC_APP_URL must be set to your canonical production domain in Vercel.
// Example: https://www.ourfoodielover.com
// DO NOT set this to a Vercel preview URL (foodie-lover-next.vercel.app) or
// localhost — email links must always open the real production application.
const APP_BASE_URL = (process.env.NEXT_PUBLIC_APP_URL ?? '').replace(/\/$/, '');

// Warn loudly at startup if the base URL is missing or looks like a deployment preview.
// This prevents silently emailing customers links that open the wrong environment.
(function warnIfUrlMisconfigured() {
  if (!APP_BASE_URL) {
    console.error(
      '[email] ❌ NEXT_PUBLIC_APP_URL is not set — tracking links in customer emails ' +
      'will be broken (relative URLs do not work in email clients). ' +
      'Set it to your production URL in Vercel → Settings → Environment Variables.',
    );
  } else if (
    APP_BASE_URL.includes('.vercel.app') ||
    APP_BASE_URL.includes('localhost') ||
    APP_BASE_URL.includes('127.0.0.1')
  ) {
    console.warn(
      `[email] ⚠️  NEXT_PUBLIC_APP_URL is "${APP_BASE_URL}" — this looks like a ` +
      'local or Vercel preview URL, not a production domain. ' +
      'Customer email links will open the wrong environment. ' +
      'Update it to your real production URL in Vercel → Settings → Environment Variables.',
    );
  }
})();

/**
 * Builds an absolute tracking URL for a pickup/delivery order.
 *
 * The track page at /track reads:
 *   ?id=    → the order UUID
 *   ?token= → the tracking_token stored on the order row
 *
 * Both parameters are required — verifyTrackingToken() rejects requests
 * where the token is missing or mismatched.
 */
function trackingUrl(orderId: string, token: string): string {
  return `${APP_BASE_URL}/track?id=${encodeURIComponent(orderId)}&token=${encodeURIComponent(token)}`;
}

/** Renders a prominent CTA button suitable for order-tracking emails. */
function trackingButtonHtml(orderId: string, token: string, label: string, color = '#E65C00'): string {
  const url = trackingUrl(orderId, token);
  return `
  <div style="text-align:center;margin:24px 0">
    <a href="${url}" target="_blank" rel="noopener noreferrer"
       style="display:inline-block;background:${color};color:white;font-weight:800;font-size:15px;
              padding:14px 32px;border-radius:12px;text-decoration:none;
              letter-spacing:0.3px;box-shadow:0 4px 12px rgba(0,0,0,0.15)">
      ${label}
    </a>
    <div style="margin-top:8px;font-size:11px;color:#94a3b8">
      or copy: <a href="${url}" style="color:#7c3aed;font-family:monospace;font-size:11px;word-break:break-all">${url}</a>
    </div>
  </div>`;
}

// ─── Build HTML receipt ───────────────────────────────────────────────────────

function buildReceiptHtml(order: Record<string, unknown>, items: Record<string, unknown>[], restaurantName: string): string {
  const RESTAURANT_NAME = restaurantName;
  const orderId   = (order.id as string) || '';
  const orderNum  = (order.order_number as number) ?? String(orderId).slice(-6);
  const custName  = (order.customer_name  as string) || 'Valued Customer';
  const custEmail = (order.customer_email as string) || '';
  const payment   = ((order.payment_method as string) || 'COD').toUpperCase();
  const subtotal  = Number(order.subtotal)  || 0;
  const tax       = Number(order.tax)       || 0;
  const discount  = Number(order.discount)  || 0;
  const tip       = Number(order.tip)       || 0;
  const total     = Number(order.total)     || 0;
  const discReason= (order.discount_reason as string) || '';
  const createdAt = order.created_at
    ? new Date(order.created_at as string).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'short' })
    : '';
  const orderType = (order.type as string) || 'dine-in';

  const itemRows = items.map(it => `
    <tr>
      <td style="padding:8px 0;border-bottom:1px solid #f0f0f0;font-size:14px;color:#334155">
        ${String(it.name)} <span style="color:#94a3b8">× ${Number(it.qty) || 1}</span>
      </td>
      <td style="padding:8px 0;border-bottom:1px solid #f0f0f0;text-align:right;font-size:14px;color:#334155">
        ₹${(Number(it.subtotal) || 0).toFixed(2)}
      </td>
    </tr>`).join('');

  const typeLabel =
    orderType === 'delivery' ? '🚗 Delivery' :
    orderType === 'pickup'   ? '🏪 Pickup'   :
    '🍽️ Dine-In';

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Your ${RESTAURANT_NAME} Receipt</title>
</head>
<body style="font-family:'Segoe UI',Arial,sans-serif;background:#f1f5f9;margin:0;padding:24px 16px">
  <div style="max-width:540px;margin:0 auto">

    <!-- Header -->
    <div style="background:linear-gradient(135deg,#E65C00,#F9D423);border-radius:16px 16px 0 0;padding:32px;text-align:center">
      <div style="font-size:36px;margin-bottom:8px">🍽️</div>
      <h1 style="margin:0;font-size:26px;font-weight:900;color:white;letter-spacing:-0.5px;text-shadow:0 1px 3px rgba(0,0,0,0.2)">
        ${RESTAURANT_NAME}
      </h1>
      <p style="margin:6px 0 0;font-size:13px;color:rgba(255,255,255,0.9)">Payment Receipt</p>
    </div>

    <!-- Card -->
    <div style="background:white;border-radius:0 0 16px 16px;padding:32px;box-shadow:0 4px 24px rgba(0,0,0,0.08)">

      <!-- Order info box -->
      <div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:10px;padding:16px 20px;margin-bottom:24px">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px">
          <div>
            <div style="font-size:11px;color:#9a3412;font-weight:700;text-transform:uppercase;letter-spacing:1px">
              Order #${orderNum}
            </div>
            <div style="font-size:16px;font-weight:700;color:#1e293b;margin-top:4px">${custName}</div>
            ${custEmail ? `<div style="font-size:12px;color:#64748b;margin-top:2px">${custEmail}</div>` : ''}
            ${orderId ? `<div style="font-size:11px;color:#94a3b8;margin-top:4px;font-family:monospace">ID: ${orderId}</div>` : ''}
          </div>
          <div style="text-align:right">
            <div style="font-size:11px;font-weight:600;background:#E65C00;color:white;padding:3px 10px;border-radius:20px;white-space:nowrap">
              ${typeLabel}
            </div>
            <div style="font-size:11px;color:#64748b;margin-top:6px">${createdAt}</div>
          </div>
        </div>
      </div>

      <!-- Items -->
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#94a3b8;margin-bottom:8px">
        Order Items
      </div>
      <table style="width:100%;border-collapse:collapse;margin-bottom:20px">
        <tbody>${itemRows}</tbody>
      </table>

      <!-- Totals -->
      <div style="border-top:2px solid #f1f5f9;padding-top:16px">
        <table style="width:100%;border-collapse:collapse">
          <tr>
            <td style="padding:4px 0;color:#64748b;font-size:14px">Subtotal</td>
            <td style="padding:4px 0;text-align:right;font-size:14px;color:#334155">₹${subtotal.toFixed(2)}</td>
          </tr>
          ${tax > 0 ? `<tr>
            <td style="padding:4px 0;color:#64748b;font-size:14px">Tax</td>
            <td style="padding:4px 0;text-align:right;font-size:14px;color:#334155">₹${tax.toFixed(2)}</td>
          </tr>` : ''}
          ${discount > 0 ? `<tr>
            <td style="padding:4px 0;color:#16a34a;font-size:14px">
              Discount${discReason ? ` (${discReason})` : ''}
            </td>
            <td style="padding:4px 0;text-align:right;color:#16a34a;font-size:14px">−₹${discount.toFixed(2)}</td>
          </tr>` : ''}
          ${tip > 0 ? `<tr>
            <td style="padding:4px 0;color:#64748b;font-size:14px">Tip</td>
            <td style="padding:4px 0;text-align:right;font-size:14px;color:#334155">₹${tip.toFixed(2)}</td>
          </tr>` : ''}
          <tr>
            <td style="padding:14px 0 0;font-weight:800;font-size:18px;color:#E65C00">Total</td>
            <td style="padding:14px 0 0;text-align:right;font-weight:900;font-size:20px;color:#E65C00">
              ₹${total.toFixed(2)}
            </td>
          </tr>
        </table>
      </div>

      <!-- Payment badge -->
      <div style="margin-top:20px;padding:12px 16px;background:#f8fafc;border-radius:8px;font-size:13px;color:#475569">
        <span style="font-size:16px">💳</span>
        Paid via <strong style="color:#1e293b">${payment}</strong>
        <span style="margin-left:8px;color:#16a34a;font-weight:700;font-size:12px">✓ PAID</span>
      </div>

      <!-- CTA -->
      <div style="margin-top:24px;text-align:center;padding:16px;background:#fff7ed;border-radius:10px">
        <p style="margin:0 0 6px;font-size:13px;color:#9a3412">
          💬 Questions about your order? Contact us and quote:
        </p>
        <p style="margin:0;font-size:12px;color:#7c3aed;font-family:monospace;font-weight:700">
          ${orderId || `Order #${orderNum}`}
        </p>
      </div>
    </div>

    <!-- Footer -->
    <div style="text-align:center;padding:20px;font-size:12px;color:#94a3b8">
      Thank you for choosing <strong style="color:#E65C00">${RESTAURANT_NAME}</strong>! 🙏<br/>
      <span style="font-size:11px">This is an automated receipt — please do not reply to this email.</span>
    </div>
  </div>
</body>
</html>`;
}

// ─── Internal: dispatch via Resend (delegates to lib/email.ts) ───────────────
// Preserves the same return type used by sendReceiptEmail / sendTabReceiptEmail.
// Adds the domain-restriction prefix so callers can show actionable UI messages.

async function dispatchViaResend(
  email:    string,
  subject:  string,
  html:     string,
): Promise<{ messageId: string } | { error: string }> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey || apiKey.startsWith('re_placeholder')) {
    console.error('[dispatchViaResend] ❌ RESEND_API_KEY is missing or placeholder — set it in Vercel Environment Variables');
    return { error: 'RESEND_API_KEY not configured' };
  }

  console.info(`[dispatchViaResend] → Sending | to: ${email} | subject: "${subject}" | html: ${html.length} chars`);

  const result = await sendEmail({ to: email, subject, html });

  if ('error' in result) {
    // Detect the Resend free-tier domain restriction and surface an actionable message.
    const errMsg = result.error;
    console.error(`[dispatchViaResend] ❌ Resend error | to: ${email} | error: ${errMsg}`);
    if (errMsg.includes('verify a domain') || errMsg.includes('testing emails')) {
      return { error: `RESEND_DOMAIN_REQUIRED: ${errMsg}` };
    }
    return { error: errMsg };
  }

  console.info(`[dispatchViaResend] ✅ Delivered | to: ${email} | messageId: ${result.messageId}`);
  return { messageId: result.messageId };
}

// ─── Build tab-level receipt HTML (orders shown per round with IDs) ───────────

function buildTabReceiptHtml(
  tab:    Record<string, unknown>,
  orders: { order: Record<string, unknown>; items: Record<string, unknown>[] }[],
  emailOverride: string | undefined,
  restaurantName: string,
): string {
  const RESTAURANT_NAME = restaurantName;
  const custName   = (tab.customer_name  as string) || 'Valued Customer';
  const custEmail  = emailOverride || (tab.customer_email as string) || '';
  const payment    = ((tab.payment_method as string) || 'Cash').toUpperCase();
  const tabTotal   = Number(tab.total)    || 0;
  const discount   = Number(tab.discount) || 0;
  const discReason = (tab.discount_reason as string) || '';
  // tab.total is the final amount (post-discount); add discount back to derive subtotal for display
  const subtotal   = tabTotal + discount;
  const tableId    = (tab.table_id as string) || '';
  const tableName  = (tab.table_name as string) || tableId || '';
  const createdAt  = tab.created_at
    ? new Date(tab.created_at as string).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'short' })
    : '';

  // Determine the order type from the first order (all orders in a tab share the same type)
  const firstOrderType = (orders[0]?.order.type as string) || 'dine-in';
  const typeLabel =
    firstOrderType === 'delivery' ? '🚗 Delivery' :
    firstOrderType === 'pickup'   ? '🏪 Pickup'   :
    '🍽️ Dine-In';

  // Collect all order IDs for the reference section
  const orderIds = orders.map(o => (o.order.id as string) || '').filter(Boolean);

  // Build per-order sections (each round gets its own heading + item list)
  const orderSections = orders.map((o, idx) => {
    const orderId  = (o.order.id as string) || '';
    const orderNum = (o.order.order_number as number) ?? String(orderId).slice(-6);
    const orderTime = o.order.created_at
      ? new Date(o.order.created_at as string).toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hour12: true })
      : '';

    const itemRows = o.items.map(it => `
      <tr>
        <td style="padding:7px 0;border-bottom:1px solid #f8f8f8;font-size:13px;color:#334155">
          ${String(it.name)} <span style="color:#94a3b8">× ${Number(it.qty) || 1}</span>
        </td>
        <td style="padding:7px 0;border-bottom:1px solid #f8f8f8;text-align:right;font-size:13px;color:#334155">
          ₹${(Number(it.subtotal) || 0).toFixed(2)}
        </td>
      </tr>`).join('');

    return `
    <!-- Order round ${idx + 1} -->
    <div style="margin-bottom:16px">
      <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 12px;background:#f8fafc;border-radius:8px;margin-bottom:4px">
        <div>
          <span style="font-size:11px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:0.5px">
            Round ${idx + 1}${orders.length > 1 ? ` — Order #${orderNum}` : ` — Order #${orderNum}`}
          </span>
          <span style="display:block;font-size:10px;color:#94a3b8;font-family:monospace;margin-top:1px">${orderId}</span>
        </div>
        ${orderTime ? `<span style="font-size:11px;color:#94a3b8">${orderTime}</span>` : ''}
      </div>
      <table style="width:100%;border-collapse:collapse">
        <tbody>${itemRows}</tbody>
      </table>
    </div>`;
  }).join('');

  // Reference IDs block shown in the footer CTA
  const refIdLines = orderIds.map(id => `<div style="font-family:monospace;font-size:11px;color:#7c3aed;font-weight:700">${id}</div>`).join('');

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Your ${RESTAURANT_NAME} Receipt</title>
</head>
<body style="font-family:'Segoe UI',Arial,sans-serif;background:#f1f5f9;margin:0;padding:24px 16px">
  <div style="max-width:540px;margin:0 auto">

    <!-- Header -->
    <div style="background:linear-gradient(135deg,#E65C00,#F9D423);border-radius:16px 16px 0 0;padding:32px;text-align:center">
      <div style="font-size:36px;margin-bottom:8px">🍽️</div>
      <h1 style="margin:0;font-size:26px;font-weight:900;color:white;letter-spacing:-0.5px;text-shadow:0 1px 3px rgba(0,0,0,0.2)">${RESTAURANT_NAME}</h1>
      <p style="margin:6px 0 0;font-size:13px;color:rgba(255,255,255,0.9)">Payment Receipt</p>
    </div>

    <!-- Card -->
    <div style="background:white;border-radius:0 0 16px 16px;padding:32px;box-shadow:0 4px 24px rgba(0,0,0,0.08)">

      <!-- Session info box -->
      <div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:10px;padding:16px 20px;margin-bottom:24px">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px">
          <div>
            <div style="font-size:11px;color:#9a3412;font-weight:700;text-transform:uppercase;letter-spacing:1px">${typeLabel}${tableName ? ` — ${tableName}` : ''}</div>
            <div style="font-size:16px;font-weight:700;color:#1e293b;margin-top:4px">${custName}</div>
            ${custEmail ? `<div style="font-size:12px;color:#64748b;margin-top:2px">${custEmail}</div>` : ''}
          </div>
          <div style="text-align:right">
            <div style="font-size:11px;color:#64748b">${createdAt}</div>
            <div style="font-size:11px;color:#94a3b8;margin-top:4px">${orders.length} order${orders.length !== 1 ? 's' : ''}</div>
          </div>
        </div>
      </div>

      <!-- Per-order item sections -->
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#94a3b8;margin-bottom:12px">
        Order Details
      </div>
      ${orderSections}

      <!-- Totals -->
      <div style="border-top:2px solid #f1f5f9;padding-top:16px;margin-top:8px">
        <table style="width:100%;border-collapse:collapse">
          <tr>
            <td style="padding:4px 0;color:#64748b;font-size:14px">Subtotal</td>
            <td style="padding:4px 0;text-align:right;font-size:14px;color:#334155">₹${subtotal.toFixed(2)}</td>
          </tr>
          ${discount > 0 ? `<tr>
            <td style="padding:4px 0;color:#16a34a;font-size:14px">Discount${discReason ? ` (${discReason})` : ''}</td>
            <td style="padding:4px 0;text-align:right;color:#16a34a;font-size:14px">−₹${discount.toFixed(2)}</td>
          </tr>` : ''}
          <tr>
            <td style="padding:14px 0 0;font-weight:800;font-size:18px;color:#E65C00">Total</td>
            <td style="padding:14px 0 0;text-align:right;font-weight:900;font-size:20px;color:#E65C00">₹${tabTotal.toFixed(2)}</td>
          </tr>
        </table>
      </div>

      <!-- Payment badge -->
      <div style="margin-top:20px;padding:12px 16px;background:#f8fafc;border-radius:8px;font-size:13px;color:#475569">
        <span style="font-size:16px">💳</span>
        Paid via <strong style="color:#1e293b">${payment}</strong>
        <span style="margin-left:8px;color:#16a34a;font-weight:700;font-size:12px">✓ PAID</span>
      </div>

      <!-- Reference IDs (for tracking / support) -->
      <div style="margin-top:24px;padding:16px;background:#fff7ed;border-radius:10px">
        <p style="margin:0 0 8px;font-size:13px;color:#9a3412;text-align:center">
          💬 Questions? Contact us and quote your order reference${orderIds.length > 1 ? 's' : ''}:
        </p>
        <div style="text-align:center">
          ${refIdLines}
        </div>
      </div>
    </div>

    <!-- Footer -->
    <div style="text-align:center;padding:20px;font-size:12px;color:#94a3b8">
      Thank you for choosing <strong style="color:#E65C00">${RESTAURANT_NAME}</strong>! 🙏<br/>
      <span style="font-size:11px">This is an automated receipt — please do not reply to this email.</span>
    </div>
  </div>
</body>
</html>`;
}

// ─── Public: enqueueReceiptEmail ──────────────────────────────────────────────
/**
 * enqueueReceiptEmail(orderId)
 *
 * Inserts a job into email_queue with status='pending'.
 * Idempotent — safe to call multiple times for the same order:
 *   • skips if a non-failed queue entry already exists
 *   • skips if ReceiptEmailSent is already in order_events
 *
 * The background worker at /api/email/process-queue picks it up within 1 min.
 * On failure the worker retries up to 3 times with exponential backoff.
 */
export async function enqueueReceiptEmail(orderId: string): Promise<EnqueueResult> {
  const TAG = `[email/enqueue orderId=${orderId}]`;
  const sb  = getServerClient();

  try {
    // 1. Fetch order to validate email exists
    const { data: order, error: fetchErr } = await sb
      .from('orders')
      .select('customer_email')
      .eq('id', orderId)
      .single();

    if (fetchErr || !order) {
      console.warn(`${TAG} Order not found — cannot enqueue`);
      return { queued: false, reason: 'Order not found' };
    }

    const email = order.customer_email as string | null;
    if (!email) {
      console.info(`${TAG} No customer_email — skipping enqueue`);
      return { queued: false, reason: 'No customer email' };
    }

    // 2. Idempotency: skip if already sent or queued (not permanently failed)
    const { data: existing } = await sb
      .from('email_queue')
      .select('id, status, retry_count')
      .eq('order_id', orderId)
      .in('status', ['pending', 'sent'])
      .maybeSingle();

    if (existing) {
      console.info(`${TAG} Already queued/sent (status=${existing.status}) — skipping`);
      return { queued: false, reason: `Already ${existing.status}` };
    }

    // 3. Idempotency: skip if ReceiptEmailSent already recorded in order_events
    const { data: events } = await sb
      .from('order_events')
      .select('id')
      .eq('order_id', orderId)
      .eq('event_type', 'ReceiptEmailSent')
      .limit(1);

    if (events && events.length > 0) {
      console.info(`${TAG} ReceiptEmailSent event exists — skipping enqueue`);
      return { queued: false, reason: 'Already sent (order_events)' };
    }

    // 4. Insert queue entry — worker will send within the next cron cycle
    await sb.from('email_queue').insert({
      id:           newId('EQ'),
      order_id:     orderId,
      email,
      status:       'pending',
      retry_count:  0,
      next_retry_at: new Date().toISOString(),   // eligible immediately
    });

    console.info(`${TAG} ✅ Queued receipt for ${email}`);
    return { queued: true };

  } catch (err) {
    console.error(`${TAG} Failed to enqueue:`, err);
    return { queued: false, reason: String(err) };
  }
}

// ─── Public: sendReceiptEmail ─────────────────────────────────────────────────
/**
 * sendReceiptEmail(orderId)
 *
 * Immediately attempts to send a receipt for this order via Resend.
 * Used by: queue worker, manual /api/email/receipt trigger.
 *
 * Idempotent via order_events — will return { sent: false, reason: 'Already sent' }
 * if ReceiptEmailSent is already recorded. This is intentional — the worker will
 * update the queue record to 'sent' without re-sending.
 */
export async function sendReceiptEmail(
  orderId:       string,
  /** Optional email override. Used when the order has no customer_email stored
   *  (e.g. dine-in tabs). If omitted, falls back to order.customer_email. */
  emailOverride?: string,
): Promise<SendReceiptResult> {
  const TAG = `[email/send orderId=${orderId}]`;
  const sb  = getServerClient();

  try {
    // 1. Fetch order + items + events in one query
    const { data: raw, error: fetchErr } = await sb
      .from('orders')
      .select('*, order_items(*), order_events(*)')
      .eq('id', orderId)
      .single();

    if (fetchErr || !raw) {
      console.error(`${TAG} Order not found:`, fetchErr);
      return { sent: false, reason: 'Order not found' };
    }

    // 2. Resolve recipient email: prefer explicit override, fall back to order record
    const email = (emailOverride?.trim() || (raw.customer_email as string | null)) ?? null;
    if (!email) {
      console.info(`${TAG} No customer_email and no override — skipping`);
      return { sent: false, reason: 'No customer email' };
    }

    // 3. Duplicate prevention: check order_events for ReceiptEmailSent
    const events: Record<string, unknown>[] = (raw.order_events as Record<string, unknown>[]) ?? [];
    const alreadySent = events.some(ev => ev.event_type === 'ReceiptEmailSent');
    if (alreadySent) {
      console.info(`${TAG} Receipt already sent to ${email} — skipping duplicate`);
      return { sent: false, reason: 'Already sent' };
    }

    // 4. Build email
    const items: Record<string, unknown>[] = (raw.order_items as Record<string, unknown>[]) ?? [];
    const RESTAURANT_NAME = (await resolveRestaurantName()).value;
    const html     = buildReceiptHtml(raw as Record<string, unknown>, items, RESTAURANT_NAME);
    const orderNum = (raw.order_number as number) ?? String(raw.id).slice(-6);
    const subject  = `Your ${RESTAURANT_NAME} Receipt — Order #${orderNum}`;

    console.info(`${TAG} Dispatching receipt to ${email}`);

    // 5. Send via Resend
    const result = await dispatchViaResend(email, subject, html);

    if ('error' in result) {
      console.error(`${TAG} Resend error: ${result.error}`);
      return { sent: false, reason: result.error };
    }

    console.info(`${TAG} ✅ Sent to ${email} — messageId: ${result.messageId}`);

    // 6. Record ReceiptEmailSent event (also prevents future duplicates)
    await sb.from('order_events').insert({
      id:           newId('EV'),
      order_id:     orderId,
      event_type:   'ReceiptEmailSent',
      performed_by: 'System',
      note:         `Receipt emailed to ${email} (messageId: ${result.messageId})`,
    });

    return { sent: true, messageId: result.messageId };

  } catch (err) {
    console.error(`${TAG} Unexpected error:`, err);
    return { sent: false, reason: String(err) };
  }
}

// ─── Public: sendTabReceiptEmail ──────────────────────────────────────────────
/**
 * sendTabReceiptEmail(tabId, emailOverride?)
 *
 * Sends a single combined receipt for ALL non-cancelled orders on a tab.
 * Designed for dine-in tabs where the manager triggers the send after close.
 *
 * - Fetches tab row + all orders + all items directly from DB (no client-state needed).
 * - Builds a merged receipt showing every item ordered across all rounds.
 * - Records a ReceiptEmailSent event on every order for idempotency.
 * - Returns { sent: true, messageId } on success or { sent: false, reason } on failure.
 */
export async function sendTabReceiptEmail(
  tabId:          string,
  emailOverride?: string,
): Promise<SendReceiptResult> {
  const TAG = `[email/sendTab tabId=${tabId}]`;
  const sb  = getServerClient();

  try {
    // 1. Fetch tab row
    const { data: tab, error: tabErr } = await sb
      .from('customer_tabs')
      .select('*')
      .eq('id', tabId)
      .single();

    if (tabErr || !tab) {
      console.error(`${TAG} Tab not found:`, tabErr?.message);
      return { sent: false, reason: 'Tab not found' };
    }

    // 2. Resolve recipient email
    const email = (emailOverride?.trim() || (tab.customer_email as string | null)) ?? null;
    if (!email) {
      console.info(`${TAG} No email — skipping`);
      return { sent: false, reason: 'No customer email' };
    }

    // 3. Fetch all non-cancelled/void orders for this tab (no need for order_events)
    const { data: rawOrders, error: ordersErr } = await sb
      .from('orders')
      .select('*, order_items(*)')
      .eq('tab_id', tabId)
      .not('status', 'in', '("cancelled","void")')
      .order('created_at', { ascending: true });

    if (ordersErr) {
      console.error(`${TAG} Orders fetch error:`, ordersErr.message);
      return { sent: false, reason: ordersErr.message };
    }

    if (!rawOrders || rawOrders.length === 0) {
      console.warn(`${TAG} No orders found for tab`);
      return { sent: false, reason: 'No orders found on this tab' };
    }

    // Note: no idempotency block here — the manager can intentionally re-send
    // (e.g. customer says they didn't receive it). Each send is still recorded
    // in order_events for the audit trail.

    // 4. Build combined receipt
    const ordersForHtml = rawOrders.map(o => ({
      order: o as Record<string, unknown>,
      items: (o.order_items as Record<string, unknown>[]) ?? [],
    }));
    const RESTAURANT_NAME = (await resolveRestaurantName()).value;
    const html       = buildTabReceiptHtml(tab as Record<string, unknown>, ordersForHtml, emailOverride, RESTAURANT_NAME);
    // Use table name if present, else humanise the raw table_id (tbl_01 → Table 1)
    const rawTableId = (tab.table_id as string) || '';
    const tablePart  =
      (tab.table_name as string) ||
      (rawTableId ? rawTableId.replace(/^tbl[_-]?0*(\d+)$/i, 'Table $1').replace(/^T0*(\d+)$/, 'Table $1') : '');
    const namePart   = (tab.customer_name as string) || 'Dine-In';
    const subject    = tablePart
      ? `Your ${RESTAURANT_NAME} Receipt — ${namePart} (${tablePart})`
      : `Your ${RESTAURANT_NAME} Receipt — ${namePart}`;

    const totalItems = rawOrders.reduce((s, o) => s + ((o.order_items as unknown[]) ?? []).length, 0);
    console.info(`${TAG} Dispatching tab receipt → recipient: ${email} | subject: "${subject}" | orders: ${rawOrders.length} | items: ${totalItems}`);

    // 5. Send via Resend
    const result = await dispatchViaResend(email, subject, html);
    if ('error' in result) {
      console.error(`${TAG} Resend error: ${result.error}`);
      return { sent: false, reason: result.error };
    }

    console.info(`${TAG} ✅ Sent to ${email} — messageId: ${result.messageId}`);

    // 6. Record ReceiptEmailSent event on each order (audit trail)
    const eventRows = rawOrders.map(o => ({
      id:           newId('EV'),
      order_id:     o.id as string,
      event_type:   'ReceiptEmailSent',
      performed_by: 'System',
      note:         `Tab receipt emailed to ${email} (messageId: ${result.messageId})`,
    }));
    await sb.from('order_events').insert(eventRows);

    return { sent: true, messageId: result.messageId };

  } catch (err) {
    console.error(`${TAG} Unexpected error:`, err);
    return { sent: false, reason: String(err) };
  }
}

// ─── Public: processEmailQueue ────────────────────────────────────────────────
/**
 * processEmailQueue()
 *
 * Called by the cron worker (/api/email/process-queue).
 * Fetches all queue entries that are ready to send (based on next_retry_at),
 * attempts each, and updates the record with the result.
 *
 * Retry schedule (exponential backoff):
 *   Attempt 1 (retry_count=0): immediate
 *   Attempt 2 (retry_count=1): 1 minute after last failure
 *   Attempt 3 (retry_count=2): 5 minutes after last failure
 *   After 3 failures: status='failed' permanently
 *
 * Returns a summary of what was processed.
 */
export async function processEmailQueue(): Promise<{
  processed: number;
  sent:      number;
  failed:    number;
  skipped:   number;
  details:   { orderId: string; email: string; result: string }[];
}> {
  const TAG = '[email/queue/worker]';
  const sb  = getServerClient();

  const summary = { processed: 0, sent: 0, failed: 0, skipped: 0, details: [] as { orderId: string; email: string; result: string }[] };

  try {
    // Fetch jobs that are ready: (pending or failed) AND retries remaining AND due now
    const now = new Date().toISOString();
    const { data: jobs, error: fetchErr } = await sb
      .from('email_queue')
      .select('*')
      .in('status', ['pending', 'failed'])
      .lt('retry_count', MAX_RETRIES)
      .lte('next_retry_at', now)
      .order('created_at', { ascending: true })
      .limit(50);  // process max 50 per run to avoid timeouts

    if (fetchErr) {
      console.error(`${TAG} Failed to fetch queue:`, fetchErr);
      return summary;
    }

    if (!jobs || jobs.length === 0) {
      console.info(`${TAG} Queue empty — nothing to process`);
      return summary;
    }

    console.info(`${TAG} Processing ${jobs.length} job(s)`);

    for (const job of jobs) {
      summary.processed++;
      const jobId   = job.id as string;
      const orderId = job.order_id as string;
      const email   = job.email as string;
      const retryN  = Number(job.retry_count);

      console.info(`${TAG} [${jobId}] attempt ${retryN + 1}/${MAX_RETRIES} → order ${orderId} → ${email}`);

      const result = await sendReceiptEmail(orderId);

      if (result.sent || result.reason === 'Already sent') {
        // Success (or another worker beat us — either way, mark sent)
        await sb.from('email_queue').update({
          status:          'sent',
          last_attempt_at: new Date().toISOString(),
          message_id:      result.sent ? result.messageId : 'dedup',
          error:           null,
        }).eq('id', jobId);

        summary.sent++;
        summary.details.push({ orderId, email, result: 'sent' });
        console.info(`${TAG} [${jobId}] ✅ sent`);

      } else {
        // Failure — increment retries and schedule next attempt
        const newRetryCount = retryN + 1;
        const isPermanentFail = newRetryCount >= MAX_RETRIES;
        const delayMs = RETRY_DELAY_MS[newRetryCount] ?? 0;
        const nextRetry = new Date(Date.now() + delayMs).toISOString();

        await sb.from('email_queue').update({
          // Keep 'pending' so the worker retries; only 'failed' after MAX_RETRIES
          status:          isPermanentFail ? 'failed' : 'pending',
          retry_count:     newRetryCount,
          last_attempt_at: new Date().toISOString(),
          next_retry_at:   isPermanentFail ? null : nextRetry,
          error:           result.reason,
        }).eq('id', jobId);

        if (isPermanentFail) {
          summary.failed++;
          summary.details.push({ orderId, email, result: `permanently_failed: ${result.reason}` });
          console.error(`${TAG} [${jobId}] ❌ permanently failed after ${MAX_RETRIES} attempts: ${result.reason}`);
        } else {
          summary.skipped++;
          summary.details.push({ orderId, email, result: `retry_${newRetryCount}: ${result.reason}` });
          console.warn(`${TAG} [${jobId}] ⚠️ attempt ${newRetryCount} failed, next retry at ${nextRetry}: ${result.reason}`);
        }
      }
    }

  } catch (err) {
    console.error(`${TAG} Worker error:`, err);
  }

  console.info(`${TAG} Done — processed:${summary.processed} sent:${summary.sent} failed:${summary.failed} retrying:${summary.skipped}`);
  return summary;
}
// ─── Transactional notification emails ───────────────────────────────────────
// Sent at key lifecycle points: order created, order ready (prepared), delivery.
// These are lightweight in comparison to the full receipt HTML — they confirm
// an event has happened and give the customer a reference number.

// ─── HTML builders ─────────────────────────────────────────────────────────

function buildConfirmationHtml(order: Record<string, unknown>, items: Record<string, unknown>[], restaurantName: string): string {
  const RESTAURANT_NAME = restaurantName;
  const orderId       = (order.id as string) || '';
  const orderNum      = (order.order_number as number) ?? String(orderId).slice(-6);
  const custName      = (order.customer_name as string) || 'Valued Customer';
  const total         = Number(order.total) || 0;
  const typeRaw       = (order.type as string) || 'dine-in';
  const trackingToken = (order.tracking_token as string) || '';
  const isPickup      = typeRaw === 'pickup';
  const isDelivery    = typeRaw === 'delivery';
  const typeLabel =
    isDelivery ? '🚗 Delivery' :
    isPickup   ? '🏪 Pickup'  : '🍽️ Dine-In';
  const deliveryAddr = (order.delivery_address as string) || '';

  // Tracking link — only for pickup and delivery orders that have a tracking token.
  // Dine-in customers track via the table page, not /track.
  const trackBtn = (isPickup || isDelivery) && trackingToken
    ? trackingButtonHtml(orderId, trackingToken, isDelivery ? '📍 Track Your Order' : '📋 View Order Status')
    : '';

  const itemRows = items.map(it => `
    <tr>
      <td style="padding:7px 0;border-bottom:1px solid #f0f0f0;font-size:13px;color:#334155">
        ${String(it.name)} <span style="color:#94a3b8">× ${Number(it.qty) || 1}</span>
      </td>
      <td style="padding:7px 0;border-bottom:1px solid #f0f0f0;text-align:right;font-size:13px;color:#334155">
        ₹${(Number(it.subtotal) || 0).toFixed(2)}
      </td>
    </tr>`).join('');

  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="font-family:'Segoe UI',Arial,sans-serif;background:#f1f5f9;margin:0;padding:24px 16px">
  <div style="max-width:520px;margin:0 auto">
    <div style="background:linear-gradient(135deg,#E65C00,#F9D423);border-radius:16px 16px 0 0;padding:28px;text-align:center">
      <div style="font-size:32px;margin-bottom:6px">✅</div>
      <h1 style="margin:0;font-size:22px;font-weight:900;color:white">Order Confirmed!</h1>
      <p style="margin:6px 0 0;font-size:13px;color:rgba(255,255,255,0.9)">${RESTAURANT_NAME}</p>
    </div>
    <div style="background:white;border-radius:0 0 16px 16px;padding:28px;box-shadow:0 4px 24px rgba(0,0,0,0.08)">
      <p style="font-size:15px;color:#334155;margin:0 0 20px">Hi <strong>${custName}</strong>, we've received your order!</p>
      <div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:10px;padding:14px 18px;margin-bottom:20px">
        <div style="font-size:11px;font-weight:700;color:#9a3412;text-transform:uppercase;letter-spacing:1px">${typeLabel} — Order #${orderNum}</div>
        <div style="font-family:monospace;font-size:11px;color:#94a3b8;margin-top:4px">${orderId}</div>
        ${deliveryAddr ? `<div style="font-size:12px;color:#475569;margin-top:6px">📍 ${deliveryAddr}</div>` : ''}
      </div>
      <table style="width:100%;border-collapse:collapse;margin-bottom:18px">
        <tbody>${itemRows}</tbody>
      </table>
      <div style="border-top:2px solid #f1f5f9;padding-top:14px;text-align:right">
        <span style="font-size:18px;font-weight:900;color:#E65C00">Total: ₹${total.toFixed(2)}</span>
      </div>
      ${trackBtn}
      <p style="margin:${trackBtn ? '4px' : '20px'} 0 0;font-size:12px;color:#94a3b8;text-align:center">
        Keep this email for reference &nbsp;·&nbsp;
        <span style="font-family:monospace;color:#7c3aed">${orderId}</span>
      </p>
    </div>
    <div style="text-align:center;padding:16px;font-size:11px;color:#94a3b8">
      Thank you for choosing <strong style="color:#E65C00">${RESTAURANT_NAME}</strong>! 🙏
    </div>
  </div>
</body>
</html>`;
}

function buildOrderReadyHtml(order: Record<string, unknown>, restaurantName: string): string {
  const RESTAURANT_NAME = restaurantName;
  const orderId       = (order.id as string) || '';
  const orderNum      = (order.order_number as number) ?? String(orderId).slice(-6);
  const custName      = (order.customer_name as string) || 'Valued Customer';
  const trackingToken = (order.tracking_token as string) || '';
  const typeRaw       = (order.type as string) || 'pickup';
  const isDelivery    = typeRaw === 'delivery';
  const icon          = isDelivery ? '🛵' : '🏪';
  const headline      = isDelivery ? 'Your order is on its way!' : 'Your order is ready for pickup!';
  const message       = isDelivery
    ? 'Our delivery team will bring your order to you shortly.'
    : 'Please come to the counter to collect your order.';

  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="font-family:'Segoe UI',Arial,sans-serif;background:#f1f5f9;margin:0;padding:24px 16px">
  <div style="max-width:520px;margin:0 auto">
    <div style="background:linear-gradient(135deg,#16a34a,#22c55e);border-radius:16px 16px 0 0;padding:28px;text-align:center">
      <div style="font-size:40px;margin-bottom:6px">${icon}</div>
      <h1 style="margin:0;font-size:22px;font-weight:900;color:white">${headline}</h1>
      <p style="margin:6px 0 0;font-size:13px;color:rgba(255,255,255,0.9)">${RESTAURANT_NAME}</p>
    </div>
    <div style="background:white;border-radius:0 0 16px 16px;padding:28px;box-shadow:0 4px 24px rgba(0,0,0,0.08)">
      <p style="font-size:15px;color:#334155;margin:0 0 20px">Hi <strong>${custName}</strong>,</p>
      <p style="font-size:14px;color:#475569;margin:0 0 24px">${message}</p>
      <div style="background:#f0fdf4;border:1px solid #86efac;border-radius:10px;padding:14px 18px;text-align:center">
        <div style="font-size:11px;font-weight:700;color:#16a34a;text-transform:uppercase;letter-spacing:1px">Order #${orderNum}</div>
        <div style="font-family:monospace;font-size:11px;color:#94a3b8;margin-top:4px">${orderId}</div>
      </div>
      ${trackingToken ? trackingButtonHtml(orderId, trackingToken, isDelivery ? '🛵 Track Delivery' : '📦 View Order Status', isDelivery ? '#2563eb' : '#16a34a') : ''}
    </div>
    <div style="text-align:center;padding:16px;font-size:11px;color:#94a3b8">
      Thank you for choosing <strong style="color:#E65C00">${RESTAURANT_NAME}</strong>! 🙏
    </div>
  </div>
</body>
</html>`;
}

// ─── Public: sendOrderConfirmationEmail ──────────────────────────────────────
/**
 * sendOrderConfirmationEmail(orderId)
 *
 * Sent immediately after order creation to acknowledge the customer's order.
 * Only fires if the order has a customer_email.
 * Fire-and-forget from POST /api/orders — never blocks the API response.
 */
export async function sendOrderConfirmationEmail(orderId: string): Promise<void> {
  const TAG = `[email/confirmation orderId=${orderId}]`;
  const sb  = getServerClient();

  try {
    const { data: raw, error: fetchErr } = await sb
      .from('orders')
      .select('*, order_items(*)')
      .eq('id', orderId)
      .single();

    if (fetchErr || !raw) {
      console.warn(`${TAG} Order not found — skipping confirmation`);
      return;
    }

    const email = raw.customer_email as string | null;
    if (!email) {
      console.info(`${TAG} No customer_email — skipping`);
      return;
    }

    // Dedup: only send once per order
    const shouldSend = await logEmail(orderId, 'confirmation', email);
    if (!shouldSend) {
      console.info(`${TAG} Already sent (email_log) — skipping duplicate`);
      return;
    }

    const orderNum = (raw.order_number as number) ?? String(raw.id).slice(-6);
    const items    = (raw.order_items as Record<string, unknown>[]) ?? [];
    const html     = buildConfirmationHtml(raw as Record<string, unknown>, items, (await resolveRestaurantName()).value);
    const subject  = `Order Confirmed — #${orderNum} 🍽️`;

    console.info(`${TAG} Sending confirmation to ${email}`);
    const result = await sendEmail({ to: email, subject, html });

    if ('error' in result) {
      console.error(`${TAG} Failed: ${result.error}`);
    } else {
      console.info(`${TAG} ✅ Sent — messageId: ${result.messageId}`);
    }
  } catch (err) {
    console.error(`${TAG} Unexpected error:`, err);
  }
}

// ─── Public: sendOrderReadyEmail ─────────────────────────────────────────────
/**
 * sendOrderReadyEmail(orderId)
 *
 * Sent when order status transitions to 'prepared'.
 * Tells the customer their food is ready (for pickup) or on its way (delivery).
 * Only fires if the order has a customer_email.
 * Fire-and-forget from PATCH /api/orders/[id] — never blocks the API response.
 */
export async function sendOrderReadyEmail(orderId: string): Promise<void> {
  const TAG = `[email/ready orderId=${orderId}]`;
  const sb  = getServerClient();

  try {
    const { data: raw, error: fetchErr } = await sb
      .from('orders')
      .select('id, order_number, customer_name, customer_email, type, tracking_token')
      .eq('id', orderId)
      .single();

    if (fetchErr || !raw) {
      console.warn(`${TAG} Order not found — skipping ready notification`);
      return;
    }

    const email = raw.customer_email as string | null;
    if (!email) {
      console.info(`${TAG} No customer_email — skipping`);
      return;
    }

    // Dedup: only send once per order
    const shouldSend = await logEmail(orderId, 'ready', email);
    if (!shouldSend) {
      console.info(`${TAG} Already sent (email_log) — skipping duplicate`);
      return;
    }

    const orderNum  = (raw.order_number as number) ?? String(raw.id).slice(-6);
    const typeRaw   = (raw.type as string) || 'pickup';
    const isDelivery = typeRaw === 'delivery';
    const RESTAURANT_NAME = (await resolveRestaurantName()).value;
    const subject   = isDelivery
      ? `Your ${RESTAURANT_NAME} Order #${orderNum} is On Its Way! 🛵`
      : `Your ${RESTAURANT_NAME} Order #${orderNum} is Ready! 🏪`;
    const html      = buildOrderReadyHtml(raw as Record<string, unknown>, RESTAURANT_NAME);

    console.info(`${TAG} Sending ready notification to ${email}`);
    const result = await sendEmail({ to: email, subject, html });

    if ('error' in result) {
      console.error(`${TAG} Failed: ${result.error}`);
    } else {
      console.info(`${TAG} ✅ Sent — messageId: ${result.messageId}`);
    }
  } catch (err) {
    console.error(`${TAG} Unexpected error:`, err);
  }
}

// ─── Public: sendOutForDeliveryEmail ─────────────────────────────────────────
/**
 * sendOutForDeliveryEmail(orderId)
 *
 * Sent when a delivery order moves to 'out_for_delivery'.
 * Deduped via email_log — only sends once per order.
 */
export async function sendOutForDeliveryEmail(orderId: string): Promise<void> {
  const TAG = `[email/out_for_delivery orderId=${orderId}]`;
  const sb  = getServerClient();

  try {
    const { data: raw, error: fetchErr } = await sb
      .from('orders')
      .select('id, order_number, customer_name, customer_email, type, tracking_token')
      .eq('id', orderId)
      .single();

    if (fetchErr || !raw) {
      console.warn(`${TAG} Order not found — skipping`);
      return;
    }

    const email = raw.customer_email as string | null;
    if (!email) {
      console.info(`${TAG} No customer_email — skipping`);
      return;
    }

    // Dedup: only send once per order
    const shouldSend = await logEmail(orderId, 'out_for_delivery', email);
    if (!shouldSend) {
      console.info(`${TAG} Already sent (email_log) — skipping duplicate`);
      return;
    }

    const orderNum      = (raw.order_number as number) ?? String(raw.id).slice(-6);
    const custName      = (raw.customer_name as string) || 'there';
    const trackingToken = (raw.tracking_token as string) || '';
    const RESTAURANT_NAME = (await resolveRestaurantName()).value;

    const html = `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="font-family:'Segoe UI',Arial,sans-serif;background:#f1f5f9;margin:0;padding:24px 16px">
  <div style="max-width:520px;margin:0 auto">
    <div style="background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:16px 16px 0 0;padding:28px;text-align:center">
      <div style="font-size:40px;margin-bottom:6px">🛵</div>
      <h1 style="margin:0;font-size:22px;font-weight:900;color:white">On Its Way!</h1>
      <p style="margin:6px 0 0;font-size:13px;color:rgba(255,255,255,0.9)">${RESTAURANT_NAME}</p>
    </div>
    <div style="background:white;border-radius:0 0 16px 16px;padding:28px;box-shadow:0 4px 24px rgba(0,0,0,0.08)">
      <p style="font-size:15px;color:#334155;margin:0 0 16px">Hi <strong>${custName}</strong>,</p>
      <p style="font-size:14px;color:#475569;margin:0 0 20px">
        Great news! Your order <strong>#${orderNum}</strong> has been picked up and is on its way to you.
        Our delivery agent will arrive shortly.
      </p>
      <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:14px 18px;text-align:center">
        <div style="font-size:11px;font-weight:700;color:#2563eb;text-transform:uppercase;letter-spacing:1px">Order #${orderNum}</div>
        <div style="font-family:monospace;font-size:11px;color:#94a3b8;margin-top:4px">${String(raw.id)}</div>
      </div>
      ${trackingToken ? trackingButtonHtml(String(raw.id), trackingToken, '🛵 Track Your Delivery', '#2563eb') : ''}
    </div>
    <div style="text-align:center;padding:16px;font-size:11px;color:#94a3b8">
      Thank you for choosing <strong style="color:#E65C00">${RESTAURANT_NAME}</strong>! 🙏
    </div>
  </div>
</body>
</html>`;

    const subject = `Your ${RESTAURANT_NAME} Order #${orderNum} is on its way! 🛵`;

    console.info(`${TAG} Sending out_for_delivery notification to ${email}`);
    const result = await sendEmail({ to: email, subject, html });

    if ('error' in result) {
      console.error(`${TAG} Failed: ${result.error}`);
    } else {
      console.info(`${TAG} ✅ Sent — messageId: ${result.messageId}`);
    }
  } catch (err) {
    console.error(`${TAG} Unexpected error:`, err);
  }
}

// ─── Public: sendRewardEmail ──────────────────────────────────────────────────
/**
 * sendRewardEmail(args)
 *
 * Sends a Spin & Win reward coupon email to the customer.
 * Works for both order-based spins (pickup/delivery) and tab-based spins (dine-in).
 * Idempotent via email_log.dedup_key — only sends once per spin event.
 * Fire-and-forget — never blocks the spin API response.
 */

export interface RewardEmailArgs {
  /** Used as dedup key base — can be tabId or orderId */
  emailRef:       string;
  /** Unique event type like 'reward_tab_XXX' or 'reward_order_XXX' */
  eventType:      string;
  recipientEmail: string;
  rewardLabel:    string;
  rewardType:     string;
  couponCode:     string;
  expiresAt:      string;
  minNextOrder:   number;
  /** Cap on percent discount in ₹ — shown in email when set (v014) */
  maxDiscount?:   number;
}

export async function sendRewardEmail(args: RewardEmailArgs): Promise<void> {
  const TAG = '[email:reward]';
  try {
    const { emailRef, eventType, recipientEmail, rewardLabel, rewardType, couponCode, expiresAt, minNextOrder, maxDiscount } = args;

    // Dedup: only send once per spin (use dedup_key for flexible FK-free deduplication)
    const sb = getServerClient();
    const dedupKey = `${emailRef}:${eventType}`;
    const { error: logErr } = await sb.from('email_log').insert({
      id:         newId('EML'),
      dedup_key:  dedupKey,
      event_type: eventType,
      sent_to:    recipientEmail,
      // order_id is now nullable in migration_012 — leave null for tab-based spins
    });
    if (logErr?.code === '23505') {
      console.info(`${TAG} Already sent (dedup_key=${dedupKey}) — skipping duplicate`);
      return;
    }

    const expiryFormatted = new Date(expiresAt).toLocaleDateString('en-IN', {
      day: 'numeric', month: 'long', year: 'numeric',
    });

    const isFreeItem = rewardType === 'free_item';
    const rewardSection = isFreeItem
      ? `<p style="font-size:1.1rem;font-weight:bold;color:#7c3aed;margin:0 0 0.5rem;">🎁 ${rewardLabel}</p>`
      : `<p style="font-size:1.1rem;font-weight:bold;color:#7c3aed;margin:0 0 0.5rem;">🎉 ${rewardLabel}</p>`;

    const minOrderSection = minNextOrder > 0
      ? `<tr><td style="color:#555;padding:4px 0;font-size:13px;">Minimum Purchase</td><td style="font-weight:600;padding:4px 0;font-size:13px;text-align:right;">₹${minNextOrder}</td></tr>`
      : '';

    const maxDiscountSection = (rewardType === 'percent' && maxDiscount != null && maxDiscount > 0)
      ? `<tr><td style="color:#555;padding:4px 0;font-size:13px;">Maximum Discount</td><td style="font-weight:600;padding:4px 0;font-size:13px;text-align:right;">₹${maxDiscount}</td></tr>`
      : '';

    const RESTAURANT_NAME = (await resolveRestaurantName()).value;

    const html = `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="font-family:'Segoe UI',Arial,sans-serif;background:#f1f5f9;margin:0;padding:24px 16px">
  <div style="max-width:480px;margin:0 auto">
    <div style="background:linear-gradient(135deg,#7c3aed,#4f46e5);border-radius:16px 16px 0 0;padding:28px 24px;text-align:center">
      <div style="font-size:36px;margin-bottom:8px">🎡</div>
      <h1 style="margin:0;font-size:22px;font-weight:900;color:white;text-shadow:0 1px 3px rgba(0,0,0,0.2)">
        Your Spin &amp; Win Reward!
      </h1>
      <p style="margin:6px 0 0;font-size:13px;color:rgba(255,255,255,0.9)">${RESTAURANT_NAME}</p>
    </div>
    <div style="background:white;border-radius:0 0 16px 16px;padding:28px 24px;box-shadow:0 4px 24px rgba(0,0,0,0.08)">
      <p style="color:#374151;font-size:14px;margin:0 0 16px;">Congratulations! Here is your reward from your recent visit:</p>
      ${rewardSection}
      <div style="background:#f5f3ff;border-radius:10px;padding:16px;margin:16px 0;text-align:center">
        <p style="color:#6b7280;font-size:11px;margin:0 0 6px;text-transform:uppercase;letter-spacing:1px;font-weight:700">YOUR COUPON CODE</p>
        <p style="font-family:monospace;font-size:28px;font-weight:bold;color:#4f46e5;letter-spacing:4px;margin:0;">${couponCode}</p>
      </div>
      <table style="width:100%;border-collapse:collapse;margin-bottom:16px">
        <tr>
          <td style="color:#555;padding:4px 0;font-size:13px;">Valid Until</td>
          <td style="font-weight:600;padding:4px 0;font-size:13px;text-align:right;">${expiryFormatted}</td>
        </tr>
        ${minOrderSection}
        ${maxDiscountSection}
      </table>
      <p style="color:#6b7280;font-size:12px;margin:0;line-height:1.5">
        Use this coupon on your next eligible order at ${RESTAURANT_NAME}.<br/>
        Save this email — your code is <strong style="color:#4f46e5">${couponCode}</strong>.
      </p>
    </div>
    <div style="text-align:center;padding:16px;font-size:11px;color:#94a3b8">
      Thank you for dining with <strong style="color:#E65C00">${RESTAURANT_NAME}</strong>! 🙏
    </div>
  </div>
</body>
</html>`;

    await dispatchViaResend(
      recipientEmail,
      `🎡 Your Spin & Win Reward: ${rewardLabel}`,
      html,
    );
    console.info(`${TAG} Reward email sent to ${recipientEmail}`);
  } catch (err) {
    console.error(`${TAG} Error:`, err);
  }
}

// ─── Spin & Win Invite Email ──────────────────────────────────────────────────

/** Builds the HTML for a spin invite email (sent BEFORE the customer spins). */
function buildSpinInviteHtml(args: {
  spinUrl:      string;
  customerName: string;
  orderTotal?:  number;
  orderType?:   string;
  restaurantName: string;
}): string {
  const { spinUrl, customerName, orderTotal, orderType, restaurantName } = args;
  const RESTAURANT_NAME = restaurantName;
  const typeLabel =
    orderType === 'delivery' ? 'delivery order' :
    orderType === 'pickup'   ? 'pickup order'   :
    orderType === 'dine-in'  ? 'dine-in visit'  : 'recent visit';

  const totalLine = orderTotal != null && orderTotal > 0
    ? `<p style="font-size:14px;color:#6b7280;margin:0 0 20px;">Your qualifying ${typeLabel} total: <strong style="color:#4f46e5">₹${orderTotal.toFixed(0)}</strong></p>`
    : '';

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>🎡 You've Unlocked Spin &amp; Win!</title>
</head>
<body style="font-family:'Segoe UI',Arial,sans-serif;background:#f5f3ff;margin:0;padding:24px 16px">
  <div style="max-width:520px;margin:0 auto">

    <!-- Header -->
    <div style="background:linear-gradient(135deg,#7c3aed,#4f46e5,#6d28d9);border-radius:20px 20px 0 0;padding:36px 28px;text-align:center">
      <div style="font-size:52px;margin-bottom:10px;display:block">🎡</div>
      <h1 style="margin:0;font-size:26px;font-weight:900;color:white;letter-spacing:-0.5px;text-shadow:0 2px 8px rgba(0,0,0,0.3)">
        You&apos;ve Unlocked<br/>Spin &amp; Win!
      </h1>
      <p style="margin:8px 0 0;font-size:14px;color:rgba(255,255,255,0.85)">${RESTAURANT_NAME}</p>
    </div>

    <!-- Card -->
    <div style="background:white;border-radius:0 0 20px 20px;padding:32px 28px;box-shadow:0 8px 32px rgba(109,40,217,0.12)">

      <p style="font-size:16px;font-weight:700;color:#1f2937;margin:0 0 8px;">
        Hi ${customerName}! 🎉
      </p>
      <p style="font-size:14px;color:#374151;margin:0 0 16px;line-height:1.6">
        Your ${typeLabel} at <strong>${RESTAURANT_NAME}</strong> has qualified you for a
        <strong style="color:#7c3aed">Spin &amp; Win</strong> reward!
        Give the wheel a spin to reveal your prize.
      </p>

      ${totalLine}

      <!-- CTA button -->
      <div style="text-align:center;margin:28px 0 24px">
        <a href="${spinUrl}" target="_blank" rel="noopener noreferrer"
           style="display:inline-block;background:linear-gradient(135deg,#7c3aed,#4f46e5);color:white;
                  font-weight:900;font-size:17px;padding:16px 40px;border-radius:14px;
                  text-decoration:none;letter-spacing:0.3px;
                  box-shadow:0 6px 20px rgba(109,40,217,0.4)">
          🎡 &nbsp; Spin Now!
        </a>
        <div style="margin-top:10px;font-size:11px;color:#9ca3af">
          or copy this link:<br/>
          <a href="${spinUrl}" style="color:#7c3aed;font-family:monospace;font-size:10px;word-break:break-all">${spinUrl}</a>
        </div>
      </div>

      <!-- Terms note -->
      <div style="background:#f5f3ff;border-radius:10px;padding:14px 16px;font-size:12px;color:#6b7280;line-height:1.6;border:1px solid #ede9fe">
        <strong style="color:#7c3aed">📋 How it works:</strong><br/>
        Each qualifying order gives you <strong>one spin</strong>. Your spin link is unique to this order.
        Rewards can include discounts, free items, and more — whatever the wheel lands on is yours!
      </div>
    </div>

    <!-- Footer -->
    <div style="text-align:center;padding:20px;font-size:11px;color:#9ca3af">
      Thank you for choosing <strong style="color:#7c3aed">${RESTAURANT_NAME}</strong>! 🙏<br/>
      <span style="font-size:10px">This invite is tied to your specific order. Each order = one spin.</span>
    </div>

  </div>
</body>
</html>`;
}

// ─── Public: sendSpinInviteEmail ──────────────────────────────────────────────
/**
 * sendSpinInviteEmail(args)
 *
 * Sends a Spin & Win invitation email with a secure spin URL to the customer.
 * Also updates spin_invite_sent_at on the order or tab to track send history.
 *
 * This email is RESENDABLE — each send is logged but never blocked by dedup.
 * The spin entitlement (ONE per order) is always enforced server-side by the
 * UNIQUE constraint on spin_results, not by the email or token.
 */
export async function sendSpinInviteEmail(args: {
  orderId?:     string;
  tabId?:       string;
  spinToken:    string;
  recipientEmail: string;
  customerName?: string;
  orderTotal?:  number;
  orderType?:   string;
}): Promise<{ sent: boolean; reason?: string }> {
  const { orderId, tabId, spinToken, recipientEmail, customerName, orderTotal, orderType } = args;
  const TAG = `[email:spin_invite ${orderId ? `orderId=${orderId}` : `tabId=${tabId}`}]`;

  try {
    // Build spin URL pointing to the new /spin page
    const entityParam = orderId
      ? `orderId=${encodeURIComponent(orderId)}`
      : `tabId=${encodeURIComponent(tabId!)}`;
    const spinUrl = `${APP_BASE_URL}/spin?${entityParam}&token=${encodeURIComponent(spinToken)}`;
    const RESTAURANT_NAME = (await resolveRestaurantName()).value;

    const html    = buildSpinInviteHtml({
      spinUrl,
      customerName: customerName || 'Valued Customer',
      orderTotal,
      orderType,
      restaurantName: RESTAURANT_NAME,
    });
    const subject = `🎡 You've unlocked Spin & Win at ${RESTAURANT_NAME}!`;

    console.info(`${TAG} Sending spin invite to ${recipientEmail}`);
    const result = await dispatchViaResend(recipientEmail, subject, html);

    if ('error' in result) {
      console.error(`${TAG} Failed: ${result.error}`);
      return { sent: false, reason: result.error };
    }

    // Update spin_invite_sent_at on the entity for "Send" vs "Resend" UX
    const sb = getServerClient();
    const sentAt = new Date().toISOString();
    if (orderId) {
      await sb.from('orders').update({ spin_invite_sent_at: sentAt }).eq('id', orderId);
    } else if (tabId) {
      await sb.from('customer_tabs').update({ spin_invite_sent_at: sentAt }).eq('id', tabId);
    }

    console.info(`${TAG} ✅ Invite sent to ${recipientEmail} — messageId: ${result.messageId}`);
    return { sent: true };
  } catch (err) {
    console.error(`${TAG} Unexpected error:`, err);
    return { sent: false, reason: String(err) };
  }
}

// ─── Internal: triggerSpinInviteForOrder ─────────────────────────────────────
/**
 * triggerSpinInviteForOrder(orderId)
 *
 * Called fire-and-forget from PATCH /api/orders/[id] when isNowComplete fires.
 * 1. Fetches the order and spin_config.
 * 2. Generates spin_token if not already set.
 * 3. Checks if the order is eligible (type, amount).
 * 4. Sends invite email if customer email exists.
 * Silently skips if ineligible or if email is missing.
 */
export async function triggerSpinInviteForOrder(orderId: string): Promise<void> {
  const TAG = `[email:spin_trigger/order orderId=${orderId}]`;
  const sb  = getServerClient();
  const rid = process.env.NEXT_PUBLIC_RESTAURANT_ID ?? 'rest_default';

  try {
    // 1. Fetch order
    const { data: order } = await sb
      .from('orders')
      .select('id, customer_email, customer_name, type, total, status, spin_token, phone')
      .eq('id', orderId)
      .single();

    if (!order) {
      console.warn(`${TAG} Order not found — skipping`);
      return;
    }

    // 2. Fetch spin config
    const { data: config } = await sb
      .from('spin_config')
      .select('enabled, min_order_amount, eligible_order_types, require_email, require_phone')
      .eq('restaurant_id', rid)
      .single();

    if (!config?.enabled) {
      console.info(`${TAG} Spin & Win disabled — skipping`);
      return;
    }

    // 3. Check amount and order type eligibility
    const total = Number(order.total) || 0;
    if (total < Number(config.min_order_amount)) {
      console.info(`${TAG} Below min amount (${total} < ${config.min_order_amount}) — skipping`);
      return;
    }

    const eligibleTypes = (config.eligible_order_types as string[]) ?? [];
    const effectiveType = (order.type as string) === 'online' ? 'delivery' : (order.type as string);
    if (!eligibleTypes.includes(effectiveType) && !eligibleTypes.includes(order.type as string)) {
      console.info(`${TAG} Order type "${order.type}" not eligible — skipping`);
      return;
    }

    // 3a. Contact requirements — same rules as GET /api/rewards/eligibility
    if (config.require_email && !order.customer_email) {
      console.info(`${TAG} require_email set but order has no customer_email — skipping`);
      return;
    }
    if (config.require_phone && !order.phone) {
      console.info(`${TAG} require_phone set but order has no phone — skipping`);
      return;
    }

    // 4. Generate spin_token if missing
    let spinToken = order.spin_token as string | null;
    if (!spinToken) {
      spinToken = generateSpinToken();
      await sb.from('orders').update({ spin_token: spinToken }).eq('id', orderId);
      console.info(`${TAG} Generated new spin_token`);
    }

    // 5. Send invite if email exists
    const email = order.customer_email as string | null;
    if (!email) {
      console.info(`${TAG} No customer_email — spin_token saved but invite not sent`);
      return;
    }

    await sendSpinInviteEmail({
      orderId,
      spinToken,
      recipientEmail:  email,
      customerName:    (order.customer_name as string) || 'Valued Customer',
      orderTotal:      total,
      orderType:       effectiveType,
    });
  } catch (err) {
    console.error(`${TAG} Unexpected error:`, err);
  }
}

// ─── Internal: triggerSpinInviteForTab ───────────────────────────────────────
/**
 * triggerSpinInviteForTab(tabId)
 *
 * Called fire-and-forget from PATCH /api/tabs/[id] when a tab closes.
 * Works exactly like triggerSpinInviteForOrder but for dine-in tabs.
 * Checks for 'dine-in' in eligible_order_types.
 */
export async function triggerSpinInviteForTab(tabId: string): Promise<void> {
  const TAG = `[email:spin_trigger/tab tabId=${tabId}]`;
  const sb  = getServerClient();
  const rid = process.env.NEXT_PUBLIC_RESTAURANT_ID ?? 'rest_default';

  try {
    // 1. Fetch tab
    const { data: tab } = await sb
      .from('customer_tabs')
      .select('id, customer_email, customer_name, total, status, spin_token, phone')
      .eq('id', tabId)
      .single();

    if (!tab) {
      console.warn(`${TAG} Tab not found — skipping`);
      return;
    }

    // 2. Fetch spin config
    const { data: config } = await sb
      .from('spin_config')
      .select('enabled, min_order_amount, eligible_order_types, require_email, require_phone')
      .eq('restaurant_id', rid)
      .single();

    if (!config?.enabled) {
      console.info(`${TAG} Spin & Win disabled — skipping`);
      return;
    }

    // 3. Check 'dine-in' eligibility
    const eligibleTypes = (config.eligible_order_types as string[]) ?? [];
    if (!eligibleTypes.includes('dine-in')) {
      console.info(`${TAG} dine-in not in eligible_order_types — skipping`);
      return;
    }

    // 4. Check amount
    const total = Number(tab.total) || 0;
    if (total < Number(config.min_order_amount)) {
      console.info(`${TAG} Below min amount (${total} < ${config.min_order_amount}) — skipping`);
      return;
    }

    // 4a. Contact requirements — same rules as GET /api/rewards/eligibility (with tab→orders phone fallback)
    if (config.require_email && !tab.customer_email) {
      console.info(`${TAG} require_email set but tab has no customer_email — skipping`);
      return;
    }
    if (config.require_phone) {
      let resolvedPhone = (tab.phone as string | null) ?? null;
      if (!resolvedPhone) {
        const { data: orderWithPhone } = await sb
          .from('orders')
          .select('phone')
          .eq('tab_id', tabId)
          .not('phone', 'is', null)
          .limit(1)
          .maybeSingle();
        resolvedPhone = (orderWithPhone?.phone as string | null) ?? null;
      }
      if (!resolvedPhone) {
        console.info(`${TAG} require_phone set but no phone on tab or orders — skipping`);
        return;
      }
    }

    // 5. Generate spin_token if missing
    let spinToken = tab.spin_token as string | null;
    if (!spinToken) {
      spinToken = generateSpinToken();
      await sb.from('customer_tabs').update({ spin_token: spinToken }).eq('id', tabId);
      console.info(`${TAG} Generated new spin_token`);
    }

    // 6. Send invite if email exists
    const email = tab.customer_email as string | null;
    if (!email) {
      console.info(`${TAG} No customer_email — spin_token saved but invite not sent`);
      return;
    }

    await sendSpinInviteEmail({
      tabId,
      spinToken,
      recipientEmail:  email,
      customerName:    (tab.customer_name as string) || 'Valued Customer',
      orderTotal:      total,
      orderType:       'dine-in',
    });
  } catch (err) {
    console.error(`${TAG} Unexpected error:`, err);
  }
}
