'use client';

export const dynamic = 'force-dynamic';
import { useState, useEffect, useCallback, lazy, Suspense } from 'react';
import { useRouter } from 'next/navigation';
import { useRealtime } from '@/lib/realtime-client';
// ── All Supabase-backed functions + types ──────────────────────────────────────
import {
  getOrders, updateOrderStatus as apiUpdateOrderStatus, applyDiscount as apiApplyDiscount,
  computeOnlineOrderStats, OnlineOrderStats,
  getTables as getTablesApi, getTabs as getTabsApi,
  createTable as createTableApi, updateTable as updateTableApi, deleteTable as deleteTableApi,
  getMenu as getMenuApi, saveMenuItem as saveMenuItemApi, deleteMenuItem as deleteMenuItemApi,
  Table, MenuItem, WaiterStats, TableOccupancyStats,
  Order,
  getSettings, saveSettings, saveSetting,
  listStaff, addStaff, patchStaff, removeStaff, StaffMember,
  getAllIssues, OrderIssue,
  forceCloseTab,
} from '@/lib/api';
import {
  getSession, clearSession, AuthSession,
  SECURITY_QUESTIONS,
} from '@/lib/auth';
import {
  todayMidnightIST, isToday, clockIST,
  fmtDateLong, fmtDate, fmtTime, fmtDateTime, fmtDateTimeShort,
  getISTHour, fmtMonthYear, toISTDate,
} from '@/lib/date';
import { MENU_CATEGORIES } from '@/lib/categories';

// ─── Constants ────────────────────────────────────────────────────────────────
// Dine-in flow:  awaiting_waiter→pending→preparing→prepared→served→completed
// Pickup flow:   pending→preparing→prepared→served→completed   (same as dine-in after accepted)
// Delivery flow: pending→preparing→prepared→out_for_delivery→delivered→completed
// NOTE: awaiting_waiter is prepended for dine-in so admin can accept the order if waiter is unavailable.
// All order types now start at 'awaiting_waiter' — a waiter must
// "Confirm & Print" before an order moves to 'preparing'. These flows let the
// admin history table's "advance" button step a stuck order forward manually
// (it's a plain status PATCH, not a print-triggering confirm).
const STATUS_FLOW_DINE_IN  = ['awaiting_waiter','pending','preparing','prepared','served','completed'] as const;
const STATUS_FLOW_PICKUP   = ['awaiting_waiter','pending','preparing','prepared','served','completed'] as const;
const STATUS_FLOW_DELIVERY = ['awaiting_waiter','pending','preparing','prepared','out_for_delivery','delivered','completed'] as const;
const CATEGORIES = MENU_CATEGORIES;
const BADGE_LABEL : Record<string,string> = { bestseller:'⭐ Bestseller', popular:'🔥 Popular', chef:"👨‍🍳 Chef's Special", famous:'🏆 Famous', new:'✨ New' };
const STATUS_COLOR: Record<string,string> = {
  awaiting_waiter:   '#f59e0b', pending:'#f59e0b', preparing:'#3b82f6',
  prepared:          '#8b5cf6', served:'#06b6d4', completed:'#16a34a',
  out_for_delivery:  '#2563eb', delivered:'#7c3aed',
  re_serve_required: '#dc2626',
  cancelled:         '#ef4444', void:'#9ca3af',
};
const STATUS_LABEL_MAP: Record<string,string> = {
  awaiting_waiter:   'Awaiting Waiter', pending:'In Queue', preparing:'Preparing',
  prepared:          'Ready', served:'Served', completed:'Completed',
  out_for_delivery:  '🛵 Out for Delivery', delivered:'📦 Delivered',
  re_serve_required: '🚨 Re-Serve Required',
  cancelled:         'Cancelled', void:'Void',
};

// ─── Style helpers ────────────────────────────────────────────────────────────
const card  = (color='#E65C00') => ({ background:'white' as const, borderRadius:12, padding:'1.4rem', boxShadow:'0 2px 8px rgba(0,0,0,0.08)', marginBottom:'1.5rem', borderLeft:`4px solid ${color}` });
const tabB  = (active:boolean)  => ({ padding:'0.42rem 1rem', border:`2px solid ${active?'#E65C00':'#ddd'}`, borderRadius:20, background:active?'#E65C00':'white' as const, color:active?'white' as const:'#666' as const, fontWeight:600 as const, cursor:'pointer' as const, fontSize:'0.8rem', fontFamily:'Poppins,sans-serif' });
const inp   = { width:'100%', padding:'0.6rem 0.75rem', border:'2px solid #e5e7eb', borderRadius:8, fontFamily:'Poppins,sans-serif', fontSize:'0.88rem', outline:'none' as const };
const btn   = (bg='#E65C00',c='white') => ({ background:bg, color:c, border:'none', padding:'0.55rem 1.1rem', borderRadius:8, fontWeight:700 as const, cursor:'pointer' as const, fontFamily:'Poppins,sans-serif', fontSize:'0.84rem' });
const emptyItem = ():Partial<MenuItem> => ({ category:'Non Veg Biryani', name:'', desc:'', price:0, img:'', badge:'', available:true, variants:[] });

const AnalyticsCharts = lazy(() => import('@/components/AnalyticsCharts'));
const AdminFinance    = lazy(() => import('@/components/AdminFinance'));

export default function AdminPage() {
  const [orders,      setOrders]      = useState<Order[]>([]);
  const [tables,      setTables]      = useState<Table[]>([]);
  // Live table status derived from Supabase (customer_tabs + tables API)
  const [liveTables,  setLiveTables]  = useState<(Table & { sessionStart?: string; sessionTabId?: string })[]>([]);
  const [menu,        setMenu]        = useState<MenuItem[]>([]);
  const [clock,   setClock]   = useState({ date:'', time:'' });

  // ── Auth ──
  const router                          = useRouter();
  const [authSession, setAuthSession]   = useState<AuthSession | null>(null);
  const [authChecked, setAuthChecked]   = useState(false);

  // ── Navigation ──
  type Section = 'overview'|'orders'|'sales'|'finance'|'menu'|'offers'|'tables'|'fraud'|'staff'|'email'|'feedback'|'spin'|'rewards_audit'|'kitchen';
  const [section, setSection] = useState<Section>('overview');

  // ── Tabs / filters ──
  const [salesTab,        setSalesTab]        = useState<'today'|'week'|'month'|'all'>('today');
  const [orderFilter,     setOrderFilter]     = useState('all');
  const [ordersDateFilter,setOrdersDateFilter]= useState<'today'|'yesterday'|'week'|'month'|'all'>('today');
  const [menuFilter,      setMenuFilter]      = useState('All');

  // ── Historical orders (sales report + orders section) ──
  // orders     = today only, kept fresh by 3-second polling (live dashboard)
  // histOrders = scoped to the selected period, fetched on demand
  const [histOrders,    setHistOrders]    = useState<Order[]>([]);
  const [histLoading,   setHistLoading]   = useState(false);

  // ── Modals ──
  const [selOrder,      setSelOrder]      = useState<Order|null>(null);
  const [menuModal,     setMenuModal]     = useState<{open:boolean;item:Partial<MenuItem>;isEdit:boolean}>({open:false,item:emptyItem(),isEdit:false});
  // modalVariants: separate state for the variants editor inside the menu modal
  // Uses string prices so the input fields can be empty/partial while typing
  const [modalVariants, setModalVariants] = useState<{name:string;price:string}[]>([{name:'',price:''}]);
  const [imgUploading,   setImgUploading]   = useState(false);
  const [seedingMenu,    setSeedingMenu]     = useState(false);
  const [seedMsg,        setSeedMsg]         = useState('');
  const [csvImportMsg,   setCsvImportMsg]    = useState('');
  const [cancelModal,   setCancelModal]   = useState<{open:boolean;orderId:string}>({open:false,orderId:''});
  const [discountModal, setDiscountModal] = useState<{open:boolean;orderId:string}>({open:false,orderId:''});

  // ── Email Diagnostics ──
  type EmailDiag = {
    configured: boolean;
    fromEmail: string;
    fromEmailConfigured: boolean;
    fromEmailDomain: string;
    apiKeyPresent: boolean;
    apiKeyLength: number;
    queueError: string | null;
    queueSummary: { total: number; sent: number; failed: number; pending: number };
    lastEntry: { status: string; error: string | null; created_at: string; updated_at: string } | null;
    recentQueue: { id: string; order_id: string; status: string; error: string | null; retry_count: number; created_at: string; updated_at: string }[];
  };
  const [emailDiag,       setEmailDiag]       = useState<EmailDiag | null>(null);
  const [emailDiagLoading,setEmailDiagLoading] = useState(false);
  const [emailDiagError,  setEmailDiagError]   = useState('');
  const [testEmailTo,     setTestEmailTo]      = useState('');
  const [testEmailResult, setTestEmailResult]  = useState('');
  const [testEmailBusy,   setTestEmailBusy]    = useState(false);

  // ── Form values ──
  const [cancelReason, setCancelReason] = useState('');
  const [discAmt,      setDiscAmt]      = useState('');
  const [discNote,     setDiscNote]     = useState('');
  const [pinInput,     setPinInput]     = useState('');
  const [pinMsg,       setPinMsg]       = useState('');
  const [showPinMgr,   setShowPinMgr]   = useState(false);
  const [newPin,       setNewPin]       = useState('');
  const [newPinMsg,    setNewPinMsg]    = useState('');

  // ── Analytics state ──
  const [waiterStats,    setWaiterStats]    = useState<WaiterStats[]>([]);
  const [tableOccupancy, setTableOccupancy] = useState<TableOccupancyStats[]>([]);
  const [onlineStats,    setOnlineStats]    = useState<OnlineOrderStats | null>(null);

  // ── Issue analytics state ──
  const [todayIssues,    setTodayIssues]    = useState<OrderIssue[]>([]);

  // ── Closed tabs count (for EOD report) ──
  const [closedTabsCount, setClosedTabsCount] = useState(0);

  // ── Danger zone: clear all orders ──
  const [clearPin,    setClearPin]    = useState('');
  const [clearMsg,    setClearMsg]    = useState('');
  const [clearBusy,   setClearBusy]   = useState(false);
  const [clearConfirm, setClearConfirm] = useState(false);

  // ── Targeted order deletion ──
  const [delMode,     setDelMode]     = useState<'id'|'date'|'range'>('id');
  const [delOrderId,  setDelOrderId]  = useState('');
  const [delDate,     setDelDate]     = useState('');
  const [delDateFrom, setDelDateFrom] = useState('');
  const [delDateTo,   setDelDateTo]   = useState('');
  const [delTimeFrom, setDelTimeFrom] = useState('00:00');
  const [delTimeTo,   setDelTimeTo]   = useState('23:59');
  const [delPin,      setDelPin]      = useState('');
  const [delPreview,  setDelPreview]  = useState<number|null>(null);
  const [delMsg,      setDelMsg]      = useState('');
  const [delBusy,     setDelBusy]     = useState(false);

  // ── Staff management state ──
  const [staffAccounts, setStaffAccounts] = useState<StaffMember[]>([]);
  const [staffForm,  setStaffForm]  = useState({ name: '', username: '', pin: '' });
  const [staffMsg,   setStaffMsg]   = useState('');
  // kitchenPin / managerPin are write-only form fields for setting a NEW pin.
  // They are never pre-filled with the current value — PINs are never sent to the browser.
  const [kitchenPin, setKitchenPin] = useState('');
  const [managerPin, setManagerPin] = useState('');
  const [kitchenPinMsg, setKitchenPinMsg] = useState('');
  const [managerPinMsg, setManagerPinMsg] = useState('');
  const [editPinId,  setEditPinId]  = useState('');
  const [editPinVal, setEditPinVal] = useState('');
  // ── Configuration diagnostics (ENV vs Admin vs Default) ──────────────────
  interface ConfigDiagEntry { label: string; value: string; source: 'env'|'admin'|'default'; envVar?: string; adminKey?: string; adminValueShadowed?: string | null }
  interface SecretDiagEntry { label: string; envVar: string; configured: boolean }
  const [configDiag,    setConfigDiag]    = useState<{ settings: ConfigDiagEntry[]; secrets: SecretDiagEntry[] } | null>(null);
  const [configDiagErr, setConfigDiagErr] = useState('');

  // ── Delivery accounts state ──
  const [deliveryAccounts,  setDeliveryAccounts]  = useState<StaffMember[]>([]);
  const [deliveryForm,      setDeliveryForm]      = useState({ name: '', username: '', pin: '' });
  const [deliveryMsg,       setDeliveryMsg]       = useState('');
  const [editDelivPinId,    setEditDelivPinId]    = useState('');
  const [editDelivPinVal,   setEditDelivPinVal]   = useState('');

  // ── Table management state ──
  const [tableForm,    setTableForm]    = useState({ name: '', capacity: '4' });
  const [tableMsg,     setTableMsg]     = useState('');
  const [editTableId,  setEditTableId]  = useState('');       // id of table being edited inline
  const [editTableVal, setEditTableVal] = useState({ name: '', capacity: '4' });

  // ── Admin PIN change state ──
  const [adminNewPin,    setAdminNewPin]    = useState('');
  const [adminNewPin2,   setAdminNewPin2]   = useState('');
  const [adminPinOld,    setAdminPinOld]    = useState('');
  const [adminPinMsg,    setAdminPinMsg]    = useState('');

  // ── Security question state ──
  const [secQuestion,    setSecQuestion]    = useState('');
  const [secAnswer,      setSecAnswer]      = useState('');
  const [secAnswerConf,  setSecAnswerConf]  = useState('');
  const [secMsg,         setSecMsg]         = useState('');
  const [secSetup,       setSecSetup]       = useState<{ question: string; setupAt: string } | null>(null);

  // ── Offer rules state ──
  interface OfferRule {
    id: string;
    name: string;
    type: 'percent' | 'flat';
    value: number;
    minOrder: number;
    maxDiscount: number;
    applyTo: 'all' | 'dine-in' | 'pickup' | 'delivery';
    active: boolean;
  }
  const [offerRules,     setOfferRules]     = useState<OfferRule[]>([]);
  const [offerForm,      setOfferForm]      = useState<Omit<OfferRule,'id'>>({ name:'', type:'percent', value:10, minOrder:0, maxDiscount:0, applyTo:'all', active:true });
  const [offerMsg,       setOfferMsg]       = useState('');
  const [offerBusy,      setOfferBusy]      = useState(false);

  // ── Feedback section state ──
  interface FeedbackRow { id: string; order_id: string; rating: number; comment?: string; created_at: string; orders?: { order_number: number; type: string; customer_name: string; total: number; created_at: string } }
  const [feedbackRows,   setFeedbackRows]   = useState<FeedbackRow[]>([]);
  const [feedbackLoaded, setFeedbackLoaded] = useState(false);

  // ── Spin & Win admin state ──
  interface SpinRewardRow {
    id: string; label: string; reward_type: string; reward_value: number;
    weight: number; min_next_order: number; expires_days: number;
    active: boolean; sort_order: number;
    // v014
    max_discount: number | null; daily_win_limit: number | null;
    monthly_win_limit: number | null;
    bogo_eligible_items: string[]; bogo_eligible_categories: string[];
    max_free_item_value: number | null;
    // v015
    archived: boolean; daily_usage: number;
  }
  interface SpinImportPreviewRow {
    action: 'CREATE' | 'UPDATE' | 'NO CHANGE' | 'ERROR';
    id?: string;
    label: string;
    type: string;
    value: number;
    max_discount: number | null;
    daily_win_limit: number | null;
    weight: number;
    chance: string;
    min_next_order: number;
    expires_days: number;
    active: boolean;
    error?: string;
  }
  interface SpinImportPreview {
    totalRows: number;
    newCount: number;
    updateCount: number;
    noChangeCount: number;
    errorCount: number;
    errors: string[];
    rows: SpinImportPreviewRow[];
  }
  interface SpinConfigRow { enabled: boolean; min_order_amount: number; eligible_order_types: string[]; require_email: boolean; require_phone: boolean }
  const [spinConfig,     setSpinConfig]     = useState<SpinConfigRow>({ enabled: false, min_order_amount: 500, eligible_order_types: ['dine-in','pickup','delivery'], require_email: true, require_phone: true });
  const [spinRewards,    setSpinRewards]    = useState<SpinRewardRow[]>([]);
  const [spinLoaded,     setSpinLoaded]     = useState(false);
  const [spinMsg,        setSpinMsg]        = useState('');
  const [spinRewardForm, setSpinRewardForm] = useState<Omit<SpinRewardRow,'id'>>({
    label: '', reward_type: 'percent', reward_value: 10, weight: 1,
    min_next_order: 0, expires_days: 30, active: true, sort_order: 0,
    max_discount: null, daily_win_limit: null, monthly_win_limit: null,
    bogo_eligible_items: [], bogo_eligible_categories: [], max_free_item_value: null,
    archived: false, daily_usage: 0,
  });
  const [editingRewardId,   setEditingRewardId]   = useState<string | null>(null);
  const [spinTogglingIds,   setSpinTogglingIds]   = useState<Set<string>>(new Set());
  const [spinImportPreview, setSpinImportPreview] = useState<SpinImportPreview | null>(null);
  const [spinImportRows,    setSpinImportRows]    = useState<Record<string, string>[]>([]);
  const [spinImportBusy,    setSpinImportBusy]    = useState(false);

  // ── Kitchen routing mode ──
  const [kitchenMode,    setKitchenMode]    = useState<'ask'|'printer'|'kitchen_display'>('ask');
  const [kitchenModeMsg, setKitchenModeMsg] = useState('');

  // ── Rewards audit state ──
  interface AuditRow { id: string; coupon_code: string; label: string; reward_type: string; reward_value: number; status: string; customer_email: string; customer_phone: string; issued_at: string; expires_at: string; redeemed_at?: string; discount_given?: number; spin_results?: { customer_email: string; spun_at: string }; source_order?: { order_number: number; type: string; total: number } }
  const [auditRows,      setAuditRows]      = useState<AuditRow[]>([]);
  const [auditLoaded,    setAuditLoaded]    = useState(false);

  // ── Data refresh ──
  const refresh = useCallback(async () => {
    // ── Orders: fetched from Supabase (NOT localStorage) ──────────────────────
    try {
      // Fetch ALL of today's orders for the live dashboard (active + completed + cancelled).
      // Bounded to today midnight so polling stays fast. Historical views use histOrders.
      const liveOrders = await getOrders({ since: todayMidnightIST().toISOString(), limit: 500 });
      setOrders(liveOrders);

      // Compute online/pickup/delivery stats from the same live data.
      // This replaces getOnlineOrderStats() from lib/storage which read localStorage.
      const stats = computeOnlineOrderStats(liveOrders);
      setOnlineStats(stats);

    } catch (e) {
      console.error('[Admin] Failed to load orders from Supabase:', e);
    }
    // ── Issue analytics: fetch all today's issues ──────────────────────────────
    try {
      const allIssues = await getAllIssues();
      const midnight = todayMidnightIST();
      setTodayIssues(allIssues.filter(i => new Date(i.createdAt) >= midnight));
    } catch (e) {
      console.error('[Admin] Failed to load issues from Supabase:', e);
    }
    // ── Live table occupancy + waiter stats: derived from Supabase customer_tabs ──
    // waiter_name lives on customer_tabs (not orders), so we compute accountability
    // stats here by aggregating today's open and recently closed tabs per waiter.
    try {
      const todayMidnightTs = todayMidnightIST();
      const todayMidnightIso = todayMidnightTs.toISOString();
      const [apiTables, openTabs, closedTabs] = await Promise.all([
        getTablesApi(),
        // All open tabs regardless of age — we need these for occupancy + stale detection
        getTabsApi('open'),
        // Only today's closed tabs for waiter stats — avoids fetching all-time history
        getTabsApi('closed', todayMidnightIso),
      ]);

      // ── Waiter accountability from today's tabs ─────────────────────────────
      // openTabs are filtered to today (IST) for stats (but ALL open tabs used for occupancy)
      const todayTabs = [
        ...openTabs.filter(t => new Date(t.createdAt) >= todayMidnightTs),
        ...closedTabs,   // already filtered to today on the server
      ];
      const byWaiter = new Map<string, { accepted: number; served: number }>();
      todayTabs.forEach(t => {
        const name = t.waiterName || 'Unassigned';
        if (!byWaiter.has(name)) byWaiter.set(name, { accepted: 0, served: 0 });
        const w = byWaiter.get(name)!;
        w.accepted++;
        if (t.status === 'closed') w.served++;
      });
      const liveWaiterStats: WaiterStats[] = Array.from(byWaiter.entries()).map(([name, s]) => ({
        name,
        ordersAccepted:   s.accepted,
        ordersCancelled:  0,        // tabs are not cancelled — only closed
        ordersServed:     s.served,
        cancellationRate: 0,
      }));
      setWaiterStats(liveWaiterStats);
      // Build a map: tableId → first open tab (sessionStart + tabId for force-close)
      const openByTableId = new Map<string, { tabId: string; createdAt: string }>();
      openTabs.forEach(tab => {
        if (tab.tableId && !openByTableId.has(tab.tableId)) {
          openByTableId.set(tab.tableId, { tabId: tab.id, createdAt: tab.createdAt });
        }
      });
      const computed = apiTables.map(t => ({
        ...t,
        status:       openByTableId.has(t.id) ? ('occupied' as const) : ('available' as const),
        sessionStart: openByTableId.get(t.id)?.createdAt  ?? undefined,
        sessionTabId: openByTableId.get(t.id)?.tabId      ?? undefined,
      }));
      // Sort by numeric suffix so T1, T2, ... T10 appear in order
      computed.sort((a, b) => {
        const na = parseInt(a.id.match(/(\d+)$/)?.[1] ?? '0', 10);
        const nb = parseInt(b.id.match(/(\d+)$/)?.[1] ?? '0', 10);
        return na - nb;
      });
      setLiveTables(computed);
      // Store closed-tab count for EOD report completedTabs metric
      setClosedTabsCount(closedTabs.length);
    } catch (e) {
      console.error('[Admin] Failed to load live tables from Supabase:', e);
    }
    // ── Menu from Supabase (replaces getMenu() from localStorage) ─────────────
    try {
      const menuItems = await getMenuApi();
      setMenu(menuItems as MenuItem[]);
    } catch { /* keep existing menu if fetch fails */ }
    // ── Staff & settings from Supabase ──────────────────────────────────────────
    try {
      const [waiters, deliveryStaff, settings] = await Promise.all([
        listStaff('waiter'),
        listStaff('delivery'),
        getSettings(),
      ]);
      setStaffAccounts(waiters);
      setDeliveryAccounts(deliveryStaff);
      // PINs are intentionally NOT loaded into client state — server-side only.
      setSecSetup(settings.security_question
        ? { question: settings.security_question, setupAt: settings.security_setup_at ?? '' }
        : null
      );
    } catch (e) {
      console.error('[Admin] Failed to load settings/staff from Supabase:', e);
    }
    // waiterStats is derived from today's tabs inside the tables/tabs try-block above.
    // tableOccupancy requires per-table historical duration data — kept empty (section
    // is conditionally hidden when empty) until a dedicated analytics endpoint is added.
    setTableOccupancy([]);
  }, []);

  // ── Auth check ──
  useEffect(() => {
    const s = getSession('admin');
    if (!s) { router.replace('/admin/login'); return; }
    setAuthSession(s);
    setAuthChecked(true);
    // Load offer rules once on mount
    fetch('/api/offers')
      .then(r => r.json())
      .then((data: OfferRule[] | { error: string }) => {
        if (Array.isArray(data)) setOfferRules(data);
      })
      .catch(e => console.error('[admin] failed to load offers:', e));
    // ── Auto-load kitchen routing mode from DB (so admin sees real value, not React default) ──
    fetch('/api/admin/restaurant-config')
      .then(r => r.json())
      .then((d: { kitchen_mode?: string }) => {
        const km = d.kitchen_mode;
        if (km === 'ask' || km === 'printer' || km === 'kitchen_display') {
          setKitchenMode(km);
        }
      })
      .catch(e => console.error('[admin] failed to load kitchen mode:', e));
  }, [router]);

  // ── Configuration diagnostics — refetched every time the Staff/Settings tab
  // is opened (cheap read-only query) so an Admin who just changed something
  // in Vercel or the dashboard always sees the current effective value/source
  // without needing to reload the whole page.
  useEffect(() => {
    if (section !== 'staff') return;
    setConfigDiagErr('');
    fetch('/api/admin/config-diagnostics')
      .then(r => r.json())
      .then((d: { settings?: ConfigDiagEntry[]; secrets?: SecretDiagEntry[]; error?: string }) => {
        if (d.error) { setConfigDiagErr(d.error); return; }
        setConfigDiag({ settings: d.settings ?? [], secrets: d.secrets ?? [] });
      })
      .catch(e => setConfigDiagErr(e instanceof Error ? e.message : 'Failed to load configuration diagnostics'));
  }, [section]);

  useEffect(() => {
    if (!authChecked) return;
    refresh();
    const t1 = setInterval(refresh, 5000);
    const t2 = setInterval(() => { setClock(clockIST()); }, 1000);
    return () => { clearInterval(t1); clearInterval(t2); };
  }, [refresh, authChecked]);

  // ── Realtime: instant refresh on any order event (no wait for 5s poll) ──────
  // Covers: new online orders, status changes, completions, payments
  useRealtime(
    process.env.NEXT_PUBLIC_RESTAURANT_ID ?? 'rest_default',
    {
      order_created:          () => { void refresh(); },
      order_status_changed:   () => { void refresh(); },
      order_ready:            () => { void refresh(); },
      order_served:           () => { void refresh(); },
      order_out_for_delivery: () => { void refresh(); },
      order_delivered:        () => { void refresh(); },
      payment_completed:      () => { void refresh(); },
      order_issue_reported:   () => { void refresh(); },
      order_issue_escalated:  () => { void refresh(); },
      order_issue_resolved:   () => { void refresh(); },
    },
  );

  function adminLogout() {
    clearSession('admin');
    router.replace('/admin/login');
  }

  // ── Historical orders fetch — called when sales tab or orders date filter changes ──
  // Returns `since` ISO string for a given period label.
  function sinceForPeriod(period: 'today'|'yesterday'|'week'|'month'|'all'): string|undefined {
    const now = new Date();
    if (period === 'today')     return todayMidnightIST().toISOString();
    if (period === 'yesterday') {
      const d = todayMidnightIST(); d.setDate(d.getDate() - 1); return d.toISOString();
    }
    if (period === 'week')  { const d = new Date(now); d.setDate(d.getDate() - 7);  return d.toISOString(); }
    if (period === 'month') { const d = new Date(now); d.setDate(d.getDate() - 30); return d.toISOString(); }
    return undefined; // 'all' — no since filter
  }

  const fetchHistoricalOrders = useCallback(async (period: 'today'|'yesterday'|'week'|'month'|'all') => {
    setHistLoading(true);
    try {
      const since = sinceForPeriod(period);
      const data = await getOrders({ since, limit: 1000 });
      setHistOrders(data);
    } catch (e) {
      console.error('[Admin] Failed to load historical orders:', e);
    } finally {
      setHistLoading(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Trigger historical fetch whenever the sales tab or orders date filter changes
  useEffect(() => {
    if (!authChecked) return;
    void fetchHistoricalOrders(salesTab === 'today' ? 'today' : salesTab as 'week'|'month'|'all');
  }, [salesTab, authChecked, fetchHistoricalOrders]);

  useEffect(() => {
    if (!authChecked) return;
    void fetchHistoricalOrders(ordersDateFilter);
  }, [ordersDateFilter, authChecked, fetchHistoricalOrders]);

  // ─── Today stats (IST — avoids UTC midnight mismatch) ────────────────────
  // todayOrders: all non-cancelled, non-void orders for today
  const todayOrders   = orders.filter(o => isToday(o.timestamp) && !['cancelled','void'].includes(o.status));
  // todayRevenue: only COMPLETED orders — money actually collected, not in-progress
  const todayRevenue  = orders.filter(o => isToday(o.timestamp) && o.status==='completed').reduce((s,o)=>s+(o.total||0),0);
  const todayDiscount = todayOrders.reduce((s,o)=>s+(o.discount||0),0);
  const todayCancel   = orders.filter(o => o.status === 'cancelled' && isToday(o.timestamp));
  // Active tables: count of tables with status 'occupied' from live Supabase data.
  const activeTables  = liveTables.filter(t => t.status === 'occupied').length;
  // Pending count: include awaiting_waiter (new dine-in orders) AND pending (kitchen queue).
  // Dine-in orders start at 'awaiting_waiter', never 'pending', so omitting it means
  // every fresh dine-in order is silently missed in this count.
  const pendingCount  = orders.filter(o => ['awaiting_waiter', 'pending'].includes(o.status)).length;

  // ─── Issue analytics ────────────────────────────────────────────────────────
  const issueTotal      = todayIssues.length;
  const issueOpen       = todayIssues.filter(i => ['open', 'reserving'].includes(i.status)).length;
  const issueEscalated  = todayIssues.filter(i => i.escalated || i.status === 'escalated').length;
  const issueResolved   = todayIssues.filter(i => i.status === 'resolved').length;
  const issueRate       = todayOrders.length > 0 ? ((issueTotal / todayOrders.length) * 100).toFixed(1) : '0.0';

  // ─── Order actions ────────────────────────────────────────────────────────
  async function advance(id:string) {
    const o = orders.find(x=>x.id===id);
    if (!o) return;

    // Use type-aware status flow — each order type has its own lifecycle
    // delivery: prepared → out_for_delivery → delivered → completed
    // pickup:   prepared → served (customer collects at counter) → completed
    // dine-in:  awaiting_waiter → pending → … → served → completed
    const flow =
      o.type === 'delivery' ? STATUS_FLOW_DELIVERY :
      o.type === 'pickup'   ? STATUS_FLOW_PICKUP   :
      STATUS_FLOW_DINE_IN;

    // Find current position in the appropriate flow
    const curIdx = (flow as readonly string[]).indexOf(o.status);
    // Guard: unknown status (e.g. awaiting_waiter, cancelled) or already at final step
    if (curIdx === -1 || curIdx >= flow.length - 1) return;

    const next = flow[curIdx + 1];

    try {
      await apiUpdateOrderStatus(id, next, 'Admin');
      await refresh();
      // Close detail modal if open for this order (it will reopen with fresh data if needed)
      if (selOrder?.id === id) setSelOrder(null);
    } catch (e) {
      console.error('[Admin] advance() failed:', e);
      alert('Failed to advance order status. Please try again.');
    }
  }

  async function doCancel() {
    if (!cancelReason.trim()) { alert('Please enter a reason'); return; }
    try {
      await apiUpdateOrderStatus(cancelModal.orderId, 'cancelled', 'Admin', { cancelReason });
      setCancelModal({open:false,orderId:''}); setCancelReason('');
      await refresh();
      if (selOrder?.id === cancelModal.orderId) setSelOrder(null);
    } catch (e) {
      console.error('[Admin] doCancel() failed:', e);
      alert('This order could not be cancelled. Please try again.');
      setCancelModal({open:false,orderId:''}); setCancelReason('');
    }
  }

  async function doDiscount() {
    const amt = parseInt(discAmt);
    if (!amt || amt <= 0) { alert('Enter a valid amount'); return; }

    // Validate discount does not exceed the order total
    const targetOrder = orders.find(o => o.id === discountModal.orderId);
    if (targetOrder) {
      const maxDiscount = targetOrder.subtotal || targetOrder.total;
      if (amt > maxDiscount) {
        alert(`Discount (₹${amt}) cannot exceed the order subtotal (₹${maxDiscount}).`);
        return;
      }
    }

    // Verify admin PIN server-side — PIN never stored in client state
    setPinMsg('⏳ Verifying…');
    try {
      const verifyRes = await fetch('/api/auth/verify-pin', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ role: 'admin', pin: pinInput }),
      });
      const verifyResult = await verifyRes.json() as { ok: boolean; error?: string };
      if (!verifyResult.ok) { setPinMsg(`❌ ${verifyResult.error ?? 'Wrong PIN'}`); return; }
    } catch {
      setPinMsg('❌ Could not verify PIN. Try again.');
      return;
    }
    try {
      await apiApplyDiscount(discountModal.orderId, amt, discNote||'Owner discount');
      setDiscountModal({open:false,orderId:''}); setDiscAmt(''); setDiscNote(''); setPinInput(''); setPinMsg('');
      await refresh();
    } catch (e) {
      console.error('[Admin] doDiscount() failed:', e);
      alert('Failed to apply discount. Please try again.');
    }
  }

  // ─── Menu CRUD ────────────────────────────────────────────────────────────
  function addVariantRow() {
    setModalVariants(v => [...v, {name:'',price:''}]);
  }
  function removeVariantRow(idx:number) {
    setModalVariants(v => v.filter((_,i)=>i!==idx));
  }
  function updateVariantRow(idx:number, field:'name'|'price', val:string) {
    setModalVariants(v => v.map((r,i)=>i===idx?{...r,[field]:val}:r));
  }

  async function saveItem() {
    const it = menuModal.item;
    if (!it.name?.trim()) { alert('Item name required'); return; }
    // Validate variants
    const filled = modalVariants.filter(v=>v.name.trim()||v.price.trim());
    if (filled.length === 0) { alert('Add at least one pricing variant'); return; }
    for (const v of filled) {
      if (!v.name.trim()) { alert('Each variant needs a name (e.g. Half, Full, Regular)'); return; }
      const p = parseFloat(v.price);
      if (isNaN(p)||p<=0) { alert(`Invalid price for variant "${v.name}"`); return; }
    }
    const variants = filled.map(v=>({ name:v.name.trim(), price:parseFloat(v.price) }));
    const price = variants[0].price; // backward compat
    try {
      await saveMenuItemApi({
        id:        menuModal.isEdit ? it.id : undefined,
        name:      it.name     || '',
        category:  it.category || CATEGORIES[0],
        price,
        variants,
        desc:      it.desc     || '',
        img:       it.img      || '',
        badge:     it.badge    || '',
        available: it.available !== false,
      });
      setMenuModal({open:false,item:emptyItem(),isEdit:false});
      setModalVariants([{name:'',price:''}]);
      void refresh();
    } catch (e) {
      alert('Failed to save menu item: ' + (e instanceof Error ? e.message : String(e)));
    }
  }

  // ─── Image upload ─────────────────────────────────────────────────────────
  async function uploadMenuImage(file: File) {
    if (file.size > 5 * 1024 * 1024) { alert('Image must be under 5 MB'); return; }
    setImgUploading(true);
    try {
      const form = new FormData();
      form.append('file', file);
      const res  = await fetch('/api/menu/upload', { method: 'POST', body: form });
      const data = await res.json() as { ok: boolean; url?: string; error?: string };
      if (!res.ok || !data.url) throw new Error(data.error ?? 'Upload failed');
      setMenuModal(m => ({ ...m, item: { ...m.item, img: data.url } }));
    } catch (e) {
      alert('Upload failed: ' + (e instanceof Error ? e.message : String(e)));
    } finally {
      setImgUploading(false);
    }
  }

  // ─── Import complete menu catalog ─────────────────────────────────────────
  async function importMenuCatalog() {
    if (!confirm('Add all missing menu items from the complete catalog?\n\nExisting items will NOT be changed.')) return;
    setSeedingMenu(true);
    setSeedMsg('');
    try {
      const res  = await fetch('/api/menu/seed');
      const data = await res.json() as { ok: boolean; inserted?: number; skipped?: number; error?: string };
      if (!res.ok || !data.ok) throw new Error(data.error ?? 'Seed failed');
      setSeedMsg(`✅ ${data.inserted} items added, ${data.skipped} already existed.`);
      void refresh();
    } catch (e) {
      setSeedMsg('❌ ' + (e instanceof Error ? e.message : String(e)));
    } finally {
      setSeedingMenu(false);
    }
  }

  // ─── CSV template download ────────────────────────────────────────────────
  function downloadCsvTemplate() {
    const rows = [
      'name,category,description,badge,available,variants,image_url',
      '"Chicken Dum Biryani","Non Veg Biryani","Authentic Hyderabadi Dum Biryani","bestseller","true","Half:140|Full:260","https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=400"',
      '"Roti","Indian Breads","Soft whole wheat flatbread baked fresh","","true","Regular:10",""',
    ];
    const blob = new Blob([rows.join('\n')], { type: 'text/csv' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = 'menu-import-template.csv'; a.click();
    URL.revokeObjectURL(url);
  }

  // ─── CSV import ───────────────────────────────────────────────────────────
  async function importMenuFromCsv(file: File) {
    setCsvImportMsg('⏳ Importing…');
    try {
      const text  = await file.text();
      const lines = text.trim().split('\n').filter(l => l.trim());
      if (lines.length < 2) { setCsvImportMsg('❌ CSV has no data rows'); return; }
      const parseRow = (line: string): string[] => {
        const cols: string[] = []; let cur = '', inQ = false;
        for (const ch of line) {
          if (ch === '"') { inQ = !inQ; }
          else if (ch === ',' && !inQ) { cols.push(cur.trim()); cur = ''; }
          else { cur += ch; }
        }
        cols.push(cur.trim()); return cols;
      };
      const header = parseRow(lines[0]).map(h => h.toLowerCase());
      const idx = (k: string) => header.indexOf(k);
      if (idx('name') === -1 || idx('category') === -1) { setCsvImportMsg('❌ CSV must have "name" and "category" columns'); return; }
      let inserted = 0, failed = 0;
      for (let i = 1; i < lines.length; i++) {
        const c = parseRow(lines[i]);
        const name = c[idx('name')] ?? ''; const category = c[idx('category')] ?? '';
        if (!name || !category) continue;
        let variants: { name: string; price: number }[] = [];
        const vStr = c[idx('variants')] ?? '';
        if (vStr) { variants = vStr.split('|').map(v => { const [n,p] = v.split(':'); return { name: (n??'').trim(), price: parseFloat(p??'0') }; }).filter(v => v.name && !isNaN(v.price) && v.price > 0); }
        if (!variants.length) variants = [{ name: 'Regular', price: 0 }];
        try {
          await saveMenuItemApi({ name, category, desc: c[idx('description')]??'', badge: c[idx('badge')]??'', img: c[idx('image_url')]??'', available: (c[idx('available')]??'true').toLowerCase()!=='false', variants, price: variants[0].price });
          inserted++;
        } catch { failed++; }
      }
      setCsvImportMsg(`✅ Imported ${inserted} items${failed ? `, ${failed} failed` : ''}.`);
      void refresh();
    } catch (e) { setCsvImportMsg('❌ ' + (e instanceof Error ? e.message : String(e))); }
  }

  // ─── Sales data ───────────────────────────────────────────────────────────
  // histOrders is already server-scoped to the selected period; just strip non-revenue rows.
  const periodOrders = histOrders.filter(o => !['cancelled','void'].includes(o.status));
  const pTotal  = periodOrders.reduce((s,o)=>s+(o.total||0),0);
  const pGross  = periodOrders.reduce((s,o)=>s+(o.subtotal||o.total||0),0);
  const pDisc   = periodOrders.reduce((s,o)=>s+(o.discount||0),0);
  const pCount  = periodOrders.length;
  const pAvg    = pCount>0?Math.round(pTotal/pCount):0;

  // Payment breakdown
  const payMap:Record<string,{count:number;total:number}> = {};
  periodOrders.forEach(o=>{const k=o.payment||'other';if(!payMap[k])payMap[k]={count:0,total:0};payMap[k].count++;payMap[k].total+=o.total||0;});

  // Top items
  const itemMap:Record<string,{qty:number;revenue:number}> = {};
  periodOrders.forEach(o=>(o.items||[]).forEach(it=>{if(!itemMap[it.name])itemMap[it.name]={qty:0,revenue:0};itemMap[it.name].qty+=it.qty||1;itemMap[it.name].revenue+=(it.subtotal||(it.price*(it.qty||1)));}));
  const topItems = Object.entries(itemMap).sort((a,b)=>b[1].qty-a[1].qty).slice(0,10);

  // Breakdown rows — all hour/date bucketing uses IST to avoid UTC offset errors
  const breakdownRows = (() => {
    if (salesTab==='today') {
      const hrs:Record<number,{o:number;n:number;d:number}> = {};
      for(let h=10;h<=23;h++) hrs[h]={o:0,n:0,d:0};
      // getISTHour returns 0-23 in IST — never UTC
      periodOrders.forEach(o=>{const h=getISTHour(o.timestamp);if(hrs[h]){hrs[h].o++;hrs[h].n+=o.total||0;hrs[h].d+=o.discount||0;}});
      return Object.entries(hrs).filter(([,v])=>v.o>0).map(([h,v])=>({label:`${parseInt(h)>12?parseInt(h)-12:h}:00${parseInt(h)>=12?' PM':' AM'}`,orders:v.o,net:v.n,disc:v.d}));
    }
    if (salesTab==='week') {
      const days=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
      const map:Record<string,{o:number;n:number;d:number}> = {};
      // Build week map using IST dates
      for(let i=0;i<7;i++){
        const d=new Date(); d.setDate(d.getDate()-d.getDay()+i);
        const k=toISTDate(d); map[k]={o:0,n:0,d:0};
      }
      periodOrders.forEach(o=>{const k=toISTDate(o.timestamp);if(map[k]){map[k].o++;map[k].n+=o.total||0;map[k].d+=o.discount||0;}});
      return Object.entries(map).map(([k,v])=>({
        label:`${days[new Date(k+'T12:00:00+05:30').getDay()]} ${parseInt(k.slice(8),10)}`,
        orders:v.o,net:v.n,disc:v.d,
      }));
    }
    if (salesTab==='month') {
      const map:Record<string,{o:number;n:number;d:number}> = {};
      // getISTWeekLabel extracts IST day to avoid UTC-shifted week buckets
      periodOrders.forEach(o=>{ const k=`Week ${Math.ceil(parseInt(toISTDate(o.timestamp).slice(8),10)/7)}`;if(!map[k])map[k]={o:0,n:0,d:0};map[k].o++;map[k].n+=o.total||0;map[k].d+=o.discount||0;});
      return Object.entries(map).map(([k,v])=>({label:k,orders:v.o,net:v.n,disc:v.d}));
    }
    // 'all' — bucket by month in IST
    const map:Record<string,{o:number;n:number;d:number}> = {};
    periodOrders.forEach(o=>{const k=fmtMonthYear(o.timestamp);if(!map[k])map[k]={o:0,n:0,d:0};map[k].o++;map[k].n+=o.total||0;map[k].d+=o.discount||0;});
    return Object.entries(map).map(([k,v])=>({label:k,orders:v.o,net:v.n,disc:v.d}));
  })();

  // ─── Fraud data (uses histOrders so period filter applies) ───────────────
  const discountOrders  = histOrders.filter(o=>(o.discount||0)>0).sort((a,b)=>new Date(b.timestamp).getTime()-new Date(a.timestamp).getTime());
  const cancelledOrders = histOrders.filter(o=>o.status==='cancelled').sort((a,b)=>new Date(b.timestamp).getTime()-new Date(a.timestamp).getTime());
  const cancelRate      = histOrders.length>0?Math.round((cancelledOrders.length/histOrders.length)*100):0;
  const highDiscOrders  = discountOrders.filter(o=>(o.discount||0)/((o.subtotal||o.total)||1)>0.3);
  const todayDiscTotal  = orders.filter(o=>isToday(o.timestamp)).reduce((s,o)=>s+(o.discount||0),0);
  const alerts:string[] = [];
  if (cancelRate>20) alerts.push(`⚠️ High cancellation rate: ${cancelRate}% of all orders cancelled`);
  if (highDiscOrders.length>0) alerts.push(`⚠️ ${highDiscOrders.length} order(s) had discount >30% of bill — review now`);
  if (todayDiscTotal>2000) alerts.push(`⚠️ Today's total discounts: ₹${todayDiscTotal} — above normal threshold`);

  // ─── Filtered orders for table ────────────────────────────────────────────
  // orders from getOrders() is already newest-first (API uses order('created_at', { ascending: false })).
  // Previously used .slice(-60).reverse() which grabbed the OLDEST 60 then flipped them — now fixed to
  // take the most-recent 60 directly with .slice(0, 60) (no reverse needed).
  const filteredOrders = (orderFilter==='all' ? histOrders : histOrders.filter(o=>o.status===orderFilter)).slice(0, 200);
  const menuItems      = menuFilter==='All' ? menu : menu.filter(m=>m.category===menuFilter);

  // ─── Nav button ───────────────────────────────────────────────────────────
  const NavBtn = ({id,label}:{id:Section;label:string}) => (
    <button onClick={()=>setSection(id)} style={{padding:'0.55rem 1.25rem',border:'none',background:section===id?'#E65C00':'transparent',color:section===id?'white':'#bbb',fontWeight:700,cursor:'pointer',fontFamily:'Poppins,sans-serif',fontSize:'0.83rem',borderRadius:6,transition:'all .2s',whiteSpace:'nowrap' as const}}>{label}</button>
  );

  // ── Admin PIN change — verified server-side via /api/auth/change-pin ───────
  async function changeAdminPin() {
    setAdminPinMsg('');
    if (!adminPinOld) { setAdminPinMsg('❌ Enter your current PIN'); return; }
    if (adminNewPin.length < 4) { setAdminPinMsg('❌ New PIN must be at least 4 digits'); return; }
    if (adminNewPin !== adminNewPin2) { setAdminPinMsg('❌ New PINs do not match'); return; }
    setAdminPinMsg('⏳ Updating…');
    try {
      const res    = await fetch('/api/auth/change-pin', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ currentPin: adminPinOld, newPin: adminNewPin }),
      });
      const result = await res.json() as { ok: boolean; error?: string };
      if (!result.ok) {
        setAdminPinMsg(`❌ ${result.error ?? 'Failed to update PIN'}`);
        return;
      }
      setAdminPinMsg('✅ Admin PIN updated successfully!');
      setAdminPinOld(''); setAdminNewPin(''); setAdminNewPin2('');
      setTimeout(() => setAdminPinMsg(''), 4000);
    } catch (e) {
      setAdminPinMsg(`❌ ${e instanceof Error ? e.message : 'Failed to update PIN'}`);
    }
  }

  // ── Clear all orders ─────────────────────────────────────────────────────
  async function clearAllOrders() {
    if (!clearConfirm) { setClearMsg('❌ Please check the confirmation checkbox first.'); return; }
    if (clearPin.length < 4) { setClearMsg('❌ Enter your Admin PIN (4+ digits)'); return; }
    setClearBusy(true);
    setClearMsg('⏳ Clearing all orders…');
    try {
      const res = await fetch('/api/orders/clear', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin: clearPin }),
      });
      const result = await res.json() as { ok?: boolean; error?: string; message?: string };
      if (!result.ok) {
        setClearMsg(`❌ ${result.error ?? 'Failed to clear orders'}`);
      } else {
        setClearMsg('✅ All orders cleared successfully! Database is now empty.');
        setClearPin('');
        setClearConfirm(false);
        // Refresh the page data
        void refresh();
      }
    } catch (e) {
      setClearMsg(`❌ ${e instanceof Error ? e.message : 'Network error'}`);
    } finally {
      setClearBusy(false);
    }
  }

  // ── Preview count for targeted deletion ─────────────────────────────────
  async function fetchDelPreview() {
    setDelPreview(null);
    if (delMode === 'id') { setDelPreview(delOrderId.trim() ? 1 : 0); return; }
    try {
      const params = new URLSearchParams({ mode: delMode });
      if (delMode === 'date')  { params.set('date', delDate); }
      if (delMode === 'range') {
        params.set('dateFrom', delDateFrom);
        params.set('dateTo',   delDateTo);
        params.set('timeFrom', delTimeFrom);
        params.set('timeTo',   delTimeTo);
      }
      const r = await fetch(`/api/orders/delete-selective?${params}`);
      const j = await r.json() as { count?: number; error?: string };
      setDelPreview(j.count ?? null);
    } catch { setDelPreview(null); }
  }

  // ── Execute targeted deletion ─────────────────────────────────────────────
  async function executeDelSelective() {
    if (delPin.length < 4) { setDelMsg('❌ Enter Admin PIN (4+ digits)'); return; }
    if (delMode === 'id' && !delOrderId.trim()) { setDelMsg('❌ Enter an order ID'); return; }
    if (delMode === 'date' && !delDate) { setDelMsg('❌ Select a date'); return; }
    if (delMode === 'range' && (!delDateFrom || !delDateTo)) {
      setDelMsg('❌ Select both From and To dates'); return;
    }
    setDelBusy(true);
    setDelMsg('⏳ Deleting…');
    try {
      const body: Record<string, string> = { pin: delPin, mode: delMode };
      if (delMode === 'id')    body.orderId  = delOrderId.trim();
      if (delMode === 'date')  body.date     = delDate;
      if (delMode === 'range') {
        body.dateFrom = delDateFrom;
        body.dateTo   = delDateTo;
        body.timeFrom = delTimeFrom;
        body.timeTo   = delTimeTo;
      }
      const res = await fetch('/api/orders/delete-selective', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const result = await res.json() as { ok?: boolean; deleted?: number; message?: string; error?: string };
      if (!result.ok) {
        setDelMsg(`❌ ${result.error ?? 'Failed'}`);
      } else {
        setDelMsg(`✅ ${result.message}`);
        setDelOrderId(''); setDelDate(''); setDelDateFrom(''); setDelDateTo('');
        setDelPin(''); setDelPreview(null);
        void refresh();
      }
    } catch (e) {
      setDelMsg(`❌ ${e instanceof Error ? e.message : 'Network error'}`);
    } finally {
      setDelBusy(false);
    }
  }

  // ── Security question setup ───────────────────────────────────────────────
  async function saveSecurityQuestion() {
    setSecMsg('');
    if (!secQuestion) { setSecMsg('❌ Select a security question'); return; }
    if (!secAnswer.trim()) { setSecMsg('❌ Enter your answer'); return; }
    if (secAnswer.toLowerCase().trim() !== secAnswerConf.toLowerCase().trim()) {
      setSecMsg('❌ Answers do not match'); return;
    }
    try {
      await saveSettings({
        security_question: secQuestion,
        security_answer: secAnswer.toLowerCase().trim(),
        security_setup_at: new Date().toISOString(),
      });
      setSecSetup({ question: secQuestion, setupAt: new Date().toISOString() });
      setSecMsg('✅ Security question saved! You can now recover your PIN if forgotten.');
      setSecQuestion(''); setSecAnswer(''); setSecAnswerConf('');
      setTimeout(() => setSecMsg(''), 5000);
    } catch (e) {
      setSecMsg(`❌ ${e instanceof Error ? e.message : 'Failed to save security question'}`);
    }
  }

  // ── Table management actions ──────────────────────────────────────────────
  async function handleAddTable() {
    const name = tableForm.name.trim();
    if (!name) { setTableMsg('❌ Table name is required'); return; }
    const capacity = parseInt(tableForm.capacity) || 4;
    if (capacity < 1 || capacity > 50) { setTableMsg('❌ Capacity must be between 1 and 50'); return; }
    try {
      await createTableApi(name, capacity);
      setTableMsg(`✅ Table "${name}" added`);
      setTableForm({ name: '', capacity: '4' });
      await refresh();
      setTimeout(() => setTableMsg(''), 3000);
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Unknown error';
      setTableMsg(`❌ ${msg}`);
    }
  }

  async function handleSaveTableEdit(id: string) {
    const name = editTableVal.name.trim();
    if (!name) { setTableMsg('❌ Table name is required'); return; }
    const capacity = parseInt(editTableVal.capacity) || 4;
    try {
      await updateTableApi(id, { name, capacity });
      setTableMsg(`✅ Table updated`);
      setEditTableId('');
      await refresh();
      setTimeout(() => setTableMsg(''), 3000);
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Unknown error';
      setTableMsg(`❌ ${msg}`);
    }
  }

  async function handleDeleteTable(id: string, name: string) {
    if (!window.confirm(`Delete table "${name}"? This cannot be undone.`)) return;
    try {
      await deleteTableApi(id);
      setTableMsg(`✅ Table "${name}" deleted`);
      await refresh();
      setTimeout(() => setTableMsg(''), 3000);
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Unknown error';
      setTableMsg(`❌ ${msg}`);
    }
  }

  // Force-close a stale or ghost session from the admin panel.
  // Uses force=true to bypass the re_serve_required billing guard.
  async function handleForceCloseSession(tableId: string, tabId: string, tableName: string) {
    if (!window.confirm(
      `Force-close the session on "${tableName}"?\n\n` +
      `This is an admin override for stale or abandoned sessions.\n` +
      `The tab will be closed with payment method "admin_override".`,
    )) return;
    try {
      setTableMsg(`⏳ Force-closing session on ${tableName}…`);
      await forceCloseTab(tabId, tableId);
      setTableMsg(`✅ Session on "${tableName}" force-closed`);
      await refresh();
      setTimeout(() => setTableMsg(''), 4000);
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Unknown error';
      setTableMsg(`❌ Force-close failed: ${msg}`);
    }
  }

  // ── Staff management actions ─────────────────────────────────────────────
  async function addStaffAccount() {
    if (!staffForm.name.trim() || !staffForm.username.trim() || !staffForm.pin.trim()) {
      setStaffMsg('❌ All fields required'); return;
    }
    try {
      await addStaff({ name: staffForm.name, username: staffForm.username, pin: staffForm.pin, role: 'waiter' });
      setStaffMsg(`✅ Account created for ${staffForm.name}`);
      setStaffForm({ name: '', username: '', pin: '' });
      void refresh();
    } catch (e) {
      setStaffMsg(`❌ ${e instanceof Error ? e.message : 'Failed to create account'}`);
    }
  }

  async function addDeliveryAccount() {
    if (!deliveryForm.name.trim() || !deliveryForm.username.trim() || !deliveryForm.pin.trim()) {
      setDeliveryMsg('❌ All fields required'); return;
    }
    try {
      await addStaff({ name: deliveryForm.name, username: deliveryForm.username, pin: deliveryForm.pin, role: 'delivery' });
      setDeliveryMsg(`✅ Account created for ${deliveryForm.name}`);
      setDeliveryForm({ name: '', username: '', pin: '' });
      void refresh();
    } catch (e) {
      setDeliveryMsg(`❌ ${e instanceof Error ? e.message : 'Failed to create account'}`);
    }
  }

  async function saveKitchenPinFn() {
    if (kitchenPin.length < 4) { setKitchenPinMsg('❌ PIN must be 4+ digits'); return; }
    try {
      await saveSetting('kitchen_pin', kitchenPin);
      setKitchenPinMsg('✅ Kitchen PIN updated');
      setTimeout(() => setKitchenPinMsg(''), 3000);
    } catch (e) {
      setKitchenPinMsg(`❌ ${e instanceof Error ? e.message : 'Failed to update PIN'}`);
    }
  }

  async function saveManagerPinFn() {
    if (managerPin.length < 4) { setManagerPinMsg('❌ PIN must be 4+ digits'); return; }
    try {
      await saveSetting('manager_pin', managerPin);
      setManagerPinMsg('✅ Manager PIN updated');
      setTimeout(() => setManagerPinMsg(''), 3000);
    } catch (e) {
      setManagerPinMsg(`❌ ${e instanceof Error ? e.message : 'Failed to update PIN'}`);
    }
  }

  // ─────────────────────── SPIN & WIN HANDLERS ─────────────────────────────────

  const SPIN_FORM_RESET: Omit<SpinRewardRow,'id'> = {
    label:'', reward_type:'percent', reward_value:10, weight:1,
    min_next_order:0, expires_days:30, active:true, sort_order:0,
    max_discount:null, daily_win_limit:null, monthly_win_limit:null,
    bogo_eligible_items:[], bogo_eligible_categories:[], max_free_item_value:null,
    archived:false, daily_usage:0,
  };

  async function handleSpinToggleActive(r: SpinRewardRow) {
    const next = !r.active;
    setSpinTogglingIds(prev => new Set([...prev, r.id]));
    try {
      const res = await fetch(`/api/admin/spin-rewards/${r.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ active: next }),
      });
      const d = await res.json() as { ok?: boolean; error?: string };
      if (d.ok) {
        setSpinRewards(prev => prev.map(x => x.id === r.id ? { ...x, active: next } : x));
        setSpinMsg(`${next ? '✅' : '⭕'} "${r.label}" ${next ? 'activated' : 'deactivated'}`);
      } else {
        setSpinMsg(`❌ ${d.error ?? 'Update failed'}`);
      }
    } catch {
      setSpinMsg('❌ Network error');
    } finally {
      setSpinTogglingIds(prev => { const s = new Set(prev); s.delete(r.id); return s; });
      setTimeout(() => setSpinMsg(''), 3000);
    }
  }

  function handleSpinEditStart(r: SpinRewardRow) {
    setEditingRewardId(r.id);
    setSpinRewardForm({
      label: r.label, reward_type: r.reward_type, reward_value: r.reward_value,
      weight: r.weight, min_next_order: r.min_next_order, expires_days: r.expires_days,
      active: r.active, sort_order: r.sort_order,
      max_discount: r.max_discount, daily_win_limit: r.daily_win_limit,
      monthly_win_limit: r.monthly_win_limit,
      bogo_eligible_items: r.bogo_eligible_items ?? [],
      bogo_eligible_categories: r.bogo_eligible_categories ?? [],
      max_free_item_value: r.max_free_item_value,
      archived: r.archived, daily_usage: r.daily_usage,
    });
    setTimeout(() => {
      document.getElementById('spin-reward-form')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 80);
  }

  async function handleSpinDeleteOrArchive(r: SpinRewardRow) {
    const hasKnownUsage = (r.daily_usage ?? 0) > 0;
    const msg = hasKnownUsage
      ? `"${r.label}" has been issued to customers today.\n\nIt will be ARCHIVED (hidden from wheel, existing coupons remain valid) rather than deleted.\n\nContinue?`
      : `Delete "${r.label}"?\n\n• If it has any spin/coupon history → will be archived\n• If unused → permanently deleted\n\nContinue?`;
    if (!confirm(msg)) return;
    try {
      const res = await fetch(`/api/admin/spin-rewards/${r.id}`, { method: 'DELETE' });
      const d = await res.json() as { ok?: boolean; action?: string; error?: string };
      if (d.ok) {
        setSpinRewards(prev => prev.filter(x => x.id !== r.id));
        setSpinMsg(d.action === 'archived'
          ? `📦 "${r.label}" archived (has history — existing coupons unaffected).`
          : `🗑 "${r.label}" permanently deleted.`);
      } else {
        setSpinMsg(`❌ ${d.error ?? 'Could not remove'}`);
      }
    } catch {
      setSpinMsg('❌ Network error');
    }
    setTimeout(() => setSpinMsg(''), 4000);
  }

  async function handleSpinFormSave() {
    const f = spinRewardForm;
    if (!f.label.trim()) { setSpinMsg('❌ Label is required'); return; }
    if (f.reward_type === 'percent') {
      if (f.reward_value <= 0 || f.reward_value > 100) { setSpinMsg('❌ Percent value must be 1–100'); return; }
      if (!f.max_discount || f.max_discount <= 0) { setSpinMsg('❌ Maximum Discount (₹) is required for percent rewards'); setTimeout(() => setSpinMsg(''), 4000); return; }
    }
    if (f.reward_type === 'fixed' && f.reward_value <= 0) { setSpinMsg('❌ Fixed amount must be > 0'); return; }
    if (f.weight < 0) { setSpinMsg('❌ Weight cannot be negative'); return; }

    // Duplicate label guard (new rewards only, or if label changed)
    const editingLabel = editingRewardId ? spinRewards.find(x => x.id === editingRewardId)?.label : undefined;
    if (!editingRewardId || editingLabel?.toLowerCase() !== f.label.trim().toLowerCase()) {
      const dupe = spinRewards.find(x =>
        !x.archived &&
        x.id !== editingRewardId &&
        x.label.toLowerCase() === f.label.trim().toLowerCase()
      );
      if (dupe) { setSpinMsg(`❌ A reward named "${dupe.label}" already exists. Edit it instead.`); setTimeout(() => setSpinMsg(''), 5000); return; }
    }

    setSpinMsg('⏳ Saving…');
    const payload = {
      label: f.label.trim(), reward_type: f.reward_type, reward_value: f.reward_value,
      weight: f.weight, min_next_order: f.min_next_order, expires_days: f.expires_days,
      active: f.active, sort_order: f.sort_order,
      max_discount: f.max_discount, daily_win_limit: f.daily_win_limit,
      monthly_win_limit: f.monthly_win_limit,
      bogo_eligible_items: f.bogo_eligible_items,
      bogo_eligible_categories: f.bogo_eligible_categories,
      max_free_item_value: f.max_free_item_value,
      archived: false,
    };
    try {
      const url = editingRewardId ? `/api/admin/spin-rewards/${editingRewardId}` : '/api/admin/spin-rewards';
      const method = editingRewardId ? 'PATCH' : 'POST';
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      const d = await res.json() as { ok?: boolean; error?: string };
      if (d.ok) {
        const updated = await fetch('/api/admin/spin-rewards').then(x => x.json()) as SpinRewardRow[];
        setSpinRewards(updated);
        setEditingRewardId(null);
        setSpinRewardForm(SPIN_FORM_RESET);
        setSpinMsg(editingRewardId ? '✅ Reward updated!' : '✅ Reward added!');
      } else {
        setSpinMsg(`❌ ${d.error ?? 'Error'}`);
      }
    } catch {
      setSpinMsg('❌ Network error');
    }
    setTimeout(() => setSpinMsg(''), 3000);
  }

  async function handleSpinImportFile(file: File) {
    setSpinImportBusy(true);
    setSpinMsg('⏳ Parsing CSV…');
    try {
      const text = await file.text();
      // Parse CSV (minimal, handles quoted fields)
      const lines = text.trim().split(/\r?\n/).filter(l => l.trim());
      if (lines.length < 2) { setSpinMsg('❌ CSV must have a header row and at least one data row'); setSpinImportBusy(false); return; }
      const parseRow = (line: string): string[] => {
        const cols: string[] = []; let cur = '', inQ = false;
        for (const ch of line) {
          if (ch === '"') { inQ = !inQ; }
          else if (ch === ',' && !inQ) { cols.push(cur.trim()); cur = ''; }
          else { cur += ch; }
        }
        cols.push(cur.trim()); return cols;
      };
      const header = parseRow(lines[0]).map(h => h.toLowerCase().replace(/^"|"$/g, '').trim());
      const csvRows: Record<string, string>[] = lines.slice(1).map(line => {
        const cols = parseRow(line);
        const obj: Record<string, string> = {};
        header.forEach((h, i) => { obj[h] = (cols[i] ?? '').replace(/^"|"$/g, '').trim(); });
        return obj;
      });

      const res = await fetch('/api/admin/spin-rewards/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rows: csvRows, confirm: false }),
      });
      const d = await res.json() as SpinImportPreview & { error?: string };
      if (d.error) { setSpinMsg(`❌ ${d.error}`); setSpinImportBusy(false); return; }
      setSpinImportRows(csvRows);
      setSpinImportPreview(d);
      setSpinMsg('');
    } catch (e) {
      setSpinMsg(`❌ ${e instanceof Error ? e.message : 'Parse error'}`);
    } finally {
      setSpinImportBusy(false);
    }
  }

  async function handleSpinImportConfirm() {
    if (!spinImportPreview || spinImportPreview.errorCount > 0) return;
    setSpinImportBusy(true);
    try {
      const res = await fetch('/api/admin/spin-rewards/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rows: spinImportRows, confirm: true }),
      });
      const d = await res.json() as { ok?: boolean; error?: string; created?: number; updated?: number };
      if (d.ok) {
        const updated = await fetch('/api/admin/spin-rewards').then(x => x.json()) as SpinRewardRow[];
        setSpinRewards(updated);
        setSpinImportPreview(null);
        setSpinImportRows([]);
        setSpinMsg(`✅ Import complete: ${d.created} created, ${d.updated} updated.`);
        setTimeout(() => setSpinMsg(''), 4000);
      } else {
        setSpinMsg(`❌ ${d.error ?? 'Import failed'}`);
        setTimeout(() => setSpinMsg(''), 5000);
      }
    } catch {
      setSpinMsg('❌ Network error during import');
      setTimeout(() => setSpinMsg(''), 4000);
    } finally {
      setSpinImportBusy(false);
    }
  }

  function handleSpinExportCsv() {
    window.location.href = '/api/admin/spin-rewards?export=csv';
  }

  function downloadSpinCsvTemplate() {
    const csvLines = [
      'id,label,type,value,weight,max_discount,daily_win_limit,min_next_order,expires_days,active',
      ',Better Luck Next Time,no_reward,0,10,,0,0,30,true',
      ',3% OFF,percent,3,25,30,0,150,30,true',
      ',5% OFF,percent,5,20,50,0,250,30,true',
      ',7% OFF,percent,7,15,70,0,350,30,true',
      ',10% OFF,percent,10,12,100,10,500,30,true',
      ',15% OFF,percent,15,8,150,5,1000,30,true',
      ',20% OFF JACKPOT,percent,20,4,200,2,2000,14,true',
      ',30% OFF MEGA JACKPOT,percent,30,1,300,1,3000,14,true',
    ];
    const blob = new Blob([csvLines.join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'spin-rewards-template.csv'; a.click();
    URL.revokeObjectURL(url);
  }

  // ─────────────────────────────── RENDER ────────────────────────────────────
  if (!authChecked) {
    return (
      <div style={{ minHeight:'100vh', background:'linear-gradient(135deg,#faf8f3,#f5f0e8)', display:'flex', alignItems:'center', justifyContent:'center' }}>
        <div style={{ textAlign:'center', color:'#888' }}>
          <div style={{ fontSize:'2rem', marginBottom:'0.5rem' }}>📊</div>
          <div>Loading Admin Dashboard…</div>
        </div>
      </div>
    );
  }

  return (
    <div style={{minHeight:'100vh',background:'linear-gradient(135deg,#faf8f3,#f5f0e8)',fontFamily:'Poppins,sans-serif'}}>

      {/* Header */}
      <div style={{background:'linear-gradient(135deg,#1A0800,#2D0F00)',color:'white',padding:'0.75rem 1.25rem',paddingTop:'max(0.75rem, env(safe-area-inset-top, 0px))',position:'sticky',top:0,zIndex:200,boxShadow:'0 4px 16px rgba(0,0,0,0.3)'}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:'0.5rem',flexWrap:'wrap'}}>
          <div style={{display:'flex',alignItems:'center',gap:'0.6rem',minWidth:0,flexShrink:1}}>
            <span style={{fontSize:'1.4rem',flexShrink:0}}>📊</span>
            <div style={{minWidth:0}}>
              <div style={{fontFamily:"'Playfair Display',serif",fontSize:'1.05rem',fontWeight:900,whiteSpace:'nowrap'}}>Admin Dashboard</div>
              <div style={{fontSize:'0.68rem',color:'#F9A826',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>Foodie Lover — Owner Control Panel</div>
            </div>
          </div>
          <div style={{display:'flex',alignItems:'center',gap:'0.35rem',overflowX:'auto',WebkitOverflowScrolling:'touch',scrollbarWidth:'none',flexShrink:0,maxWidth:'calc(100vw - 180px)',paddingBottom:2}}>
            {alerts.length>0 && <div style={{background:'#ef4444',color:'white',padding:'0.25rem 0.6rem',borderRadius:20,fontSize:'0.72rem',fontWeight:700,cursor:'pointer',whiteSpace:'nowrap',flexShrink:0}} onClick={()=>setSection('fraud')}>🚨 {alerts.length}</div>}
            <button onClick={()=>setSection('staff')} style={{...btn('#374151'),padding:'0.3rem 0.6rem',fontSize:'0.72rem',whiteSpace:'nowrap',flexShrink:0}}>🔐 Staff</button>
            <button onClick={adminLogout} style={{...btn('#7f1d1d'),padding:'0.3rem 0.6rem',fontSize:'0.72rem',whiteSpace:'nowrap',flexShrink:0}}>🚪 Logout</button>
            <div style={{textAlign:'right',flexShrink:0}}>
              <div style={{fontWeight:700,fontSize:'0.8rem',whiteSpace:'nowrap'}}>{clock.date}</div>
              <div style={{fontSize:'0.72rem',color:'#F9A826',whiteSpace:'nowrap'}}>{clock.time}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <div style={{background:'#1A0800',display:'flex',gap:'0.2rem',padding:'0.35rem 1rem',overflowX:'auto',WebkitOverflowScrolling:'touch',scrollbarWidth:'none'}}>
        <NavBtn id="overview" label="📋 Overview"         />
        <NavBtn id="orders"   label="🧾 Orders"           />
        <NavBtn id="sales"    label="📊 Sales Report"     />
        <NavBtn id="finance"  label="💰 Finance"          />
        <NavBtn id="menu"     label="🍽️ Menu Management" />
        <NavBtn id="offers"   label="🎁 Offers"           />
        <NavBtn id="tables"   label="🪑 Tables"           />
        <NavBtn id="fraud"    label="🔍 Transparency"     />
        <NavBtn id="staff"         label="👥 Staff"           />
        <NavBtn id="email"         label="📧 Email"           />
        <NavBtn id="kitchen"       label="🔥 Kitchen"         />
        <NavBtn id="feedback"      label="⭐ Feedback"        />
        <NavBtn id="spin"          label="🎡 Spin & Win"      />
        <NavBtn id="rewards_audit" label="🎟 Rewards Audit"   />
      </div>

      <div style={{maxWidth:'1400px',margin:'0 auto',padding:'1rem 1rem 1.5rem',paddingLeft:'max(1rem, env(safe-area-inset-left,0px))',paddingRight:'max(1rem, env(safe-area-inset-right,0px))'}}>

        {/* ═══════════ OVERVIEW ═══════════ */}
        {section==='overview' && <>
          {/* Dine-in stats */}
          <div style={{fontSize:'0.7rem',fontWeight:700,color:'#888',textTransform:'uppercase',letterSpacing:1,marginBottom:'0.5rem'}}>🍽️ Dine-In &amp; General</div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(165px,1fr))',gap:'1rem',marginBottom:'1.25rem'}}>
            {[
              {icon:'📋',val:todayOrders.length,   label:"Today's Orders",   color:'#E65C00'},
              {icon:'💰',val:`₹${todayRevenue}`,    label:'Net Revenue',      color:'#E65C00'},
              {icon:'🏷️',val:`₹${todayDiscount}`,  label:'Discounts Given',  color:'#16a34a'},
              {icon:'❌',val:todayCancel.length,    label:'Cancelled Today',  color:'#ef4444'},
              {icon:'🪑',val:activeTables,          label:'Active Tables',    color:'#3b82f6'},
              {icon:'⏳',val:pendingCount,          label:'Awaiting / Queued',color:'#f59e0b'},
            ].map(s=>(
              <div key={s.label} style={{background:'white',padding:'1.1rem',borderRadius:12,boxShadow:'0 2px 8px rgba(0,0,0,0.08)',borderLeft:`4px solid ${s.color}`}}>
                <div style={{fontSize:'1.5rem',marginBottom:'0.25rem'}}>{s.icon}</div>
                <div style={{fontSize:'1.4rem',fontWeight:900,color:s.color}}>{s.val}</div>
                <div style={{color:'#888',fontSize:'0.76rem'}}>{s.label}</div>
              </div>
            ))}
          </div>

          {/* Online order stats */}
          <div style={{fontSize:'0.7rem',fontWeight:700,color:'#888',textTransform:'uppercase',letterSpacing:1,marginBottom:'0.5rem'}}>📦 Online Orders (Today)</div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(165px,1fr))',gap:'1rem',marginBottom:'1.5rem'}}>
            {[
              {icon:'📦',val:onlineStats?.todayTotal    ?? 0, label:'Online Orders Today', color:'#2563eb'},
              {icon:'🏪',val:onlineStats?.todayPickup   ?? 0, label:'Pickup Orders',       color:'#0891b2'},
              {icon:'🚗',val:onlineStats?.todayDelivery ?? 0, label:'Delivery Orders',     color:'#7c3aed'},
              {icon:'💵',val:`₹${onlineStats?.todayRevenue ?? 0}`, label:'Online Revenue', color:'#16a34a'},
              {icon:'⏳',val:onlineStats?.pendingOnline ?? 0, label:'Pending Online',      color:'#f59e0b'},
            ].map(s=>(
              <div key={s.label} style={{background:'white',padding:'1.1rem',borderRadius:12,boxShadow:'0 2px 8px rgba(0,0,0,0.08)',borderLeft:`4px solid ${s.color}`}}>
                <div style={{fontSize:'1.5rem',marginBottom:'0.25rem'}}>{s.icon}</div>
                <div style={{fontSize:'1.4rem',fontWeight:900,color:s.color}}>{s.val}</div>
                <div style={{color:'#888',fontSize:'0.76rem'}}>{s.label}</div>
              </div>
            ))}
          </div>

          {/* Issue analytics */}
          <div style={{fontSize:'0.7rem',fontWeight:700,color:'#888',textTransform:'uppercase',letterSpacing:1,marginBottom:'0.5rem'}}>🚨 Order Issues (Today)</div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(165px,1fr))',gap:'1rem',marginBottom:'1.5rem'}}>
            {[
              {icon:'🚨', val: issueTotal,    label:'Issues Reported',   color:'#dc2626'},
              {icon:'🔓', val: issueOpen,     label:'Unresolved Now',     color:'#f97316'},
              {icon:'⬆️', val: issueEscalated,label:'Escalated',          color:'#7f1d1d'},
              {icon:'✅', val: issueResolved, label:'Resolved Today',     color:'#16a34a'},
              {icon:'📊', val:`${issueRate}%`,label:'Issue Rate',          color:'#8b5cf6'},
            ].map(s=>(
              <div key={s.label} style={{background:'white',padding:'1.1rem',borderRadius:12,boxShadow:'0 2px 8px rgba(0,0,0,0.08)',borderLeft:`4px solid ${s.color}`}}>
                <div style={{fontSize:'1.5rem',marginBottom:'0.25rem'}}>{s.icon}</div>
                <div style={{fontSize:'1.4rem',fontWeight:900,color:s.color}}>{s.val}</div>
                <div style={{color:'#888',fontSize:'0.76rem'}}>{s.label}</div>
              </div>
            ))}
          </div>

          {/* Active issues detail — only when issues exist */}
          {issueOpen > 0 && (
            <div style={{...card('#dc2626'), marginBottom:'1.5rem'}}>
              <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:'1.05rem',fontWeight:700,marginBottom:'0.85rem',color:'#1A0800'}}>🚨 Active Issues Requiring Attention</h2>
              <div style={{display:'flex',flexDirection:'column',gap:'0.5rem'}}>
                {todayIssues.filter(i => ['open','reserving','escalated'].includes(i.status)).map(issue => {
                  const relOrd = orders.find(o => o.id === issue.orderId);
                  return (
                    <div key={issue.id} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'0.6rem 0.85rem',background:issue.escalated ? '#fef2f2' : '#fff7ed',borderRadius:8,border:`1px solid ${issue.escalated ? '#fecaca' : '#fed7aa'}`,flexWrap:'wrap',gap:'0.5rem'}}>
                      <div>
                        <div style={{fontWeight:800,fontSize:'0.82rem',color:'#1A0800'}}>
                          Order #{relOrd?.orderNum || issue.orderId.slice(-6)}
                          {relOrd?.customerName && <span style={{fontWeight:400,color:'#888',marginLeft:'0.3rem'}}>— {relOrd.customerName}</span>}
                          {issue.escalated && <span style={{marginLeft:'0.5rem',background:'#dc2626',color:'white',borderRadius:4,padding:'0.05rem 0.35rem',fontSize:'0.65rem',fontWeight:800}}>ESCALATED</span>}
                        </div>
                        <div style={{fontSize:'0.7rem',color:'#64748b',marginTop:'0.1rem'}}>
                          Reported by: {issue.reportedBy} · Attempt #{issue.retryCount} · Status: {issue.status} · {fmtTime(issue.reportedAt)}
                        </div>
                      </div>
                      <span style={{fontSize:'0.72rem',fontWeight:700,padding:'0.2rem 0.55rem',borderRadius:20,background: issue.status === 'reserving' ? '#dbeafe' : issue.escalated ? '#fee2e2' : '#fff7ed',color: issue.status === 'reserving' ? '#1d4ed8' : issue.escalated ? '#dc2626' : '#c2410c'}}>
                        {issue.status === 'reserving' ? '🔄 Re-serving' : issue.escalated ? '🚨 Escalated' : '⏳ Open'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Table map — live status from Supabase customer_tabs */}
          <div style={card()}>
            <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:'1.05rem',fontWeight:700,marginBottom:'0.9rem',color:'#1A0800'}}>🪑 Table Overview</h2>
            {liveTables.length === 0 && (
              <div style={{fontSize:'0.8rem',color:'#888',textAlign:'center',padding:'1rem'}}>Loading tables…</div>
            )}
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(75px,1fr))',gap:'0.5rem'}}>
              {liveTables.map(t=>{
                const sessionMins = t.sessionStart
                  ? Math.floor((Date.now()-new Date(t.sessionStart).getTime())/60000)
                  : null;
                // Sessions > 4 hours are flagged as stale (likely forgotten / abandoned)
                const STALE_MINS = 240;
                const isStale   = sessionMins !== null && sessionMins >= STALE_MINS;
                const color =
                  t.status === 'available' ? '#10b981' :
                  isStale                  ? '#dc2626' :  // stale → red
                                             '#f97316';   // normal occupied → orange
                const bg =
                  t.status === 'available' ? '#d1fae5' :
                  isStale                  ? '#fee2e2' :  // stale → light red
                                             '#fed7aa';   // normal occupied → light orange
                // Format duration: "23m", "1h 5m", "17h 8m"
                const fmtDuration = (m: number) =>
                  m < 60 ? `${m}m` : `${Math.floor(m/60)}h ${m%60}m`;
                return (
                  <div key={t.id} style={{background:bg,border:`2px solid ${color}`,borderRadius:8,padding:'0.55rem',textAlign:'center'}}>
                    <div style={{fontWeight:800,fontSize:'0.88rem',color:'#1A0800'}}>{t.name}</div>
                    <div style={{fontSize:'0.58rem',color:t.status==='available'?'#065f46':color,fontWeight:700,textTransform:'uppercase'}}>
                      {isStale ? '⚠️ STALE' : t.status}
                    </div>
                    {sessionMins!==null&&t.status==='occupied'&&(
                      <div style={{fontSize:'0.56rem',color:isStale?'#dc2626':'#E65C00',fontWeight:700}}>
                        {fmtDuration(sessionMins)}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            {/* Stale session legend */}
            {liveTables.some(t => {
              const m = t.sessionStart ? Math.floor((Date.now()-new Date(t.sessionStart).getTime())/60000) : 0;
              return m >= 240 && t.status === 'occupied';
            }) && (
              <div style={{marginTop:'0.6rem',fontSize:'0.68rem',color:'#dc2626',fontWeight:600,textAlign:'center'}}>
                ⚠️ Red = session open &gt;4h — go to Tables tab to force-close
              </div>
            )}
          </div>

          {/* End of Day Report — derived from live Supabase orders */}
          {(() => {
            const todayOrdsFull = orders.filter(o => isToday(o.timestamp));
            const eod = {
              totalOrders:   todayOrdsFull.filter(o => o.status === 'completed').length,
              totalRevenue:  Math.round(todayOrdsFull.filter(o => !['cancelled','void'].includes(o.status)).reduce((s,o)=>s+(o.total||0),0)),
              avgOrderValue: (() => {
                const done = todayOrdsFull.filter(o => o.status === 'completed');
                return done.length > 0 ? Math.round(done.reduce((s,o)=>s+(o.total||0),0)/done.length) : 0;
              })(),
              completedTabs: closedTabsCount, // fetched in refresh() via getTabsApi('closed', today)
              discountsTotal:Math.round(todayOrdsFull.reduce((s,o)=>s+(o.discount||0),0)),
              voidedOrders:  todayOrdsFull.filter(o => o.status === 'void').length,
              topItems: (() => {
                const map: Record<string,{name:string;qty:number}> = {};
                todayOrdsFull.filter(o=>!['cancelled','void'].includes(o.status))
                  .forEach(o=>(o.items||[]).forEach(it=>{if(!map[it.name])map[it.name]={name:it.name,qty:0};map[it.name].qty+=it.qty||1;}));
                return Object.values(map).sort((a,b)=>b.qty-a.qty).slice(0,5);
              })(),
            };
            return (
              <div style={card('#16a34a')}>
                <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:'1.05rem',fontWeight:700,marginBottom:'0.85rem',color:'#1A0800'}}>📊 End-of-Day Report — Today</h2>
                <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(130px,1fr))',gap:'0.7rem',marginBottom:'0.75rem'}}>
                  {[
                    {icon:'🧾',val:eod.totalOrders,label:'Orders Completed',color:'#16a34a'},
                    {icon:'💰',val:`₹${eod.totalRevenue}`,label:'Total Revenue',color:'#E65C00'},
                    {icon:'📊',val:`₹${eod.avgOrderValue}`,label:'Avg Order Value',color:'#8b5cf6'},
                    {icon:'✅',val:eod.completedTabs,label:'Closed Tabs',color:'#3b82f6'},
                    {icon:'🏷️',val:`₹${eod.discountsTotal}`,label:'Discounts',color:'#f59e0b'},
                    {icon:'🚫',val:eod.voidedOrders,label:'Voided Orders',color:'#ef4444'},
                  ].map(s=>(
                    <div key={s.label} style={{background:'white',border:`1px solid ${s.color}30`,borderRadius:10,padding:'0.75rem',textAlign:'center',borderLeft:`3px solid ${s.color}`}}>
                      <div style={{fontSize:'1.1rem',marginBottom:'0.15rem'}}>{s.icon}</div>
                      <div style={{fontSize:'1.1rem',fontWeight:900,color:s.color}}>{s.val}</div>
                      <div style={{fontSize:'0.62rem',color:'#999'}}>{s.label}</div>
                    </div>
                  ))}
                </div>
                {eod.topItems.length>0 && (
                  <div>
                    <div style={{fontSize:'0.78rem',fontWeight:700,color:'#16a34a',marginBottom:'0.35rem'}}>🏆 Today&apos;s Top Items</div>
                    <div style={{display:'flex',gap:'0.4rem',flexWrap:'wrap'}}>
                      {eod.topItems.map((item,i)=>(
                        <div key={i} style={{background:'#f0fdf4',borderRadius:20,padding:'0.2rem 0.7rem',fontSize:'0.75rem',color:'#064e3b',fontWeight:600}}>
                          {item.name} <span style={{color:'#E65C00',fontWeight:700}}>×{item.qty}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })()}

          {/* Table Occupancy Analytics */}
          {tableOccupancy.length > 0 && (
            <div style={card('#3b82f6')}>
              <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:'1.05rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>🪑 Table Occupancy Analytics</h2>
              <div style={{overflowX:'auto'}}>
                <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.82rem'}}>
                  <thead><tr style={{background:'#eff6ff'}}>
                    {['Table','Sessions','Avg Time','Revenue','Last Used'].map(h=>(
                      <th key={h} style={{padding:'0.48rem 0.75rem',textAlign:'left',fontSize:'0.7rem',fontWeight:700,color:'#1d4ed8',textTransform:'uppercase'}}>{h}</th>
                    ))}
                  </tr></thead>
                  <tbody>
                    {tableOccupancy.slice(0,10).map((t,i)=>(
                      <tr key={t.tableId} style={{borderBottom:'1px solid #dbeafe',background:i%2?'#f0f9ff':'white'}}>
                        <td style={{padding:'0.48rem 0.75rem',fontWeight:700,color:'#1A0800'}}>{t.tableId}</td>
                        <td style={{padding:'0.48rem 0.75rem',fontWeight:700,color:'#3b82f6'}}>{t.totalSessions}</td>
                        <td style={{padding:'0.48rem 0.75rem'}}>{t.avgMinutes} min</td>
                        <td style={{padding:'0.48rem 0.75rem',fontWeight:700,color:'#16a34a'}}>₹{t.totalRevenue}</td>
                        <td style={{padding:'0.48rem 0.75rem',color:'#888',fontSize:'0.75rem'}}>{t.lastUsed?fmtDate(t.lastUsed):'—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Staff links */}
          <div style={card()}>
            <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:'1.05rem',fontWeight:700,marginBottom:'0.85rem',color:'#1A0800'}}>👥 Staff Pages</h2>
            <div style={{display:'flex',gap:'0.65rem',flexWrap:'wrap'}}>
              {[
                {href:'/kitchen',      label:'🔥 Kitchen',         color:'linear-gradient(135deg,#E65C00,#F9A826)'},
                {href:'/waiter',       label:'🧑‍🍳 Waiter',          color:'linear-gradient(135deg,#E65C00,#F9A826)'},
                {href:'/manager',      label:'💳 Manager Counter',  color:'linear-gradient(135deg,#064e3b,#16a34a)'},
                {href:'/table?table=T01',label:'📱 Table Ordering', color:'linear-gradient(135deg,#E65C00,#F9A826)'},
                {href:'/',             label:'🛍️ Customer Menu',   color:'linear-gradient(135deg,#E65C00,#F9A826)'},
                {href:'/qr',           label:'📱 QR Generator',     color:'linear-gradient(135deg,#3b82f6,#1d4ed8)'},
              ].map(l=>(
                <a key={l.href} href={l.href} style={{padding:'0.55rem 1.1rem',background:l.color,color:'white',borderRadius:8,fontWeight:700,textDecoration:'none',fontSize:'0.84rem'}}>{l.label}</a>
              ))}
            </div>
          </div>
        </>}

        {/* ═══════════ ORDERS ═══════════ */}
        {section==='orders' && (
          <div style={card()}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'0.6rem',flexWrap:'wrap',gap:'0.5rem'}}>
              <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:'1.05rem',fontWeight:700,color:'#1A0800',margin:0}}>🧾 All Orders</h2>
              {/* Date range selector */}
              <div style={{display:'flex',gap:'0.3rem',flexWrap:'wrap'}}>
                {([['today','Today'],['yesterday','Yesterday'],['week','Last 7 Days'],['month','Last 30 Days'],['all','All Time']] as const).map(([k,l])=>(
                  <button key={k} onClick={()=>setOrdersDateFilter(k)} style={{...tabB(ordersDateFilter===k),padding:'0.28rem 0.7rem',fontSize:'0.72rem'}}>
                    {histLoading && ordersDateFilter===k ? '⏳' : l}
                  </button>
                ))}
              </div>
            </div>
            <div style={{display:'flex',gap:'0.35rem',flexWrap:'wrap',marginBottom:'1rem'}}>
                {[
                  {k:'all',            l:'All'},
                  {k:'awaiting_waiter',l:'Awaiting Waiter'},
                  {k:'pending',        l:'In Queue'},
                  {k:'preparing',      l:'Preparing'},
                  {k:'prepared',       l:'Ready'},
                  {k:'served',         l:'Served'},
                  {k:'out_for_delivery',l:'Out for Delivery'},
                  {k:'delivered',      l:'Delivered'},
                  {k:'re_serve_required',l:'Re-Serve'},
                  {k:'completed',      l:'Completed'},
                  {k:'cancelled',      l:'Cancelled'},
                  {k:'void',           l:'Void'},
                ].map(({k,l})=>(
                  <button key={k} onClick={()=>setOrderFilter(k)} style={{...tabB(orderFilter===k),padding:'0.28rem 0.7rem',fontSize:'0.72rem'}}>{l}</button>
                ))}
            </div>
            {histLoading && <div style={{color:'#E65C00',fontSize:'0.8rem',marginBottom:'0.5rem'}}>⏳ Loading orders…</div>}
            <div style={{overflowX:'auto'}}>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.81rem'}}>
                <thead><tr style={{background:'#FFF5EB'}}>
                  {['Order ID','Type','Location','Customer','Items','Subtotal','Disc.','Total','Payment','Status','Time','Actions'].map(h=>(
                    <th key={h} style={{padding:'0.5rem 0.65rem',textAlign:'left',fontWeight:700,fontSize:'0.7rem',color:'#6B5246',textTransform:'uppercase',whiteSpace:'nowrap'}}>{h}</th>
                  ))}
                </tr></thead>
                <tbody>
                  {!filteredOrders.length
                    ? <tr><td colSpan={12} style={{textAlign:'center',color:'#999',padding:'2rem'}}>{histLoading ? '⏳ Loading…' : 'No orders found for this period'}</td></tr>
                    : filteredOrders.map(order=>{
                        const t      = fmtTime(order.timestamp);
                        // Each order type has its own status flow — must NOT share delivery/pickup flows.
                        // Pickup: pending→preparing→prepared→served→completed  (NOT out_for_delivery)
                        // Delivery: pending→preparing→prepared→out_for_delivery→delivered→completed
                        const _flow  = order.type==='delivery' ? STATUS_FLOW_DELIVERY
                                     : order.type==='pickup'   ? STATUS_FLOW_PICKUP
                                     : STATUS_FLOW_DINE_IN;
                        const curIdx = (_flow as readonly string[]).indexOf(order.status);
                        const nxt    = curIdx !== -1 && curIdx < _flow.length - 1 ? _flow[curIdx + 1] : undefined;
                        const isc    = order.status==='cancelled';
                        return (
                          <tr key={order.id} style={{borderBottom:'1px solid #f5f0e8',opacity:isc?0.6:1}}>
                            <td style={{padding:'0.5rem 0.65rem'}}><button onClick={()=>setSelOrder(order)} style={{background:'none',border:'none',color:'#E65C00',textDecoration:'underline',fontWeight:700,cursor:'pointer',fontFamily:'Poppins,sans-serif',fontSize:'0.81rem'}}>{order.id}</button></td>
                            <td style={{padding:'0.5rem 0.65rem'}}>
                              <span style={{fontSize:'0.7rem',fontWeight:700,padding:'0.12rem 0.45rem',borderRadius:10,background:order.type==='dine-in'?'#fff7ed':order.type==='delivery'?'#f5f3ff':'#f0fdf4',color:order.type==='dine-in'?'#ea580c':order.type==='delivery'?'#7c3aed':'#16a34a'}}>
                                {order.type==='dine-in'?'🍽️ Dine-In':order.type==='delivery'?'🚗 Delivery':'🏪 Pickup'}
                              </span>
                              {order.source==='online' && <span style={{marginLeft:'0.25rem',fontSize:'0.62rem',fontWeight:700,background:'#dbeafe',color:'#1d4ed8',padding:'0.1rem 0.35rem',borderRadius:6}}>ONLINE</span>}
                            </td>
                            <td style={{padding:'0.5rem 0.65rem',fontSize:'0.8rem'}}>
                              {order.type==='dine-in'?`Table ${order.tableId}`:order.deliveryAddress?<span title={order.deliveryAddress}>📍 {order.deliveryAddress.slice(0,22)}{order.deliveryAddress.length>22?'…':''}</span>:'—'}
                            </td>
                            <td style={{padding:'0.5rem 0.65rem',fontWeight:600}}>{order.customerName}</td>
                            <td style={{padding:'0.5rem 0.65rem',textAlign:'center'}}>{(order.items||[]).reduce((s:number,it:{qty?:number})=>s+(it.qty||1),0)||0}</td>
                            <td style={{padding:'0.5rem 0.65rem'}}>₹{order.subtotal||order.total}</td>
                            <td style={{padding:'0.5rem 0.65rem',color:'#16a34a',fontWeight:700}}>{(order.discount||0)>0?`-₹${order.discount}`:'—'}</td>
                            <td style={{padding:'0.5rem 0.65rem',fontWeight:800}}>₹{order.total}</td>
                            <td style={{padding:'0.5rem 0.65rem',color:'#888'}}>{order.payment||'N/A'}</td>
                            <td style={{padding:'0.5rem 0.65rem'}}><span style={{fontSize:'0.7rem',fontWeight:700,padding:'0.12rem 0.45rem',borderRadius:10,background:(STATUS_COLOR[order.status]||'#888')+'22',color:STATUS_COLOR[order.status]||'#888',textTransform:'capitalize'}}>{order.status}</span></td>
                            <td style={{padding:'0.5rem 0.65rem',color:'#999',whiteSpace:'nowrap'}}>{t}</td>
                            <td style={{padding:'0.5rem 0.65rem',whiteSpace:'nowrap',display:'flex',gap:'0.25rem'}}>
                              {!isc&&nxt&&<button onClick={()=>advance(order.id)} style={{...btn('#f97316'),padding:'0.18rem 0.5rem',fontSize:'0.7rem'}}>▶ {STATUS_LABEL_MAP[nxt]||nxt}</button>}
                              {!isc&&order.status!=='completed'&&<button onClick={()=>{setCancelModal({open:true,orderId:order.id});setCancelReason('');}} style={{...btn('#ef4444'),padding:'0.18rem 0.45rem',fontSize:'0.7rem'}}>✕</button>}
                              {!isc&&<button onClick={()=>{setDiscountModal({open:true,orderId:order.id});setDiscAmt('');setDiscNote('');setPinInput('');setPinMsg('');}} style={{...btn('#8b5cf6'),padding:'0.18rem 0.45rem',fontSize:'0.7rem'}}>🏷</button>}
                            </td>
                          </tr>
                        );
                      })
                  }
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ═══════════ SALES ═══════════ */}
        {section==='sales' && <>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'1rem',flexWrap:'wrap',gap:'0.75rem'}}>
            <div style={{display:'flex',gap:'0.4rem',flexWrap:'wrap'}}>
              {(['today','week','month','all'] as const).map(t=>(
                <button key={t} onClick={()=>setSalesTab(t)} style={tabB(salesTab===t)}>
                  {t==='today'?'📅 Today':t==='week'?'📆 This Week':t==='month'?'🗓️ This Month':'📊 All Time'}
                </button>
              ))}
            </div>
            <button onClick={()=>{
              // Export current period orders from live Supabase data as CSV
              const rows = periodOrders.map(o=>[
                o.id,o.orderNum||'',o.type,o.customerName,o.status,
                o.total||0,o.discount||0,o.paymentMethod||'',
                fmtDateTime(o.timestamp),
              ]);
              const header=['ID','Order#','Type','Customer','Status','Total','Discount','Payment','Date'];
              const csv=[header,...rows].map(r=>r.map(v=>JSON.stringify(v??'')).join(',')).join('\n');
              const blob=new Blob([csv],{type:'text/csv'});
              const url=URL.createObjectURL(blob);
              const a=document.createElement('a');
              a.href=url;a.download=`orders-${salesTab}-${new Date().toISOString().slice(0,10)}.csv`;
              a.click();URL.revokeObjectURL(url);
            }} style={{...btn('#16a34a'),display:'flex',alignItems:'center',gap:'0.4rem'}}>📁 Export CSV</button>
          </div>

          {/* Summary cards */}
          <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(140px,1fr))',gap:'0.7rem',marginBottom:'1.4rem'}}>
            {[{val:pCount,label:'Orders',color:'#3b82f6'},{val:`₹${pGross}`,label:'Gross Rev.',color:'#E65C00'},{val:`₹${pDisc}`,label:'Discounts',color:'#ef4444'},{val:`₹${pTotal}`,label:'Net Revenue',color:'#16a34a'},{val:`₹${pAvg}`,label:'Avg Order',color:'#8b5cf6'},{val:periodOrders.filter(o=>o.type==='dine-in').length,label:'🍽️ Dine-In',color:'#f97316'},{val:periodOrders.filter(o=>o.type==='pickup').length,label:'🏪 Pickup',color:'#06b6d4'},{val:periodOrders.filter(o=>o.type==='delivery').length,label:'🚗 Delivery',color:'#7c3aed'},{val:periodOrders.filter(o=>o.source==='online').length,label:'📦 Online',color:'#2563eb'}].map(c=>(
              <div key={c.label} style={{background:'white',border:'1px solid #f0e4d7',borderRadius:10,padding:'0.8rem',borderLeft:`4px solid ${c.color}`}}>
                <div style={{fontSize:'1.2rem',fontWeight:900,color:c.color}}>{c.val}</div>
                <div style={{fontSize:'0.7rem',color:'#999'}}>{c.label}</div>
              </div>
            ))}
          </div>

          {/* Payment breakdown */}
          <div style={card()}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'0.98rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>💳 Payment Method Breakdown</h3>
            <div style={{display:'flex',gap:'0.7rem',flexWrap:'wrap'}}>
              {!Object.keys(payMap).length
                ? <div style={{color:'#999',fontSize:'0.85rem'}}>No data for this period</div>
                : Object.entries(payMap).map(([method,data])=>(
                  <div key={method} style={{background:'#FFF5EB',border:'1px solid #f0e4d7',borderRadius:8,padding:'0.7rem 1rem',minWidth:'130px'}}>
                    <div style={{fontWeight:800,fontSize:'0.98rem',color:'#E65C00'}}>₹{data.total}</div>
                    <div style={{fontSize:'0.72rem',color:'#888',textTransform:'capitalize'}}>{method} ({data.count} orders)</div>
                  </div>
                ))
              }
            </div>
          </div>

          {/* ── Order Source Breakdown ──────────────────────────────────────────
              Shows how orders actually reached the kitchen — self-service QR,
              waiter-assisted, staff-entered counter/pickup, or online — so the
              owner can see real QR adoption. Computed client-side from the
              same periodOrders already loaded for this report; orders.source
              is metadata only and never affects any total above (see
              docs/staff-ordering-implementation-report.md §13/§14). */}
          <div style={card()}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'0.98rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>📊 {salesTab==='today'?"Today's":salesTab==='week'?"This Week's":salesTab==='month'?"This Month's":'Custom Period'} Orders by Source</h3>
            {!periodOrders.length
              ? <div style={{color:'#999',fontSize:'0.85rem'}}>No data for this period</div>
              : (() => {
                  const SOURCE_LABELS: Record<string,{label:string;color:string}> = {
                    'table-qr': { label: '📱 QR Self-Order (Dine-in)', color: '#16a34a' },
                    'online':   { label: '🌐 Online',                  color: '#2563eb' },
                    'waiter':   { label: '🛎️ Waiter-Assisted',         color: '#7c3aed' },
                    'counter':  { label: '🧾 Counter / Pickup Staff',  color: '#f59e0b' },
                    'in-store': { label: '🏪 Other / Legacy',          color: '#6b7280' },
                  };
                  const counts: Record<string, number> = {};
                  periodOrders.forEach(o => {
                    const key = o.source && SOURCE_LABELS[o.source] ? o.source : 'in-store';
                    counts[key] = (counts[key] || 0) + 1;
                  });
                  const total = periodOrders.length;
                  return (
                    <div style={{display:'flex',flexDirection:'column',gap:'0.5rem'}}>
                      {Object.entries(counts).sort((a,b)=>b[1]-a[1]).map(([key,n]) => {
                        const meta = SOURCE_LABELS[key] ?? SOURCE_LABELS['in-store'];
                        const pct = total > 0 ? Math.round((n/total)*100) : 0;
                        return (
                          <div key={key} style={{display:'flex',alignItems:'center',gap:'0.6rem'}}>
                            <div style={{width:170,fontSize:'0.8rem',fontWeight:700,color:'#1A0800',flexShrink:0}}>{meta.label}</div>
                            <div style={{flex:1,background:'#f3f0ea',borderRadius:6,height:18,overflow:'hidden'}}>
                              <div style={{width:`${pct}%`,background:meta.color,height:'100%',borderRadius:6,transition:'width .3s'}} />
                            </div>
                            <div style={{width:90,fontSize:'0.78rem',color:'#666',textAlign:'right',flexShrink:0}}>{n} · {pct}%</div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()
            }
          </div>

          {/* Breakdown table */}
          <div style={card()}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'0.98rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>
              {salesTab==='today'?'⏰ Hour-by-Hour':salesTab==='week'?'📅 Day-by-Day':salesTab==='month'?'📆 Week-by-Week':'🗓️ Month-by-Month'} Breakdown
            </h3>
            <div style={{overflowX:'auto'}}>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.83rem'}}>
                <thead><tr style={{background:'linear-gradient(135deg,#E65C00,#F9A826)',color:'white'}}>
                  {['Period','Orders','Net Revenue','Discounts'].map(h=><th key={h} style={{padding:'0.55rem 0.8rem',textAlign:'left',fontSize:'0.76rem',fontWeight:700}}>{h}</th>)}
                </tr></thead>
                <tbody>
                  {!breakdownRows.length
                    ? <tr><td colSpan={4} style={{textAlign:'center',color:'#999',padding:'1.5rem'}}>No data</td></tr>
                    : breakdownRows.map((r,i)=>(
                        <tr key={i} style={{borderBottom:'1px solid #f5f0e8',background:i%2?'#fffaf5':'white'}}>
                          <td style={{padding:'0.5rem 0.8rem',fontWeight:600}}>{r.label}</td>
                          <td style={{padding:'0.5rem 0.8rem'}}>{r.orders}</td>
                          <td style={{padding:'0.5rem 0.8rem',fontWeight:700,color:'#16a34a'}}>₹{r.net}</td>
                          <td style={{padding:'0.5rem 0.8rem',color:'#ef4444'}}>{r.disc>0?`-₹${r.disc}`:'—'}</td>
                        </tr>
                      ))
                  }
                </tbody>
                <tfoot><tr style={{background:'#f5f0e8',fontWeight:800}}>
                  <td style={{padding:'0.55rem 0.8rem',borderTop:'2px solid #E65C00'}}>TOTAL</td>
                  <td style={{padding:'0.55rem 0.8rem',borderTop:'2px solid #E65C00'}}>{pCount}</td>
                  <td style={{padding:'0.55rem 0.8rem',borderTop:'2px solid #E65C00',color:'#16a34a'}}>₹{pTotal}</td>
                  <td style={{padding:'0.55rem 0.8rem',borderTop:'2px solid #E65C00',color:'#ef4444'}}>{pDisc>0?`-₹${pDisc}`:'—'}</td>
                </tr></tfoot>
              </table>
            </div>
          </div>

          {/* Top items */}
          {topItems.length>0 && (
            <div style={card()}>
              <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'0.98rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>🏆 Top Selling Items</h3>
              <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(195px,1fr))',gap:'0.55rem'}}>
                {topItems.map(([name,data],i)=>(
                  <div key={name} style={{background:'#fafafa',border:'1px solid #f0f0f0',borderRadius:8,padding:'0.65rem 0.85rem',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                    <div>
                      <div style={{fontSize:'0.65rem',color:'#f97316',fontWeight:700}}>#{i+1}</div>
                      <div style={{fontWeight:600,fontSize:'0.8rem',color:'#333'}}>{name}</div>
                      <div style={{fontSize:'0.68rem',color:'#999'}}>₹{data.revenue}</div>
                    </div>
                    <div style={{fontWeight:900,fontSize:'1.05rem',color:'#E65C00',textAlign:'right'}}>{data.qty}<div style={{fontSize:'0.62rem',color:'#bbb',fontWeight:400}}>sold</div></div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>}

        {/* ═══════════ FINANCE / CASH FLOW ═══════════ */}
        {section==='finance' && (
          <Suspense fallback={<div style={{padding:'2rem',textAlign:'center',color:'#94a3b8'}}>Loading Finance…</div>}>
            <AdminFinance adminName={authSession?.name || 'Admin'} />
          </Suspense>
        )}

        {/* ═══════════ MENU ═══════════ */}
        {section==='menu' && <>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'1rem',flexWrap:'wrap',gap:'0.75rem'}}>
            <div style={{display:'flex',gap:'0.35rem',flexWrap:'wrap'}}>
              {['All',...CATEGORIES].map(c=>(
                <button key={c} onClick={()=>setMenuFilter(c)} style={tabB(menuFilter===c)}>{c}</button>
              ))}
            </div>
            <div style={{display:'flex',gap:'0.5rem',flexWrap:'wrap' as const}}>
              <button onClick={importMenuCatalog} disabled={seedingMenu} style={{...btn('#8b5cf6'),fontSize:'0.78rem'}}>{seedingMenu?'⏳ Loading…':'📥 Import Catalog'}</button>
              <label style={{...btn('#16a34a'),fontSize:'0.78rem',cursor:'pointer' as const,display:'inline-flex',alignItems:'center' as const}}>
                📤 Import CSV
                <input type="file" accept=".csv" style={{display:'none'}} onChange={e=>{const f=e.target.files?.[0];if(f){void importMenuFromCsv(f);e.target.value='';}}} />
              </label>
              <button onClick={downloadCsvTemplate} style={{...btn('#6b7280'),fontSize:'0.78rem'}}>⬇️ CSV Template</button>
              <button onClick={()=>{setMenuModal({open:true,item:emptyItem(),isEdit:false});setModalVariants([{name:'',price:''}]);}} style={{...btn(),display:'flex',alignItems:'center',gap:'0.35rem'}}><span style={{fontSize:'1.1rem',lineHeight:1}}>＋</span> Add Item</button>
            </div>
          </div>

          {(seedMsg||csvImportMsg) && (() => {
            const message  = seedMsg || csvImportMsg;
            const bgColor  = message.startsWith('✅') ? '#dcfce7' : message.startsWith('⏳') ? '#eff6ff' : '#fef2f2';
            const txtColor = message.startsWith('✅') ? '#16a34a' : message.startsWith('⏳') ? '#2563eb' : '#ef4444';
            return (
              <div style={{padding:'0.6rem 0.85rem',borderRadius:8,background:bgColor,color:txtColor,fontWeight:700,fontSize:'0.82rem',marginBottom:'0.75rem',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                <span>{message}</span>
                <button onClick={()=>{setSeedMsg('');setCsvImportMsg('');}} style={{background:'none',border:'none',cursor:'pointer',color:'inherit',fontSize:'1.1rem',lineHeight:1,padding:'0 0.2rem'}}>×</button>
              </div>
            );
          })()}
          {!menuItems.length
            ? <div style={{textAlign:'center',color:'#999',padding:'3rem',background:'white',borderRadius:12}}>No items in this category</div>
            : <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(255px,1fr))',gap:'1rem'}}>
                {menuItems.map(item=>(
                  <div key={item.id} style={{background:'white',borderRadius:12,overflow:'hidden',boxShadow:'0 2px 8px rgba(0,0,0,0.08)',opacity:item.available===false?0.55:1,transition:'opacity .2s'}}>
                    <div style={{position:'relative',height:'145px',background:'#f5f0e8',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'2.5rem'}}>
                      {item.img && <img src={item.img} alt={item.name} style={{position:'absolute',inset:0,width:'100%',height:'100%',objectFit:'cover'}} onError={e=>{(e.target as HTMLImageElement).style.display='none';}} />}
                      {!item.img && '🍽️'}
                      {item.badge && <span style={{position:'absolute',top:8,left:8,background:'#E65C00',color:'white',fontSize:'0.6rem',padding:'0.18rem 0.45rem',borderRadius:8,fontWeight:700,zIndex:1}}>{BADGE_LABEL[item.badge]||item.badge}</span>}
                      {item.available===false && <div style={{position:'absolute',inset:0,background:'rgba(0,0,0,0.45)',display:'flex',alignItems:'center',justifyContent:'center',color:'white',fontWeight:700,fontSize:'0.82rem',zIndex:1}}>UNAVAILABLE</div>}
                    </div>
                    <div style={{padding:'0.85rem'}}>
                      <div style={{fontSize:'0.62rem',color:'#888',fontWeight:700,textTransform:'uppercase',letterSpacing:'0.05em'}}>{item.category}</div>
                      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',gap:'0.4rem',margin:'0.2rem 0 0.25rem'}}>
                        <div style={{fontWeight:700,fontSize:'0.9rem',color:'#1A0800'}}>{item.name}</div>
                        <div style={{fontWeight:900,color:'#E65C00',fontSize:'0.88rem',whiteSpace:'nowrap'}}>
                          {item.variants&&item.variants.length>0
                            ? item.variants.length===1
                              ? `₹${item.variants[0].price}`
                              : `₹${item.variants[0].price}–₹${item.variants[item.variants.length-1].price}`
                            : `₹${item.price}`
                          }
                        </div>
                      </div>
                      <div style={{fontSize:'0.73rem',color:'#888',marginBottom:'0.75rem',lineHeight:'1.4'}}>{item.desc}</div>
                      <div style={{display:'flex',gap:'0.35rem'}}>
                        <button onClick={()=>{setMenuModal({open:true,item:{...item},isEdit:true});setModalVariants(item.variants&&item.variants.length>0?item.variants.map(v=>({name:v.name,price:String(v.price)})):[{name:'Regular',price:String(item.price)}]);}} style={{...btn('#3b82f6'),padding:'0.3rem 0.75rem',fontSize:'0.75rem',flex:1}}>✏️ Edit</button>
                        <button onClick={()=>{saveMenuItemApi({id:item.id,available:item.available===false}).then(()=>refresh()).catch(e=>alert(String(e)));}} style={{...btn(item.available===false?'#16a34a':'#6b7280'),padding:'0.3rem 0.65rem',fontSize:'0.75rem'}}>{item.available===false?'✅':'⏸'}</button>
                        <button onClick={()=>{if(confirm(`Delete "${item.name}"?`)){deleteMenuItemApi(item.id).then(()=>refresh()).catch(e=>alert(String(e)));}}} style={{...btn('#ef4444'),padding:'0.3rem 0.6rem',fontSize:'0.75rem'}}>🗑</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
          }
        </>}

        {/* ═══════════ TABLES MANAGEMENT ═══════════ */}
        {section==='tables' && <>
          <div style={card('#E65C00')}>
            <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:'1.05rem',fontWeight:700,marginBottom:'0.3rem',color:'#1A0800'}}>🪑 Tables Management</h2>
            <p style={{fontSize:'0.78rem',color:'#666',marginBottom:'1rem'}}>Add, edit or remove tables. Changes sync instantly to QR, waiter, kitchen and manager portals.</p>

            {tableMsg && (
              <div style={{padding:'0.6rem 0.8rem',borderRadius:8,background:tableMsg.startsWith('✅')?'#dcfce7':'#fef2f2',color:tableMsg.startsWith('✅')?'#16a34a':'#ef4444',fontWeight:700,fontSize:'0.82rem',marginBottom:'1rem'}}>
                {tableMsg}
              </div>
            )}

            {/* Add Table Form */}
            <div style={{background:'#faf8f3',borderRadius:10,padding:'1rem',marginBottom:'1.25rem',border:'1px solid #e5e7eb'}}>
              <h3 style={{fontSize:'0.88rem',fontWeight:700,color:'#1A0800',marginBottom:'0.7rem'}}>➕ Add New Table</h3>
              <div style={{display:'grid',gridTemplateColumns:'1fr 120px auto',gap:'0.75rem',alignItems:'flex-end'}}>
                <div>
                  <label style={{fontSize:'0.73rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Table Name / Number</label>
                  <input value={tableForm.name} onChange={e=>setTableForm(f=>({...f,name:e.target.value}))} placeholder="e.g. T1 or Table 5" style={{...inp}} />
                </div>
                <div>
                  <label style={{fontSize:'0.73rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Seats</label>
                  <input type="number" min={1} max={50} value={tableForm.capacity} onChange={e=>setTableForm(f=>({...f,capacity:e.target.value}))} style={{...inp,textAlign:'center'}} />
                </div>
                <button onClick={handleAddTable} style={{...btn('#E65C00'),whiteSpace:'nowrap' as const}}>+ Add Table</button>
              </div>
            </div>

            {/* Existing Tables */}
            <h3 style={{fontSize:'0.88rem',fontWeight:700,color:'#1A0800',marginBottom:'0.7rem'}}>All Tables ({liveTables.length})</h3>
            {liveTables.length === 0 && (
              <div style={{textAlign:'center',padding:'2rem',color:'#999',fontSize:'0.85rem'}}>No tables found. Add your first table above.</div>
            )}
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))',gap:'0.75rem'}}>
              {liveTables.map(t => {
                const isEditing  = editTableId === t.id;
                const isOccupied = t.status === 'occupied';
                const sessionMins = t.sessionStart
                  ? Math.floor((Date.now()-new Date(t.sessionStart).getTime())/60000)
                  : null;
                const STALE_MINS = 240;
                const isStale   = sessionMins !== null && sessionMins >= STALE_MINS;
                const fmtDuration = (m: number) =>
                  m < 60 ? `${m}m` : `${Math.floor(m/60)}h ${m%60}m`;
                const borderColor =
                  !isOccupied ? '#e5e7eb' :
                  isStale     ? '#dc2626' :
                                '#f97316';
                const statusBg    = !isOccupied ? '#d1fae5' : isStale ? '#fee2e2' : '#fed7aa';
                const statusColor = !isOccupied ? '#065f46' : isStale ? '#991b1b' : '#92400e';
                const statusLabel = !isOccupied ? '🟢 Available' : isStale ? '🔴 Stale Session' : '🟠 Occupied';
                return (
                  <div key={t.id} style={{background:'white',border:`2px solid ${borderColor}`,borderRadius:12,padding:'0.85rem 1rem'}}>
                    {isEditing ? (
                      <>
                        <div style={{display:'grid',gridTemplateColumns:'1fr 80px',gap:'0.5rem',marginBottom:'0.6rem'}}>
                          <input value={editTableVal.name} onChange={e=>setEditTableVal(v=>({...v,name:e.target.value}))} placeholder="Table name" style={{...inp,fontSize:'0.85rem'}} />
                          <input type="number" min={1} max={50} value={editTableVal.capacity} onChange={e=>setEditTableVal(v=>({...v,capacity:e.target.value}))} style={{...inp,fontSize:'0.85rem',textAlign:'center'}} />
                        </div>
                        <div style={{display:'flex',gap:'0.5rem'}}>
                          <button onClick={()=>handleSaveTableEdit(t.id)} style={{...btn('#16a34a'),flex:1,fontSize:'0.78rem'}}>💾 Save</button>
                          <button onClick={()=>setEditTableId('')} style={{...btn('#6b7280'),flex:1,fontSize:'0.78rem'}}>Cancel</button>
                        </div>
                      </>
                    ) : (
                      <>
                        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'0.4rem'}}>
                          <div style={{fontWeight:800,fontSize:'1rem',color:'#1A0800'}}>{t.name}</div>
                          <span style={{fontSize:'0.7rem',fontWeight:700,background:statusBg,color:statusColor,borderRadius:20,padding:'0.15rem 0.5rem'}}>
                            {statusLabel}
                          </span>
                        </div>
                        <div style={{fontSize:'0.78rem',color:'#666',marginBottom:'0.5rem'}}>
                          🪑 {t.capacity} seat{t.capacity!==1?'s':''} &nbsp;·&nbsp; ID: <code style={{fontSize:'0.68rem',background:'#f3f4f6',padding:'0.1rem 0.3rem',borderRadius:4}}>{t.id}</code>
                        </div>
                        {/* Session info for occupied tables */}
                        {isOccupied && sessionMins !== null && (
                          <div style={{fontSize:'0.72rem',color:isStale?'#dc2626':'#f97316',fontWeight:600,marginBottom:'0.5rem',background:isStale?'#fee2e2':'#fff7ed',borderRadius:6,padding:'0.25rem 0.5rem'}}>
                            ⏱ Session open for <strong>{fmtDuration(sessionMins)}</strong>
                            {isStale && ' — likely abandoned, consider force-closing'}
                          </div>
                        )}
                        <div style={{display:'flex',gap:'0.4rem',flexWrap:'wrap'}}>
                          <button onClick={()=>{setEditTableId(t.id);setEditTableVal({name:t.name,capacity:String(t.capacity)});}} style={{...btn('#E65C00'),flex:1,fontSize:'0.72rem',padding:'0.35rem 0.5rem'}}>✏️ Edit</button>
                          {/* Force-close button: visible for any occupied table, prominent for stale */}
                          {isOccupied && t.sessionTabId && (
                            <button
                              onClick={()=>handleForceCloseSession(t.id, t.sessionTabId!, t.name)}
                              style={{...btn(isStale?'#dc2626':'#6b7280'),flex:1,fontSize:'0.72rem',padding:'0.35rem 0.5rem'}}
                              title="Admin override: force-close this session"
                            >
                              {isStale ? '🔴 Force Close' : '🔒 Close Session'}
                            </button>
                          )}
                          <button onClick={()=>handleDeleteTable(t.id,t.name)} disabled={isOccupied} title={isOccupied?'Force-close the session first, then delete':'Delete table'} style={{...btn(isOccupied?'#d1d5db':'#ef4444',isOccupied?'#9ca3af':'white'),flex:1,fontSize:'0.72rem',padding:'0.35rem 0.5rem',cursor:isOccupied?'not-allowed':'pointer'}}>🗑️ Delete</button>
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Summary stats */}
            {liveTables.length > 0 && (
              <div style={{marginTop:'1.25rem',display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(140px,1fr))',gap:'0.6rem'}}>
                {[
                  {icon:'🪑',val:liveTables.length,label:'Total Tables',color:'#E65C00'},
                  {icon:'🔴',val:liveTables.filter(t=>t.status==='occupied').length,label:'Occupied',color:'#f97316'},
                  {icon:'🟢',val:liveTables.filter(t=>t.status==='available').length,label:'Available',color:'#16a34a'},
                  {icon:'👥',val:liveTables.reduce((s,t)=>s+t.capacity,0),label:'Total Seats',color:'#3b82f6'},
                ].map(s=>(
                  <div key={s.label} style={{background:'white',padding:'0.75rem',borderRadius:10,textAlign:'center',boxShadow:'0 1px 4px rgba(0,0,0,0.06)',borderLeft:`3px solid ${s.color}`}}>
                    <div style={{fontSize:'1.4rem',marginBottom:'0.1rem'}}>{s.icon}</div>
                    <div style={{fontWeight:900,fontSize:'1.2rem',color:s.color}}>{s.val}</div>
                    <div style={{fontSize:'0.68rem',color:'#888'}}>{s.label}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>}

        {/* ═══════════ OFFERS / DISCOUNT RULES ═══════════ */}
        {section==='offers' && <>
          {/* Create new offer */}
          <div style={card('#E65C00')}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'1rem',fontWeight:700,marginBottom:'1rem',color:'#1A0800'}}>🎁 Create New Offer</h3>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'0.75rem',marginBottom:'0.75rem'}}>
              <div style={{gridColumn:'1/-1'}}>
                <label style={{fontSize:'0.75rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Offer Name</label>
                <input value={offerForm.name} onChange={e=>setOfferForm(f=>({...f,name:e.target.value}))} placeholder="e.g. 10% off above ₹2000" style={{...inp}} />
              </div>
              <div>
                <label style={{fontSize:'0.75rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Type</label>
                <select value={offerForm.type} onChange={e=>setOfferForm(f=>({...f,type:e.target.value as 'percent'|'flat'}))} style={{...inp}}>
                  <option value="percent">Percent (%)</option>
                  <option value="flat">Flat (₹)</option>
                </select>
              </div>
              <div>
                <label style={{fontSize:'0.75rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Value ({offerForm.type==='percent'?'%':'₹'})</label>
                <input type="number" value={offerForm.value} onChange={e=>setOfferForm(f=>({...f,value:parseFloat(e.target.value)||0}))} placeholder="10" min="0" style={{...inp}} />
              </div>
              <div>
                <label style={{fontSize:'0.75rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Min Order ₹</label>
                <input type="number" value={offerForm.minOrder} onChange={e=>setOfferForm(f=>({...f,minOrder:parseFloat(e.target.value)||0}))} placeholder="0 = always" min="0" style={{...inp}} />
              </div>
              <div>
                <label style={{fontSize:'0.75rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Max Discount ₹ (0=no cap)</label>
                <input type="number" value={offerForm.maxDiscount} onChange={e=>setOfferForm(f=>({...f,maxDiscount:parseFloat(e.target.value)||0}))} placeholder="0 = no cap" min="0" style={{...inp}} />
              </div>
              <div>
                <label style={{fontSize:'0.75rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Apply To</label>
                <select value={offerForm.applyTo} onChange={e=>setOfferForm(f=>({...f,applyTo:e.target.value as OfferRule['applyTo']}))} style={{...inp}}>
                  <option value="all">All Orders</option>
                  <option value="dine-in">Dine-in</option>
                  <option value="pickup">Pickup</option>
                  <option value="delivery">Delivery</option>
                </select>
              </div>
              <div style={{display:'flex',alignItems:'center',gap:'0.5rem'}}>
                <input type="checkbox" id="offerActive" checked={offerForm.active} onChange={e=>setOfferForm(f=>({...f,active:e.target.checked}))} style={{width:16,height:16}} />
                <label htmlFor="offerActive" style={{fontSize:'0.82rem',fontWeight:600,color:'#555',cursor:'pointer'}}>Active</label>
              </div>
            </div>
            {offerMsg && <div style={{fontSize:'0.8rem',marginBottom:'0.5rem',color:offerMsg.includes('✅')?'#16a34a':'#ef4444'}}>{offerMsg}</div>}
            <button
              disabled={offerBusy||!offerForm.name.trim()}
              onClick={async () => {
                if (!offerForm.name.trim()) { setOfferMsg('❌ Name is required'); return; }
                setOfferBusy(true); setOfferMsg('');
                try {
                  const newRule: OfferRule = { ...offerForm, id: 'off_'+Date.now().toString(36) };
                  const res  = await fetch('/api/offers', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ rule: newRule }) });
                  const data = await res.json() as OfferRule[] | { error: string };
                  if (Array.isArray(data)) { setOfferRules(data); setOfferMsg('✅ Offer created!'); setOfferForm({ name:'', type:'percent', value:10, minOrder:0, maxDiscount:0, applyTo:'all', active:true }); }
                  else setOfferMsg(`❌ ${(data as {error:string}).error}`);
                } catch(e) { setOfferMsg('❌ ' + (e instanceof Error ? e.message : String(e))); }
                finally { setOfferBusy(false); }
              }}
              style={{...btn(), opacity:offerBusy?0.7:1}}
            >{offerBusy?'⏳ Saving…':'✅ Create Offer'}</button>
          </div>

          {/* Existing offers list */}
          <div style={card('#8b5cf6')}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'0.98rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>📋 Existing Offers</h3>
            {!offerRules.length
              ? <div style={{color:'#999',fontSize:'0.85rem'}}>No offers created yet</div>
              : <div style={{display:'flex',flexDirection:'column',gap:'0.65rem'}}>
                  {offerRules.map(rule=>(
                    <div key={rule.id} style={{background:'white',border:'1px solid #e5e7eb',borderRadius:10,padding:'0.85rem',display:'flex',justifyContent:'space-between',alignItems:'flex-start',gap:'0.75rem',opacity:rule.active?1:0.6}}>
                      <div style={{flex:1}}>
                        <div style={{fontWeight:800,fontSize:'0.88rem',color:'#1A0800',marginBottom:'0.2rem'}}>{rule.name}</div>
                        <div style={{fontSize:'0.72rem',color:'#64748b',display:'flex',flexWrap:'wrap',gap:'0.5rem'}}>
                          <span style={{background:'#f0fdf4',color:'#16a34a',borderRadius:6,padding:'0.1rem 0.4rem',fontWeight:700}}>
                            {rule.type==='percent'?`${rule.value}% off`:`₹${rule.value} off`}
                          </span>
                          {rule.minOrder>0 && <span style={{background:'#eff6ff',color:'#2563eb',borderRadius:6,padding:'0.1rem 0.4rem',fontWeight:700}}>Min ₹{rule.minOrder}</span>}
                          {rule.maxDiscount>0 && <span style={{background:'#fef3c7',color:'#d97706',borderRadius:6,padding:'0.1rem 0.4rem',fontWeight:700}}>Cap ₹{rule.maxDiscount}</span>}
                          <span style={{background:'#f5f3ff',color:'#7c3aed',borderRadius:6,padding:'0.1rem 0.4rem',fontWeight:700}}>{rule.applyTo}</span>
                        </div>
                      </div>
                      <div style={{display:'flex',flexDirection:'column',gap:'0.35rem',alignItems:'flex-end',flexShrink:0}}>
                        <button
                          onClick={async()=>{
                            try {
                              const res  = await fetch('/api/offers', { method:'PATCH', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id: rule.id, updates: { active: !rule.active } }) });
                              const data = await res.json() as OfferRule[];
                              if (Array.isArray(data)) setOfferRules(data);
                            } catch(e) { alert(String(e)); }
                          }}
                          style={{...btn(rule.active?'#e5e7eb':'#16a34a',rule.active?'#555':'white'),padding:'0.25rem 0.7rem',fontSize:'0.72rem'}}
                        >{rule.active?'⏸ Disable':'✅ Enable'}</button>
                        <button
                          onClick={async()=>{
                            if (!confirm(`Delete offer "${rule.name}"?`)) return;
                            try {
                              const res  = await fetch('/api/offers', { method:'DELETE', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id: rule.id }) });
                              const data = await res.json() as OfferRule[];
                              if (Array.isArray(data)) setOfferRules(data);
                            } catch(e) { alert(String(e)); }
                          }}
                          style={{...btn('#ef4444'),padding:'0.25rem 0.7rem',fontSize:'0.72rem'}}
                        >🗑 Delete</button>
                      </div>
                    </div>
                  ))}
                </div>
            }
          </div>
        </>}

        {/* ═══════════ FRAUD / TRANSPARENCY ═══════════ */}
        {section==='fraud' && <>
          {alerts.length>0 && (
            <div style={{background:'#fef2f2',border:'2px solid #ef4444',borderRadius:12,padding:'1.2rem',marginBottom:'1.4rem'}}>
              <h3 style={{color:'#ef4444',fontWeight:700,marginBottom:'0.6rem',fontSize:'0.92rem'}}>🚨 Active Alerts</h3>
              {alerts.map((a,i)=><div key={i} style={{color:'#7f1d1d',fontSize:'0.85rem',padding:'0.25rem 0',borderBottom:'1px solid #fecaca'}}>{a}</div>)}
            </div>
          )}

          <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(155px,1fr))',gap:'0.7rem',marginBottom:'1.4rem'}}>
            {[{val:`${cancelRate}%`,label:'Cancel Rate',color:'#ef4444'},{val:cancelledOrders.length,label:'Total Cancelled',color:'#f97316'},{val:discountOrders.length,label:'Discounted Orders',color:'#8b5cf6'},{val:`₹${orders.reduce((s,o)=>s+(o.discount||0),0)}`,label:'All-Time Discounts',color:'#E65C00'},{val:highDiscOrders.length,label:'High Disc. (>30%)',color:'#dc2626'}].map(c=>(
              <div key={c.label} style={{background:'white',border:'1px solid #f0e4d7',borderRadius:10,padding:'0.82rem',borderLeft:`4px solid ${c.color}`}}>
                <div style={{fontSize:'1.25rem',fontWeight:900,color:c.color}}>{c.val}</div>
                <div style={{fontSize:'0.7rem',color:'#999'}}>{c.label}</div>
              </div>
            ))}
          </div>

          {/* Discount log */}
          <div style={card('#8b5cf6')}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'0.98rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>🏷️ Discount Log</h3>
            {!discountOrders.length
              ? <div style={{color:'#999',fontSize:'0.85rem'}}>No discounts applied yet</div>
              : <div style={{overflowX:'auto'}}>
                  <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.8rem'}}>
                    <thead><tr style={{background:'#f5f3ff'}}>
                      {['Order','Customer','Date','Subtotal','Discount','% Off','Reason','Status'].map(h=><th key={h} style={{padding:'0.48rem 0.7rem',textAlign:'left',fontSize:'0.7rem',fontWeight:700,color:'#6d28d9',textTransform:'uppercase'}}>{h}</th>)}
                    </tr></thead>
                    <tbody>
                      {discountOrders.map(o=>{
                        const sub=o.subtotal||o.total;
                        const pct=Math.round(((o.discount||0)/sub)*100);
                        return (
                          <tr key={o.id} style={{borderBottom:'1px solid #f5f0e8',background:pct>30?'#fef2f2':'white'}}>
                            <td style={{padding:'0.48rem 0.7rem'}}><button onClick={()=>setSelOrder(o)} style={{background:'none',border:'none',color:'#E65C00',textDecoration:'underline',fontWeight:700,cursor:'pointer',fontFamily:'Poppins,sans-serif',fontSize:'0.8rem'}}>{o.id}</button></td>
                            <td style={{padding:'0.48rem 0.7rem',fontWeight:600}}>{o.customerName}</td>
                            <td style={{padding:'0.48rem 0.7rem',color:'#888'}}>{fmtDate(o.timestamp)}</td>
                            <td style={{padding:'0.48rem 0.7rem'}}>₹{sub}</td>
                            <td style={{padding:'0.48rem 0.7rem',color:'#16a34a',fontWeight:700}}>-₹{o.discount}</td>
                            <td style={{padding:'0.48rem 0.7rem'}}><span style={{fontWeight:700,color:pct>30?'#ef4444':'#888'}}>{pct}%{pct>30?' ⚠️':''}</span></td>
                            <td style={{padding:'0.48rem 0.7rem',color:'#555'}}>{o.discountReason||'—'}</td>
                            <td style={{padding:'0.48rem 0.7rem'}}><span style={{fontSize:'0.7rem',fontWeight:700,padding:'0.12rem 0.45rem',borderRadius:10,background:(STATUS_COLOR[o.status]||'#888')+'22',color:STATUS_COLOR[o.status]||'#888',textTransform:'capitalize'}}>{o.status}</span></td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
            }
          </div>

          {/* Cancellation log */}
          <div style={card('#ef4444')}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'0.98rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>❌ Cancellation Log</h3>
            {!cancelledOrders.length
              ? <div style={{color:'#999',fontSize:'0.85rem'}}>No cancellations recorded</div>
              : <div style={{overflowX:'auto'}}>
                  <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.8rem'}}>
                    <thead><tr style={{background:'#fef2f2'}}>
                      {['Order','Customer','Type','Amount','Cancelled At','Reason'].map(h=><th key={h} style={{padding:'0.48rem 0.7rem',textAlign:'left',fontSize:'0.7rem',fontWeight:700,color:'#991b1b',textTransform:'uppercase'}}>{h}</th>)}
                    </tr></thead>
                    <tbody>
                      {cancelledOrders.map(o=>(
                        <tr key={o.id} style={{borderBottom:'1px solid #fee2e2'}}>
                          <td style={{padding:'0.48rem 0.7rem'}}><button onClick={()=>setSelOrder(o)} style={{background:'none',border:'none',color:'#E65C00',textDecoration:'underline',fontWeight:700,cursor:'pointer',fontFamily:'Poppins,sans-serif',fontSize:'0.8rem'}}>{o.id}</button></td>
                          <td style={{padding:'0.48rem 0.7rem',fontWeight:600}}>{o.customerName}</td>
                          <td style={{padding:'0.48rem 0.7rem',textTransform:'capitalize'}}>{o.type}</td>
                          <td style={{padding:'0.48rem 0.7rem',fontWeight:700,color:'#ef4444'}}>₹{o.total}</td>
                          <td style={{padding:'0.48rem 0.7rem',color:'#888'}}>{fmtDateTime(o.timestamp)}</td>
                          <td style={{padding:'0.48rem 0.7rem',color:'#555'}}>{o.cancelReason||'—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
            }
          </div>

          {/* Issue / Not-Received Log */}
          <div style={card('#dc2626')}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'0.98rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>🚨 Not-Received Issue Log — Today</h3>
            {!todayIssues.length
              ? <div style={{color:'#999',fontSize:'0.85rem'}}>No issues reported today</div>
              : <div style={{overflowX:'auto'}}>
                  <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.8rem'}}>
                    <thead><tr style={{background:'#fef2f2'}}>
                      {['Order','Reported By','Retries','Status','Escalated','Reported At','Resolved By','Resolved At'].map(h=>(
                        <th key={h} style={{padding:'0.48rem 0.7rem',textAlign:'left',fontSize:'0.68rem',fontWeight:700,color:'#991b1b',textTransform:'uppercase',whiteSpace:'nowrap'}}>{h}</th>
                      ))}
                    </tr></thead>
                    <tbody>
                      {todayIssues.map(issue => {
                        const relOrd = orders.find(o => o.id === issue.orderId);
                        return (
                          <tr key={issue.id} style={{borderBottom:'1px solid #fee2e2',background:issue.escalated?'#fef2f2':'white'}}>
                            <td style={{padding:'0.48rem 0.7rem',fontWeight:700,color:'#dc2626'}}>{relOrd?.orderNum || issue.orderId.slice(-6)}</td>
                            <td style={{padding:'0.48rem 0.7rem'}}>{issue.reportedBy}</td>
                            <td style={{padding:'0.48rem 0.7rem',textAlign:'center',fontWeight:700,color:issue.retryCount>=3?'#dc2626':'#555'}}>#{issue.retryCount}</td>
                            <td style={{padding:'0.48rem 0.7rem'}}>
                              <span style={{fontSize:'0.7rem',fontWeight:700,padding:'0.12rem 0.45rem',borderRadius:10,background:issue.status==='resolved'?'#dcfce7':issue.status==='reserving'?'#dbeafe':'#fef9c3',color:issue.status==='resolved'?'#16a34a':issue.status==='reserving'?'#1d4ed8':'#854d0e'}}>
                                {issue.status}
                              </span>
                            </td>
                            <td style={{padding:'0.48rem 0.7rem',textAlign:'center'}}>{issue.escalated?<span style={{color:'#dc2626',fontWeight:800}}>⬆ YES</span>:'—'}</td>
                            <td style={{padding:'0.48rem 0.7rem',color:'#888',whiteSpace:'nowrap'}}>{fmtTime(issue.reportedAt)}</td>
                            <td style={{padding:'0.48rem 0.7rem',color:'#555'}}>{issue.resolvedBy || '—'}</td>
                            <td style={{padding:'0.48rem 0.7rem',color:'#888',whiteSpace:'nowrap'}}>{issue.resolvedAt ? fmtTime(issue.resolvedAt) : '—'}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
            }
          </div>

          {/* Staff Accountability */}
          <div style={card('#06b6d4')}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'0.98rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>👤 Staff Accountability — Today</h3>
            {!waiterStats.length
              ? <div style={{color:'#999',fontSize:'0.85rem'}}>No waiter activity recorded today.</div>
              : <div style={{overflowX:'auto'}}>
                  <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.82rem'}}>
                    <thead><tr style={{background:'#ecfeff'}}>
                      {['Waiter','Accepted','Cancelled','Served','Cancel Rate'].map(h=>(
                        <th key={h} style={{padding:'0.48rem 0.75rem',textAlign:'left',fontSize:'0.7rem',fontWeight:700,color:'#0e7490',textTransform:'uppercase'}}>{h}</th>
                      ))}
                    </tr></thead>
                    <tbody>
                      {waiterStats.map((s,i)=>{
                        const isFlagged = s.cancellationRate > 20;
                        return (
                          <tr key={s.name} style={{borderBottom:'1px solid #cffafe',background:isFlagged?'#fef2f2':i%2?'#f0fdfe':'white'}}>
                            <td style={{padding:'0.48rem 0.75rem',fontWeight:700,color:'#1A0800'}}>{s.name}{isFlagged&&<span style={{marginLeft:'0.3rem',color:'#ef4444',fontSize:'0.7rem'}}>⚠️ High</span>}</td>
                            <td style={{padding:'0.48rem 0.75rem',fontWeight:700,color:'#16a34a'}}>{s.ordersAccepted}</td>
                            <td style={{padding:'0.48rem 0.75rem',fontWeight:700,color:s.ordersCancelled>0?'#ef4444':'#9ca3af'}}>{s.ordersCancelled}</td>
                            <td style={{padding:'0.48rem 0.75rem',fontWeight:700,color:'#06b6d4'}}>{s.ordersServed}</td>
                            <td style={{padding:'0.48rem 0.75rem'}}>
                              <span style={{fontWeight:700,color:s.cancellationRate>20?'#ef4444':s.cancellationRate>10?'#f59e0b':'#16a34a'}}>
                                {s.cancellationRate}%
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
            }
          </div>

          {/* ── Analytics Charts (Recharts) ────── */}
          <Suspense fallback={<div style={{padding:'1rem',textAlign:'center',color:'#94a3b8'}}>Loading charts…</div>}>
            <AnalyticsCharts period={salesTab} />
          </Suspense>

        {/* Fraud Alert Log — derived from live Supabase orders */}
          {(() => {
            // Build fraud log from live order timeline events (replaces localStorage getFraudAlerts)
            const fraudAlerts = orders
              .flatMap(o => (o.timeline||[])
                .filter(e => ['OrderCancelled','FoodDisputed','DisputeResolved'].includes(e.eventType))
                .map(e => ({
                  id:     `${o.id}-${e.eventType}`,
                  type:   e.eventType,
                  detail: `Order #${o.orderNum||o.id.slice(-6)} — ${o.customerName}`,
                  by:     e.by || 'System',
                  amount: e.eventType === 'OrderCancelled' ? (o.total||0) : 0,
                  at:     e.at || o.timestamp,
                }))
              )
              .sort((a,b) => new Date(b.at).getTime() - new Date(a.at).getTime())
              .slice(0, 20);
            if (!fraudAlerts.length) return null;
            return (
              <div style={card('#f97316')}>
                <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'0.98rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>🚨 Fraud Alert Log</h3>
                <div style={{overflowX:'auto'}}>
                  <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.8rem'}}>
                    <thead><tr style={{background:'#fff7ed'}}>
                      {['Type','Detail','By','Amount','Date'].map(h=><th key={h} style={{padding:'0.48rem 0.7rem',textAlign:'left',fontSize:'0.7rem',fontWeight:700,color:'#9a3412',textTransform:'uppercase'}}>{h}</th>)}
                    </tr></thead>
                    <tbody>
                      {fraudAlerts.map(a=>(
                        <tr key={a.id} style={{borderBottom:'1px solid #fed7aa'}}>
                          <td style={{padding:'0.48rem 0.7rem'}}><span style={{fontSize:'0.7rem',fontWeight:700,padding:'0.12rem 0.45rem',borderRadius:10,background:'#fff7ed',color:'#ea580c'}}>{a.type.replace(/_/g,' ')}</span></td>
                          <td style={{padding:'0.48rem 0.7rem',color:'#555',maxWidth:'200px',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{a.detail}</td>
                          <td style={{padding:'0.48rem 0.7rem',fontWeight:600}}>{a.by}</td>
                          <td style={{padding:'0.48rem 0.7rem',color:'#ef4444',fontWeight:700}}>{a.amount?`₹${a.amount}`:'—'}</td>
                          <td style={{padding:'0.48rem 0.7rem',color:'#888',fontSize:'0.75rem'}}>{fmtDateTimeShort(a.at)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })()}
        </>}

        {/* ═══════════ STAFF ═══════════ */}
        {section==='staff' && <>

          {/* ── Configuration Diagnostics ── */}
          <div style={card('#0d9488')}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'1rem',fontWeight:700,marginBottom:'0.2rem',color:'#1A0800'}}>⚙️ Configuration</h3>
            <p style={{fontSize:'0.78rem',color:'#888',marginBottom:'0.85rem'}}>
              Where each setting's active value is currently coming from. Environment Variable always wins when configured — change it in Vercel and redeploy to take effect.
            </p>
            {configDiagErr && <div style={{fontSize:'0.78rem',color:'#ef4444',marginBottom:'0.6rem'}}>❌ {configDiagErr}</div>}
            {!configDiag && !configDiagErr && <div style={{fontSize:'0.8rem',color:'#999'}}>Loading…</div>}
            {configDiag && (
              <>
                <div style={{display:'grid',gap:'0.6rem'}}>
                  {configDiag.settings.map(s => {
                    const sourceLabel = s.source==='env' ? 'Environment' : s.source==='admin' ? 'Admin' : 'Default';
                    const sourceColor = s.source==='env' ? '#7c3aed' : s.source==='admin' ? '#16a34a' : '#888';
                    return (
                      <div key={s.label} style={{border:'1px solid #eee',borderRadius:10,padding:'0.65rem 0.85rem'}}>
                        <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',flexWrap:'wrap',gap:'0.4rem'}}>
                          <div style={{fontWeight:700,fontSize:'0.85rem',color:'#1A0800'}}>{s.label}</div>
                          <span style={{background:sourceColor+'20',color:sourceColor,fontWeight:800,fontSize:'0.65rem',padding:'0.15rem 0.5rem',borderRadius:20,textTransform:'uppercase',letterSpacing:'0.03em'}}>Source: {sourceLabel}</span>
                        </div>
                        <div style={{fontSize:'0.82rem',color:'#333',marginTop:'0.25rem'}}>Effective: <strong>{s.value}</strong></div>
                        {s.source === 'env' && (
                          <div style={{fontSize:'0.72rem',color:'#7c3aed',marginTop:'0.3rem',fontWeight:600}}>
                            🔒 Controlled by Environment Variable <code style={{background:'#f5f0ff',padding:'0.05rem 0.35rem',borderRadius:4}}>{s.envVar}</code>
                            {s.adminValueShadowed != null && s.adminValueShadowed !== '' && (
                              <> — Admin value on file (<em>not active</em>): &ldquo;{s.adminValueShadowed}&rdquo;. Environment override active.</>
                            )}
                          </div>
                        )}
                        {s.source !== 'env' && s.envVar && (
                          <div style={{fontSize:'0.68rem',color:'#aaa',marginTop:'0.25rem'}}>
                            Can be overridden by setting <code style={{background:'#f5f5f5',padding:'0.05rem 0.35rem',borderRadius:4}}>{s.envVar}</code> (requires redeploy).
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
                <div style={{fontSize:'0.72rem',fontWeight:700,color:'#888',textTransform:'uppercase',letterSpacing:'0.04em',margin:'1rem 0 0.5rem'}}>Secrets (values never shown)</div>
                <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))',gap:'0.5rem'}}>
                  {configDiag.secrets.map(sec => (
                    <div key={sec.envVar} style={{border:'1px solid #eee',borderRadius:8,padding:'0.5rem 0.7rem',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                      <div>
                        <div style={{fontSize:'0.78rem',fontWeight:700,color:'#1A0800'}}>{sec.label}</div>
                        <code style={{fontSize:'0.65rem',color:'#999'}}>{sec.envVar}</code>
                      </div>
                      <span style={{fontSize:'0.7rem',fontWeight:800,color: sec.configured ? '#16a34a' : '#dc2626'}}>
                        {sec.configured ? '✅ Configured' : '❌ Not Set'}
                      </span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* ── Admin PIN Change ── */}
          <div style={card('#E65C00')}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'1rem',fontWeight:700,marginBottom:'0.2rem',color:'#1A0800'}}>🔐 Change Admin PIN</h3>
            <p style={{fontSize:'0.78rem',color:'#888',marginBottom:'0.85rem'}}>Used to login to this dashboard and authorise discounts. Requires your current PIN to change.</p>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:'0.75rem',alignItems:'flex-end'}}>
              <div>
                <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Current PIN</label>
                <input type="password" inputMode="numeric" value={adminPinOld} onChange={e=>setAdminPinOld(e.target.value.replace(/\D/g,''))} maxLength={8} placeholder="••••" style={{...inp,letterSpacing:'0.4em',textAlign:'center'}} />
              </div>
              <div>
                <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>New PIN</label>
                <input type="password" inputMode="numeric" value={adminNewPin} onChange={e=>setAdminNewPin(e.target.value.replace(/\D/g,''))} maxLength={8} placeholder="••••" style={{...inp,letterSpacing:'0.4em',textAlign:'center'}} />
              </div>
              <div>
                <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Confirm PIN</label>
                <input type="password" inputMode="numeric" value={adminNewPin2} onChange={e=>setAdminNewPin2(e.target.value.replace(/\D/g,''))} maxLength={8} placeholder="••••" style={{...inp,letterSpacing:'0.4em',textAlign:'center'}} />
              </div>
            </div>
            {adminPinMsg && <div style={{fontSize:'0.78rem',color:adminPinMsg.includes('✅')?'#16a34a':'#ef4444',margin:'0.5rem 0'}}>{adminPinMsg}</div>}
            <button onClick={changeAdminPin} style={{...btn('#E65C00'),marginTop:'0.75rem'}}>🔐 Update Admin PIN</button>
          </div>

          {/* ── Security Question ── */}
          <div style={card('#7c3aed')}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'1rem',fontWeight:700,marginBottom:'0.2rem',color:'#1A0800'}}>🛡️ PIN Recovery — Security Question</h3>
            <p style={{fontSize:'0.78rem',color:'#888',marginBottom:'0.75rem'}}>
              Set a security question so you can reset your PIN if you ever forget it.
              {secSetup && <span style={{color:'#16a34a',marginLeft:'0.3rem'}}>✅ Set up on {fmtDate(secSetup.setupAt)}</span>}
            </p>
            {secSetup && (
              <div style={{background:'#f0fdf4',borderRadius:8,padding:'0.6rem 0.85rem',marginBottom:'0.75rem',fontSize:'0.83rem',color:'#166534',fontWeight:600}}>
                Current question: &quot;{secSetup.question}&quot;
              </div>
            )}
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'0.75rem',marginBottom:'0.75rem'}}>
              <div style={{gridColumn:'1/-1'}}>
                <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Security Question</label>
                <select
                  value={secQuestion}
                  onChange={e=>setSecQuestion(e.target.value)}
                  style={{...inp,fontSize:'0.82rem'}}
                >
                  <option value="">— Select a question —</option>
                  {SECURITY_QUESTIONS.map(q=><option key={q} value={q}>{q}</option>)}
                </select>
              </div>
              <div>
                <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Your Answer</label>
                <input type="text" autoComplete="off" value={secAnswer} onChange={e=>setSecAnswer(e.target.value)} placeholder="Answer (not case sensitive)" style={{...inp,fontSize:'0.82rem'}} />
              </div>
              <div>
                <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Confirm Answer</label>
                <input type="text" autoComplete="off" value={secAnswerConf} onChange={e=>setSecAnswerConf(e.target.value)} placeholder="Re-enter answer" style={{...inp,fontSize:'0.82rem'}} />
              </div>
            </div>
            {secMsg && <div style={{fontSize:'0.78rem',color:secMsg.includes('✅')?'#16a34a':'#ef4444',marginBottom:'0.5rem'}}>{secMsg}</div>}
            <button onClick={saveSecurityQuestion} style={{...btn('#7c3aed')}}>🛡️ {secSetup?'Update':'Save'} Security Question</button>
          </div>

          {/* Kitchen & Manager PINs — write-only; current value never shown */}
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1rem',marginBottom:'1.5rem'}}>
            <div style={card('#3b82f6')}>
              <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'1rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>🔥 Kitchen PIN</h3>
              <p style={{fontSize:'0.78rem',color:'#666',marginBottom:'0.75rem'}}>Set a new PIN for kitchen staff at <code>/kitchen</code>. Leave blank to keep current.</p>
              <input
                value={kitchenPin}
                onChange={e=>setKitchenPin(e.target.value.replace(/\D/g,''))}
                maxLength={6} type="password" inputMode="numeric" placeholder="New PIN (4+ digits)"
                style={{...inp,letterSpacing:'0.4em',textAlign:'center',marginBottom:'0.5rem'}}
              />
              {kitchenPinMsg && <div style={{fontSize:'0.75rem',color:kitchenPinMsg.includes('✅')?'#16a34a':'#ef4444',marginBottom:'0.4rem'}}>{kitchenPinMsg}</div>}
              <button onClick={saveKitchenPinFn} style={{...btn('#3b82f6'),width:'100%'}}>💾 Set Kitchen PIN</button>
            </div>
            <div style={card('#16a34a')}>
              <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'1rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>💳 Manager PIN</h3>
              <p style={{fontSize:'0.78rem',color:'#666',marginBottom:'0.75rem'}}>Set a new PIN for manager billing at <code>/manager</code>. Leave blank to keep current.</p>
              <input
                value={managerPin}
                onChange={e=>setManagerPin(e.target.value.replace(/\D/g,''))}
                maxLength={6} type="password" inputMode="numeric" placeholder="New PIN (4+ digits)"
                style={{...inp,letterSpacing:'0.4em',textAlign:'center',marginBottom:'0.5rem'}}
              />
              {managerPinMsg && <div style={{fontSize:'0.75rem',color:managerPinMsg.includes('✅')?'#16a34a':'#ef4444',marginBottom:'0.4rem'}}>{managerPinMsg}</div>}
              <button onClick={saveManagerPinFn} style={{...btn('#16a34a'),width:'100%'}}>💾 Set Manager PIN</button>
            </div>
          </div>

          {/* Create Waiter Account */}
          <div style={card('#8b5cf6')}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'1rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>➕ Create Waiter Account</h3>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr auto',gap:'0.75rem',alignItems:'flex-end'}}>
              <div>
                <label style={{fontSize:'0.73rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Full Name</label>
                <input value={staffForm.name} onChange={e=>setStaffForm(f=>({...f,name:e.target.value}))} placeholder="e.g. Ravi Kumar" style={{...inp}} />
              </div>
              <div>
                <label style={{fontSize:'0.73rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Username</label>
                <input value={staffForm.username} onChange={e=>setStaffForm(f=>({...f,username:e.target.value}))} placeholder="e.g. ravi" style={{...inp}} />
              </div>
              <div>
                <label style={{fontSize:'0.73rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>PIN (4+ digits)</label>
                <input
                  type="password"
                  inputMode="numeric"
                  value={staffForm.pin}
                  onChange={e=>setStaffForm(f=>({...f,pin:e.target.value.replace(/\D/g,'')}))}
                  placeholder="••••"
                  maxLength={6}
                  style={{...inp,letterSpacing:'0.3em',textAlign:'center'}}
                />
              </div>
              <button onClick={addStaffAccount} style={{...btn('#8b5cf6'),padding:'0.65rem 1.1rem',whiteSpace:'nowrap' as const}}>✅ Add</button>
            </div>
            {staffMsg && <div style={{fontSize:'0.78rem',color:staffMsg.includes('✅')?'#16a34a':'#ef4444',marginTop:'0.5rem'}}>{staffMsg}</div>}
          </div>

          {/* Waiter Accounts List */}
          <div style={card()}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'1rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>
              🧑‍🍳 Waiter Accounts ({staffAccounts.length})
            </h3>
            {!staffAccounts.length
              ? <div style={{color:'#999',fontSize:'0.85rem',textAlign:'center',padding:'2rem 0'}}>No waiter accounts yet. Create one above.</div>
              : <div style={{overflowX:'auto'}}>
                  <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.83rem'}}>
                    <thead>
                      <tr style={{background:'#FFF5EB'}}>
                        {['Name','Username','Status','Created','Actions'].map(h=>(
                          <th key={h} style={{padding:'0.5rem 0.75rem',textAlign:'left',fontSize:'0.7rem',fontWeight:700,color:'#6B5246',textTransform:'uppercase'}}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {staffAccounts.map(acc=>(
                        <tr key={acc.id} style={{borderBottom:'1px solid #f5f0e8',opacity:acc.active?1:0.5}}>
                          <td style={{padding:'0.55rem 0.75rem',fontWeight:700}}>{acc.name}</td>
                          <td style={{padding:'0.55rem 0.75rem',color:'#666',fontFamily:'monospace'}}>{acc.username}</td>
                          <td style={{padding:'0.55rem 0.75rem'}}>
                            <span style={{fontSize:'0.72rem',fontWeight:700,padding:'0.18rem 0.5rem',borderRadius:10,background:acc.active?'#dcfce7':'#fee2e2',color:acc.active?'#16a34a':'#ef4444'}}>
                              {acc.active?'Active':'Inactive'}
                            </span>
                          </td>
                          <td style={{padding:'0.55rem 0.75rem',color:'#aaa',fontSize:'0.78rem'}}>
                            {acc.createdAt ? fmtDateLong(acc.createdAt) : '—'}
                          </td>
                          <td style={{padding:'0.55rem 0.75rem'}}>
                            <div style={{display:'flex',gap:'0.4rem',flexWrap:'wrap' as const}}>
                              <button
                                onClick={()=>{ void patchStaff(acc.id, { active: !acc.active }).then(() => refresh()); }}
                                style={{...btn(acc.active?'#fef2f2':'#f0fdf4',acc.active?'#ef4444':'#16a34a'),fontSize:'0.72rem',padding:'0.25rem 0.6rem',border:`1px solid ${acc.active?'#fecaca':'#bbf7d0'}`}}
                              >
                                {acc.active?'⛔ Disable':'✅ Enable'}
                              </button>
                              {editPinId===acc.id
                                ? <div style={{display:'flex',gap:'0.3rem',alignItems:'center'}}>
                                    <input
                                      type="password"
                                      inputMode="numeric"
                                      value={editPinVal}
                                      onChange={e=>setEditPinVal(e.target.value.replace(/\D/g,''))}
                                      placeholder="New PIN"
                                      maxLength={6}
                                      style={{width:'80px',padding:'0.25rem 0.4rem',border:'2px solid #e5e7eb',borderRadius:6,fontSize:'0.78rem',fontFamily:'Poppins,sans-serif',letterSpacing:'0.3em',textAlign:'center'}}
                                    />
                                    <button onClick={()=>{ if(editPinVal.length>=4){ void patchStaff(acc.id, { pin: editPinVal }).then(() => { setEditPinId(''); setEditPinVal(''); void refresh(); }); } }} style={{...btn('#3b82f6'),fontSize:'0.72rem',padding:'0.25rem 0.5rem'}}>Save</button>
                                    <button onClick={()=>{setEditPinId('');setEditPinVal('');}} style={{...btn('#e5e7eb','#555'),fontSize:'0.72rem',padding:'0.25rem 0.5rem'}}>✕</button>
                                  </div>
                                : <button onClick={()=>{ setEditPinId(acc.id); setEditPinVal(''); }} style={{...btn('#374151'),fontSize:'0.72rem',padding:'0.25rem 0.6rem'}}>🔑 PIN</button>
                              }
                              <button
                                onClick={()=>{ if(confirm(`Delete account for ${acc.name}?`)){void removeStaff(acc.id).then(() => refresh());} }}
                                style={{...btn('#ef4444'),fontSize:'0.72rem',padding:'0.25rem 0.6rem'}}
                              >
                                🗑️ Delete
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
            }
          </div>

          {/* ── Create Delivery Account ── */}
          <div style={card('#0f172a')}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'1rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>➕ Create Delivery Account</h3>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr auto',gap:'0.75rem',alignItems:'flex-end'}}>
              <div>
                <label style={{fontSize:'0.73rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Full Name</label>
                <input value={deliveryForm.name} onChange={e=>setDeliveryForm(f=>({...f,name:e.target.value}))} placeholder="e.g. Ravi Kumar" style={{...inp}} />
              </div>
              <div>
                <label style={{fontSize:'0.73rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Username</label>
                <input value={deliveryForm.username} onChange={e=>setDeliveryForm(f=>({...f,username:e.target.value}))} placeholder="e.g. ravi" style={{...inp}} />
              </div>
              <div>
                <label style={{fontSize:'0.73rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>PIN (4+ digits)</label>
                <input
                  type="password"
                  inputMode="numeric"
                  value={deliveryForm.pin}
                  onChange={e=>setDeliveryForm(f=>({...f,pin:e.target.value.replace(/\D/g,'')}))}
                  placeholder="••••"
                  maxLength={6}
                  style={{...inp,letterSpacing:'0.3em',textAlign:'center'}}
                />
              </div>
              <button onClick={addDeliveryAccount} style={{...btn('#0f172a'),padding:'0.65rem 1.1rem',whiteSpace:'nowrap' as const}}>✅ Add</button>
            </div>
            {deliveryMsg && <div style={{fontSize:'0.78rem',color:deliveryMsg.includes('✅')?'#16a34a':'#ef4444',marginTop:'0.5rem'}}>{deliveryMsg}</div>}
          </div>

          {/* ── Delivery Accounts List ── */}
          <div style={card()}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'1rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>
              🛵 Delivery Accounts ({deliveryAccounts.length})
            </h3>
            {!deliveryAccounts.length
              ? <div style={{color:'#999',fontSize:'0.85rem',textAlign:'center',padding:'2rem 0'}}>No delivery accounts yet. Create one above.</div>
              : <div style={{overflowX:'auto'}}>
                  <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.83rem'}}>
                    <thead>
                      <tr style={{background:'#f8fafc'}}>
                        {['Name','Username','Status','Created','Actions'].map(h=>(
                          <th key={h} style={{padding:'0.5rem 0.75rem',textAlign:'left',fontSize:'0.7rem',fontWeight:700,color:'#475569',textTransform:'uppercase'}}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {deliveryAccounts.map(acc=>(
                        <tr key={acc.id} style={{borderBottom:'1px solid #f1f5f9',opacity:acc.active?1:0.5}}>
                          <td style={{padding:'0.55rem 0.75rem',fontWeight:700}}>{acc.name}</td>
                          <td style={{padding:'0.55rem 0.75rem',color:'#666',fontFamily:'monospace'}}>{acc.username}</td>
                          <td style={{padding:'0.55rem 0.75rem'}}>
                            <span style={{fontSize:'0.72rem',fontWeight:700,padding:'0.18rem 0.5rem',borderRadius:10,background:acc.active?'#dcfce7':'#fee2e2',color:acc.active?'#16a34a':'#ef4444'}}>
                              {acc.active?'Active':'Inactive'}
                            </span>
                          </td>
                          <td style={{padding:'0.55rem 0.75rem',color:'#aaa',fontSize:'0.78rem'}}>
                            {acc.createdAt ? fmtDateLong(acc.createdAt) : '—'}
                          </td>
                          <td style={{padding:'0.55rem 0.75rem'}}>
                            <div style={{display:'flex',gap:'0.4rem',flexWrap:'wrap' as const}}>
                              <button
                                onClick={()=>{ void patchStaff(acc.id, { active: !acc.active }).then(() => refresh()); }}
                                style={{...btn(acc.active?'#fef2f2':'#f0fdf4',acc.active?'#ef4444':'#16a34a'),fontSize:'0.72rem',padding:'0.25rem 0.6rem',border:`1px solid ${acc.active?'#fecaca':'#bbf7d0'}`}}
                              >
                                {acc.active?'⛔ Disable':'✅ Enable'}
                              </button>
                              {editDelivPinId===acc.id
                                ? <div style={{display:'flex',gap:'0.3rem',alignItems:'center'}}>
                                    <input
                                      type="password"
                                      inputMode="numeric"
                                      value={editDelivPinVal}
                                      onChange={e=>setEditDelivPinVal(e.target.value.replace(/\D/g,''))}
                                      placeholder="New PIN"
                                      maxLength={6}
                                      style={{width:'80px',padding:'0.25rem 0.4rem',border:'2px solid #e5e7eb',borderRadius:6,fontSize:'0.78rem',fontFamily:'Poppins,sans-serif',letterSpacing:'0.3em',textAlign:'center'}}
                                    />
                                    <button onClick={()=>{ if(editDelivPinVal.length>=4){ void patchStaff(acc.id, { pin: editDelivPinVal }).then(() => { setEditDelivPinId(''); setEditDelivPinVal(''); void refresh(); }); } }} style={{...btn('#3b82f6'),fontSize:'0.72rem',padding:'0.25rem 0.5rem'}}>Save</button>
                                    <button onClick={()=>{setEditDelivPinId('');setEditDelivPinVal('');}} style={{...btn('#e5e7eb','#555'),fontSize:'0.72rem',padding:'0.25rem 0.5rem'}}>✕</button>
                                  </div>
                                : <button onClick={()=>{ setEditDelivPinId(acc.id); setEditDelivPinVal(''); }} style={{...btn('#374151'),fontSize:'0.72rem',padding:'0.25rem 0.6rem'}}>🔑 PIN</button>
                              }
                              <button
                                onClick={()=>{ if(confirm(`Delete account for ${acc.name}?`)){void removeStaff(acc.id).then(() => refresh());} }}
                                style={{...btn('#ef4444'),fontSize:'0.72rem',padding:'0.25rem 0.6rem'}}
                              >
                                🗑️ Delete
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
            }
          </div>

          {/* Staff portal links */}
          <div style={card()}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'1rem',fontWeight:700,marginBottom:'0.75rem',color:'#1A0800'}}>🔗 Staff Portal Links</h3>
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))',gap:'0.65rem'}}>
              {[
                {href:'/kitchen/login',  label:'🔥 Kitchen Login',    color:'#3b82f6'},
                {href:'/waiter/login',   label:'🧑‍🍳 Waiter Login',    color:'#8b5cf6'},
                {href:'/delivery/login', label:'🛵 Delivery Login',   color:'#0f172a'},
                {href:'/manager/login',  label:'💳 Manager Login',    color:'#16a34a'},
                {href:'/admin/login',    label:'🔧 Admin Login',      color:'#E65C00'},
                {href:'/online',         label:'📦 Online Ordering',  color:'#06b6d4'},
                {href:'/',               label:'🪑 Dine-In Menu',     color:'#f59e0b'},
              ].map(l=>(
                <a key={l.href} href={l.href} target="_blank" rel="noreferrer" style={{padding:'0.65rem 1rem',background:l.color,color:'white',borderRadius:8,fontWeight:700,textDecoration:'none',fontSize:'0.82rem',textAlign:'center',display:'block'}}>
                  {l.label}
                </a>
              ))}
            </div>
          </div>

          {/* ── Targeted Order Deletion ── */}
          <div style={{border:'2px solid #fed7aa',borderRadius:12,padding:'1.25rem',background:'#fff7ed',marginBottom:'1.25rem'}}>
            <div style={{display:'flex',alignItems:'center',gap:'0.6rem',marginBottom:'0.85rem'}}>
              <span style={{fontSize:'1.3rem'}}>🎯</span>
              <div>
                <div style={{fontWeight:800,color:'#c2410c',fontSize:'0.92rem'}}>Delete Specific Orders</div>
                <div style={{fontSize:'0.72rem',color:'#ea580c',marginTop:'0.08rem'}}>Delete by order ID, by date, or by date+time range (IST). Requires Admin PIN.</div>
              </div>
            </div>

            {/* Mode selector */}
            <div style={{display:'flex',background:'#ffe8cc',borderRadius:10,padding:'3px',marginBottom:'1rem',gap:'2px'}}>
              {(['id','date','range'] as const).map(m=>(
                <button key={m} onClick={()=>{setDelMode(m);setDelPreview(null);setDelMsg('');}}
                  style={{flex:1,padding:'0.45rem 0.25rem',borderRadius:8,border:'none',cursor:'pointer',
                    fontFamily:'Poppins,sans-serif',fontWeight:700,fontSize:'0.72rem',whiteSpace:'nowrap' as const,
                    background:delMode===m?'white':'transparent',
                    color:delMode===m?'#c2410c':'#888',
                    boxShadow:delMode===m?'0 2px 8px rgba(0,0,0,0.1)':'none'}}>
                  {m==='id'?'🆔 Order ID':m==='date'?'📅 Single Date':'🕐 Date+Time Range'}
                </button>
              ))}
            </div>

            {/* ── Mode: by ID ── */}
            {delMode==='id' && (
              <div style={{marginBottom:'0.85rem'}}>
                <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Order ID</label>
                <input
                  value={delOrderId}
                  onChange={e=>{setDelOrderId(e.target.value);setDelMsg('');setDelPreview(null);}}
                  placeholder="e.g. ord_abc123"
                  style={{...inp,fontFamily:'monospace',fontSize:'0.85rem'}}
                />
                <div style={{fontSize:'0.68rem',color:'#888',marginTop:'0.2rem'}}>Find it in the Orders tab — shown as the order ID on each card.</div>
              </div>
            )}

            {/* ── Mode: by date ── */}
            {delMode==='date' && (
              <div style={{marginBottom:'0.85rem'}}>
                <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Date (IST)</label>
                <input
                  type="date"
                  value={delDate}
                  onChange={e=>{setDelDate(e.target.value);setDelPreview(null);setDelMsg('');}}
                  style={{...inp}}
                />
                {delDate && (
                  <button onClick={fetchDelPreview} style={{...btn('#f97316'),marginTop:'0.5rem',fontSize:'0.75rem',padding:'0.35rem 0.9rem'}}>
                    🔍 Preview count
                  </button>
                )}
              </div>
            )}

            {/* ── Mode: by range ── */}
            {delMode==='range' && (
              <div style={{marginBottom:'0.85rem'}}>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'0.6rem',marginBottom:'0.5rem'}}>
                  <div>
                    <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>From Date (IST)</label>
                    <input type="date" value={delDateFrom} onChange={e=>{setDelDateFrom(e.target.value);setDelPreview(null);setDelMsg('');}} style={{...inp}} />
                  </div>
                  <div>
                    <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>To Date (IST)</label>
                    <input type="date" value={delDateTo} onChange={e=>{setDelDateTo(e.target.value);setDelPreview(null);setDelMsg('');}} style={{...inp}} />
                  </div>
                  <div>
                    <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>From Time (IST 24h)</label>
                    <input type="time" value={delTimeFrom} onChange={e=>{setDelTimeFrom(e.target.value);setDelPreview(null);}} style={{...inp}} />
                  </div>
                  <div>
                    <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>To Time (IST 24h)</label>
                    <input type="time" value={delTimeTo} onChange={e=>{setDelTimeTo(e.target.value);setDelPreview(null);}} style={{...inp}} />
                  </div>
                </div>
                {delDateFrom && delDateTo && (
                  <button onClick={fetchDelPreview} style={{...btn('#f97316'),fontSize:'0.75rem',padding:'0.35rem 0.9rem'}}>
                    🔍 Preview count
                  </button>
                )}
              </div>
            )}

            {/* Preview badge */}
            {delPreview !== null && (
              <div style={{
                background: delPreview===0?'#f0fdf4':'#fff3cd',
                border:`1px solid ${delPreview===0?'#bbf7d0':'#ffc107'}`,
                borderRadius:8,padding:'0.5rem 0.85rem',
                fontSize:'0.78rem',fontWeight:700,
                color:delPreview===0?'#166534':'#856404',
                marginBottom:'0.75rem',
              }}>
                {delPreview===0
                  ? '✅ No orders match — nothing will be deleted.'
                  : `⚠️ ${delPreview} order${delPreview!==1?'s':''} will be permanently deleted.`}
              </div>
            )}

            {/* PIN + confirm button */}
            <div style={{display:'flex',gap:'0.65rem',alignItems:'flex-end',flexWrap:'wrap' as const}}>
              <div style={{flex:1,minWidth:130}}>
                <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Admin PIN</label>
                <input
                  type="password" inputMode="numeric"
                  value={delPin}
                  onChange={e=>setDelPin(e.target.value.replace(/\D/g,''))}
                  maxLength={8} placeholder="••••"
                  style={{...inp,letterSpacing:'0.4em',textAlign:'center' as const}}
                />
              </div>
              <button
                onClick={executeDelSelective}
                disabled={delBusy}
                style={{
                  ...btn('#c2410c'),padding:'0.65rem 1.1rem',
                  fontSize:'0.82rem',whiteSpace:'nowrap' as const,
                  opacity:delBusy?0.6:1,
                  cursor:delBusy?'not-allowed':'pointer',
                }}
              >
                {delBusy?'⏳ Deleting…':'🗑️ Delete'}
              </button>
            </div>
            {delMsg && (
              <div style={{
                fontSize:'0.78rem',
                color:delMsg.includes('✅')?'#16a34a':delMsg.includes('⏳')?'#555':'#ef4444',
                marginTop:'0.5rem',fontWeight:600,
              }}>{delMsg}</div>
            )}
          </div>

          {/* ── Danger Zone: Clear All Orders ── */}
          <div style={{border:'2px solid #fecaca',borderRadius:12,padding:'1.25rem',background:'#fef2f2',marginBottom:'1.5rem'}}>
            <div style={{display:'flex',alignItems:'center',gap:'0.6rem',marginBottom:'0.5rem'}}>
              <span style={{fontSize:'1.4rem'}}>🗑️</span>
              <div>
                <div style={{fontWeight:800,color:'#dc2626',fontSize:'0.95rem'}}>Danger Zone — Clear All Orders</div>
                <div style={{fontSize:'0.75rem',color:'#ef4444',marginTop:'0.1rem'}}>Permanently deletes ALL orders, items, and events from the database. This cannot be undone.</div>
              </div>
            </div>
            <div style={{background:'#fff',border:'1px solid #fecaca',borderRadius:8,padding:'0.9rem',marginBottom:'0.75rem'}}>
              <div style={{fontSize:'0.8rem',color:'#666',marginBottom:'0.6rem'}}>
                Use this only to clear dummy/test data before going live. Once deleted, orders <strong>cannot be recovered</strong>.
              </div>
              <label style={{display:'flex',alignItems:'flex-start',gap:'0.5rem',cursor:'pointer',marginBottom:'0.75rem'}}>
                <input
                  type="checkbox"
                  checked={clearConfirm}
                  onChange={e=>setClearConfirm(e.target.checked)}
                  style={{marginTop:'0.15rem',accentColor:'#dc2626',width:16,height:16,flexShrink:0}}
                />
                <span style={{fontSize:'0.8rem',color:'#555',lineHeight:1.4}}>
                  I understand this will permanently delete ALL orders from the live database and this action cannot be undone.
                </span>
              </label>
              <div style={{display:'flex',gap:'0.65rem',alignItems:'flex-end',flexWrap:'wrap' as const}}>
                <div style={{flex:1,minWidth:140}}>
                  <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Admin PIN to confirm</label>
                  <input
                    type="password"
                    inputMode="numeric"
                    value={clearPin}
                    onChange={e=>setClearPin(e.target.value.replace(/\D/g,''))}
                    maxLength={8}
                    placeholder="••••"
                    style={{...inp,letterSpacing:'0.4em',textAlign:'center' as const}}
                  />
                </div>
                <button
                  onClick={clearAllOrders}
                  disabled={clearBusy || !clearConfirm}
                  style={{
                    ...btn('#dc2626'),
                    padding:'0.65rem 1.25rem',
                    fontSize:'0.82rem',
                    whiteSpace:'nowrap' as const,
                    opacity: clearBusy || !clearConfirm ? 0.55 : 1,
                    cursor: clearBusy || !clearConfirm ? 'not-allowed' : 'pointer',
                  }}
                >
                  {clearBusy ? '⏳ Clearing…' : '🗑️ Clear All Orders'}
                </button>
              </div>
              {clearMsg && (
                <div style={{
                  fontSize:'0.8rem',
                  color:clearMsg.includes('✅')?'#16a34a':clearMsg.includes('⏳')?'#555':'#ef4444',
                  marginTop:'0.5rem',
                  fontWeight:600,
                }}>
                  {clearMsg}
                </div>
              )}
            </div>
          </div>
        </>}

        {/* ═══════════ EMAIL DIAGNOSTICS ═══════════ */}
        {section==='email' && <>
          <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,fontSize:'1.15rem',marginBottom:'1rem',color:'#1A0800'}}>📧 Email Diagnostics</div>

          {/* Config status card */}
          <div style={{...card('#E65C00'),marginBottom:'1rem'}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'0.75rem'}}>
              <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'1rem',fontWeight:700,color:'#1A0800',margin:0}}>Resend Configuration</h3>
              <button
                onClick={async()=>{
                  setEmailDiagLoading(true); setEmailDiagError('');
                  try {
                    const r = await fetch('/api/email/diagnostics');
                    const d = await r.json() as typeof emailDiag;
                    setEmailDiag(d);
                  } catch(e){ setEmailDiagError(String(e)); }
                  setEmailDiagLoading(false);
                }}
                style={{...btn(),padding:'0.3rem 0.8rem',fontSize:'0.75rem'}}
              >{emailDiagLoading ? '⏳ Checking…' : '🔍 Check Status'}</button>
            </div>

            {emailDiagError && <div style={{background:'#fef2f2',color:'#dc2626',borderRadius:8,padding:'0.5rem',fontSize:'0.78rem',marginBottom:'0.75rem'}}>❌ {emailDiagError}</div>}

            {emailDiag && (
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'0.6rem'}}>
                {[
                  {label:'RESEND_API_KEY set?',    value: emailDiag.apiKeyPresent ? `✅ Yes (${emailDiag.apiKeyLength} chars)` : '❌ Not set',                                                     ok: emailDiag.apiKeyPresent},
                  {label:'Configured & valid?',     value: emailDiag.configured   ? '✅ Yes — ready to send' : '❌ No — placeholder or missing',                                                     ok: emailDiag.configured},
                  {label:'FROM_EMAIL set?',         value: emailDiag.fromEmailConfigured ? `✅ ${emailDiag.fromEmail}` : '❌ FROM_EMAIL env var not set',                                             ok: emailDiag.fromEmailConfigured},
                  {label:'Sending domain',          value: emailDiag.fromEmailDomain     ? `✅ ${emailDiag.fromEmailDomain}` : '❌ Cannot determine — FROM_EMAIL missing',                           ok: Boolean(emailDiag.fromEmailDomain)},
                  {label:'Queue errors?',           value: emailDiag.queueError   ? `❌ ${emailDiag.queueError}` : '✅ None',                                                                        ok: !emailDiag.queueError},
                  {label:'Queue summary',           value: `Total: ${emailDiag.queueSummary.total} | ✅ Sent: ${emailDiag.queueSummary.sent} | ❌ Failed: ${emailDiag.queueSummary.failed} | ⏳ Pending: ${emailDiag.queueSummary.pending}`, ok: emailDiag.queueSummary.failed === 0},
                ].map(row=>(
                  <div key={row.label} style={{background:'white',borderRadius:8,padding:'0.5rem 0.75rem',border:`1px solid ${row.ok?'#dcfce7':'#fecaca'}`}}>
                    <div style={{fontSize:'0.65rem',fontWeight:700,color:'#888',textTransform:'uppercase',letterSpacing:1,marginBottom:'0.2rem'}}>{row.label}</div>
                    <div style={{fontSize:'0.8rem',fontWeight:600,color:row.ok?'#16a34a':'#dc2626'}}>{row.value}</div>
                  </div>
                ))}
              </div>
            )}

            {emailDiag?.lastEntry && (
              <div style={{marginTop:'0.75rem',background:'white',borderRadius:8,padding:'0.6rem 0.85rem',border:'1px solid #e5e7eb'}}>
                <div style={{fontSize:'0.65rem',fontWeight:700,color:'#888',textTransform:'uppercase',letterSpacing:1,marginBottom:'0.3rem'}}>Last Queue Entry</div>
                <div style={{display:'flex',gap:'1rem',flexWrap:'wrap' as const,fontSize:'0.78rem'}}>
                  <span>Status: <strong style={{color:emailDiag.lastEntry.status==='sent'?'#16a34a':emailDiag.lastEntry.status==='failed'?'#dc2626':'#f59e0b'}}>{emailDiag.lastEntry.status}</strong></span>
                  <span>Created: {fmtDateTime(emailDiag.lastEntry.created_at)}</span>
                  {emailDiag.lastEntry.error && <span style={{color:'#dc2626'}}>Error: {emailDiag.lastEntry.error}</span>}
                </div>
              </div>
            )}

            {!emailDiag && !emailDiagLoading && (
              <div style={{fontSize:'0.8rem',color:'#888',textAlign:'center',padding:'1rem 0'}}>Click &quot;Check Status&quot; to load diagnostics</div>
            )}
          </div>

          {/* Recent queue table */}
          {emailDiag && emailDiag.recentQueue.length > 0 && (
            <div style={{...card('#E65C00'),marginBottom:'1rem'}}>
              <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'1rem',fontWeight:700,color:'#1A0800',marginBottom:'0.75rem'}}>Recent Email Queue (last 10)</h3>
              <div style={{overflowX:'auto'}}>
                <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.75rem'}}>
                  <thead>
                    <tr style={{background:'#f8fafc'}}>
                      {['Order ID','Status','Retries','Created','Error'].map(h=>(
                        <th key={h} style={{padding:'0.4rem 0.5rem',textAlign:'left',fontWeight:700,color:'#64748b',borderBottom:'1px solid #e2e8f0'}}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {emailDiag.recentQueue.map(row=>(
                      <tr key={row.id} style={{borderBottom:'1px solid #f1f5f9'}}>
                        <td style={{padding:'0.35rem 0.5rem',fontFamily:'monospace',fontSize:'0.7rem',color:'#64748b'}}>{row.order_id?.slice(-8) ?? '—'}</td>
                        <td style={{padding:'0.35rem 0.5rem'}}>
                          <span style={{padding:'0.1rem 0.45rem',borderRadius:20,fontSize:'0.68rem',fontWeight:700,background:row.status==='sent'?'#dcfce7':row.status==='failed'?'#fef2f2':'#fef3c7',color:row.status==='sent'?'#16a34a':row.status==='failed'?'#dc2626':'#d97706'}}>{row.status}</span>
                        </td>
                        <td style={{padding:'0.35rem 0.5rem',textAlign:'center',color:'#64748b'}}>{row.retry_count}</td>
                        <td style={{padding:'0.35rem 0.5rem',color:'#94a3b8'}}>{fmtDateTimeShort(row.created_at)}</td>
                        <td style={{padding:'0.35rem 0.5rem',color:'#ef4444',maxWidth:200,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap' as const}}>{row.error ?? '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Test email */}
          <div style={{...card('#E65C00')}}>
            <h3 style={{fontFamily:"'Playfair Display',serif",fontSize:'1rem',fontWeight:700,color:'#1A0800',marginBottom:'0.25rem'}}>📤 Send Test Email</h3>
            <p style={{fontSize:'0.78rem',color:'#888',marginBottom:'0.85rem'}}>Sends a test email via Resend to verify end-to-end delivery. Check server logs for details.</p>
            <div style={{display:'flex',gap:'0.6rem',alignItems:'center'}}>
              <input
                type="email"
                value={testEmailTo}
                onChange={e=>setTestEmailTo(e.target.value)}
                placeholder="your@email.com"
                style={{flex:1,padding:'0.6rem 0.85rem',border:'2px solid #e5e7eb',borderRadius:10,fontFamily:'Poppins,sans-serif',fontSize:'0.85rem',outline:'none'}}
              />
              <button
                onClick={async()=>{
                  if (!testEmailTo.includes('@')) { setTestEmailResult('❌ Enter a valid email address'); return; }
                  setTestEmailBusy(true); setTestEmailResult('⏳ Sending…');
                  try {
                    const r = await fetch(`/api/test-email?to=${encodeURIComponent(testEmailTo)}`);
                    const d = await r.json() as {ok:boolean;messageId?:string;error?:string;sentTo?:string};
                    if (d.ok) {
                      setTestEmailResult(`✅ Sent! messageId: ${d.messageId ?? '?'} → ${d.sentTo ?? testEmailTo}`);
                    } else {
                      setTestEmailResult(`❌ Failed: ${d.error ?? 'Unknown error'}`);
                    }
                  } catch(e){ setTestEmailResult(`❌ ${String(e)}`); }
                  setTestEmailBusy(false);
                }}
                disabled={testEmailBusy}
                style={{...btn(),padding:'0.6rem 1.1rem',whiteSpace:'nowrap' as const,opacity:testEmailBusy?0.7:1}}
              >📧 Send Test</button>
            </div>
            {testEmailResult && (
              <div style={{marginTop:'0.6rem',padding:'0.5rem 0.75rem',borderRadius:8,background:testEmailResult.startsWith('✅')?'#dcfce7':testEmailResult.startsWith('❌')?'#fef2f2':'#f1f5f9',fontSize:'0.78rem',fontWeight:600,color:testEmailResult.startsWith('✅')?'#16a34a':testEmailResult.startsWith('❌')?'#dc2626':'#475569'}}>
                {testEmailResult}
              </div>
            )}
            <div style={{marginTop:'0.85rem',padding:'0.6rem',background:'#f8fafc',borderRadius:8,fontSize:'0.72rem',color:'#64748b'}}>
              <strong>Troubleshooting checklist:</strong><br/>
              1. <code>RESEND_API_KEY</code> set in Vercel → Settings → Environment Variables<br/>
              2. <code>FROM_EMAIL</code> set in Vercel → e.g. <code>Foodie Lover &lt;noreply@yourdomain.com&gt;</code><br/>
              3. The domain in <code>FROM_EMAIL</code> must be verified in Resend → Domains<br/>
              4. Customer must have provided email at order time (check their order/tab record)<br/>
              5. Check Vercel function logs for <code>[sendEmail]</code> entries<br/>
              6. Flush the retry queue via: <code>GET /api/email/process-queue</code> (with Authorization header)
            </div>
          </div>
        </>}

        {/* ═══════════ FEEDBACK ═══════════ */}
        {section==='feedback' && <>
          <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,fontSize:'1.15rem',marginBottom:'1rem',color:'#1A0800'}}>⭐ Customer Feedback</div>
          <button
            style={{...btn(),marginBottom:'1rem'}}
            onClick={async()=>{
              const r = await fetch('/api/admin/feedback');
              const d = await r.json() as FeedbackRow[];
              setFeedbackRows(d);
              setFeedbackLoaded(true);
            }}
          >{feedbackLoaded ? '🔄 Refresh' : '📥 Load Feedback'}</button>
          {feedbackLoaded && (
            <div style={{overflowX:'auto'}}>
              {feedbackRows.length === 0
                ? <p style={{color:'#888',fontSize:'0.85rem'}}>No feedback yet.</p>
                : <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.82rem'}}>
                  <thead><tr style={{background:'#fff5ed'}}>
                    {['Date','Order #','Customer','Type','Rating','Comment'].map(h=><th key={h} style={{padding:'0.5rem 0.75rem',textAlign:'left',fontWeight:700,color:'#6B5246',fontSize:'0.72rem',textTransform:'uppercase'}}>{h}</th>)}
                  </tr></thead>
                  <tbody>
                    {feedbackRows.map(f=>(
                      <tr key={f.id} style={{borderBottom:'1px solid #f5f0e8'}}>
                        <td style={{padding:'0.45rem 0.75rem',whiteSpace:'nowrap' as const}}>{fmtDateTimeShort(f.created_at)}</td>
                        <td style={{padding:'0.45rem 0.75rem'}}>#{f.orders?.order_number ?? '—'}</td>
                        <td style={{padding:'0.45rem 0.75rem'}}>{f.orders?.customer_name ?? '—'}</td>
                        <td style={{padding:'0.45rem 0.75rem'}}>{f.orders?.type ?? '—'}</td>
                        <td style={{padding:'0.45rem 0.75rem',fontWeight:800,color:'#E65C00'}}>{'⭐'.repeat(f.rating)}</td>
                        <td style={{padding:'0.45rem 0.75rem',color:'#555',maxWidth:300}}>{f.comment || <span style={{color:'#bbb'}}>—</span>}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              }
            </div>
          )}
        </>}

        {/* ═══════════ SPIN & WIN ═══════════ */}
        {section==='spin' && <>
          <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,fontSize:'1.15rem',marginBottom:'1rem',color:'#1A0800'}}>🎡 Spin & Win Configuration</div>
          <button
            style={{...btn(),marginBottom:'1rem'}}
            onClick={async()=>{
              const [cfgRes, rwdRes, kitRes] = await Promise.all([
                fetch('/api/admin/spin-config').then(r=>r.json()),
                fetch('/api/admin/spin-rewards').then(r=>r.json()),
                fetch('/api/admin/restaurant-config').then(r=>r.json()),
              ]);
              setSpinConfig(cfgRes as SpinConfigRow);
              setSpinRewards(rwdRes as SpinRewardRow[]);
              const km = (kitRes as Record<string,unknown>).kitchen_mode;
              if (km === 'ask' || km === 'printer' || km === 'kitchen_display') setKitchenMode(km);
              setSpinLoaded(true);
            }}
          >{spinLoaded ? '🔄 Refresh' : '📥 Load Config'}</button>

          {spinLoaded && <>
            {/* Config form */}
            <div style={{...card('#7c3aed'),marginBottom:'1rem'}}>
              <h3 style={{margin:'0 0 1rem',fontWeight:700,color:'#1A0800',fontSize:'1rem'}}>Global Settings</h3>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'0.75rem',marginBottom:'1rem'}}>
                <label style={{display:'flex',alignItems:'center',gap:'0.5rem',fontSize:'0.85rem',fontWeight:700,cursor:'pointer'}}>
                  <input type="checkbox" checked={spinConfig.enabled} onChange={e=>setSpinConfig(c=>({...c,enabled:e.target.checked}))} />
                  Enable Spin & Win
                </label>
                <label style={{display:'flex',alignItems:'center',gap:'0.5rem',fontSize:'0.85rem',fontWeight:700,cursor:'pointer'}}>
                  <input type="checkbox" checked={spinConfig.require_email} onChange={e=>setSpinConfig(c=>({...c,require_email:e.target.checked}))} />
                  Require Email
                </label>
                <label style={{display:'flex',alignItems:'center',gap:'0.5rem',fontSize:'0.85rem',fontWeight:700,cursor:'pointer'}}>
                  <input type="checkbox" checked={spinConfig.require_phone} onChange={e=>setSpinConfig(c=>({...c,require_phone:e.target.checked}))} />
                  Require Phone
                </label>
                <div>
                  <label style={{fontSize:'0.75rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.25rem'}}>Min Order Amount (₹)</label>
                  <input type="number" value={spinConfig.min_order_amount} onChange={e=>setSpinConfig(c=>({...c,min_order_amount:Number(e.target.value)}))} style={{...inp}} />
                </div>
              </div>
              <div style={{marginBottom:'1rem'}}>
                <div style={{fontSize:'0.75rem',fontWeight:700,color:'#555',marginBottom:'0.4rem'}}>Eligible Order Types</div>
                {(['dine-in','pickup','delivery'] as const).map(t=>(
                  <label key={t} style={{display:'inline-flex',alignItems:'center',gap:'0.4rem',marginRight:'1rem',fontSize:'0.85rem',cursor:'pointer'}}>
                    <input type="checkbox"
                      checked={spinConfig.eligible_order_types.includes(t)}
                      onChange={e=>setSpinConfig(c=>({
                        ...c,
                        eligible_order_types: e.target.checked
                          ? [...c.eligible_order_types, t]
                          : c.eligible_order_types.filter(x=>x!==t)
                      }))}
                    /> {t}
                  </label>
                ))}
              </div>
              <button
                onClick={async()=>{
                  setSpinMsg('⏳ Saving…');
                  const r = await fetch('/api/admin/spin-config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(spinConfig)});
                  const d = await r.json() as {ok?:boolean;error?:string};
                  setSpinMsg(d.ok ? '✅ Config saved!' : `❌ ${d.error ?? 'Error'}`);
                  setTimeout(()=>setSpinMsg(''),3000);
                }}
                style={{...btn('#7c3aed')}}
              >💾 Save Config</button>
              {spinMsg && <span style={{marginLeft:'0.75rem',fontSize:'0.8rem',fontWeight:700,color:spinMsg.includes('✅')?'#16a34a':'#ef4444'}}>{spinMsg}</span>}
            </div>

            {/* Kitchen routing mode */}
            <div style={{...card('#0f766e'),marginBottom:'1rem'}}>
              <h3 style={{margin:'0 0 0.5rem',fontWeight:700,color:'#1A0800',fontSize:'1rem'}}>🔥 Kitchen Routing Mode</h3>
              <p style={{fontSize:'0.78rem',color:'#555',marginBottom:'0.75rem'}}>Controls how confirmed orders reach the kitchen. Affects the waiter portal buttons.</p>
              <select
                value={kitchenMode}
                onChange={e=>setKitchenMode(e.target.value as 'ask'|'printer'|'kitchen_display')}
                style={{...inp,marginBottom:'0.75rem',maxWidth:300}}
              >
                <option value="ask">Ask each time (show both Print KOT + Kitchen Display buttons)</option>
                <option value="printer">Printer only (always print KOT, no kitchen display button)</option>
                <option value="kitchen_display">Kitchen display only (no print KOT button)</option>
              </select>
              <div>
                <button
                  onClick={async()=>{
                    setKitchenModeMsg('⏳ Saving…');
                    const r = await fetch('/api/admin/restaurant-config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kitchen_mode:kitchenMode})});
                    const d = await r.json() as {ok?:boolean;error?:string};
                    setKitchenModeMsg(d.ok ? '✅ Kitchen mode saved!' : `❌ ${d.error ?? 'Error'}`);
                    setTimeout(()=>setKitchenModeMsg(''),3000);
                  }}
                  style={{...btn('#0f766e')}}
                >💾 Save Kitchen Mode</button>
                {kitchenModeMsg && <span style={{marginLeft:'0.75rem',fontSize:'0.8rem',fontWeight:700,color:kitchenModeMsg.includes('✅')?'#16a34a':'#ef4444'}}>{kitchenModeMsg}</span>}
              </div>
            </div>

            {/* ── Rewards list ─────────────────────────────────────────── */}
            <div style={{...card('#E65C00'),marginBottom:'1rem'}}>

              {/* Header */}
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'0.6rem',flexWrap:'wrap',gap:'0.5rem'}}>
                <h3 style={{margin:0,fontWeight:700,color:'#1A0800',fontSize:'1rem'}}>Spin Rewards</h3>
                {spinRewards.length > 0 && (()=>{
                  const totalW = spinRewards.filter(r=>r.active).reduce((s,r)=>s+r.weight,0);
                  return <span style={{background:'#fff5ed',border:'1px solid #E65C00',borderRadius:20,padding:'0.2rem 0.75rem',fontSize:'0.75rem',fontWeight:700,color:'#E65C00'}}>Active Weight: {totalW}</span>;
                })()}
              </div>

              {/* Toolbar */}
              <div style={{display:'flex',gap:'0.5rem',marginBottom:'0.75rem',flexWrap:'wrap',alignItems:'center'}}>
                <label style={{...btn('#3b82f6'),cursor:'pointer',display:'inline-flex',alignItems:'center',gap:'0.3rem',opacity:spinImportBusy?0.6:1}}>
                  {spinImportBusy?'⏳ Parsing…':'📥 Import CSV'}
                  <input type="file" accept=".csv" style={{display:'none'}} disabled={spinImportBusy}
                    onChange={async e=>{const f=e.target.files?.[0];if(!f)return;await handleSpinImportFile(f);e.target.value='';}} />
                </label>
                <button style={{...btn('#6b7280')}} onClick={handleSpinExportCsv}>📤 Export CSV</button>
                <button style={{...btn('#8b5cf6')}} onClick={downloadSpinCsvTemplate}>📋 Template</button>
              </div>

              {/* Rewards table */}
              {spinRewards.length === 0
                ? <p style={{color:'#888',fontSize:'0.85rem'}}>No rewards configured yet. Use the form below or Import CSV.</p>
                : (()=>{
                    const totalW = spinRewards.filter(r=>r.active).reduce((s,r)=>s+r.weight,0);
                    return (
                      <div style={{overflowX:'auto',marginBottom:'1rem'}}>
                        <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.8rem',minWidth:680}}>
                          <thead>
                            <tr style={{background:'#fff5ed'}}>
                              {['Label','Type','Value','Cap','Chance','Wt','Today','Min₹','Exp','Active','',''].map((h,i)=>(
                                <th key={i} style={{padding:'0.35rem 0.5rem',textAlign:'left',fontWeight:700,fontSize:'0.68rem',color:'#6B5246',textTransform:'uppercase',whiteSpace:'nowrap'}}>{h}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {spinRewards.map(r=>{
                              const pct = r.active && totalW>0 ? ((r.weight/totalW)*100).toFixed(1)+'%' : '—';
                              const isHighVal = r.reward_type==='percent' && r.reward_value>=30 && !r.max_discount;
                              const isToggling = spinTogglingIds.has(r.id);
                              const atLimit = r.daily_win_limit!=null && (r.daily_usage??0)>=r.daily_win_limit;
                              const todayStr = r.daily_win_limit!=null
                                ? `${r.daily_usage??0}/${r.daily_win_limit}`
                                : `${r.daily_usage??0}/∞`;
                              return (
                                <tr key={r.id} style={{borderBottom:'1px solid #f5f0e8',opacity:r.active?1:0.55,background:editingRewardId===r.id?'#fffbf0':'transparent'}}>
                                  <td style={{padding:'0.35rem 0.5rem',fontWeight:600,maxWidth:140}}>
                                    {r.label}
                                    {isHighVal&&<span title="High-value percent with no max cap" style={{marginLeft:4,cursor:'help'}}>⚠️</span>}
                                  </td>
                                  <td style={{padding:'0.35rem 0.5rem',color:'#6b7280',fontSize:'0.75rem'}}>{r.reward_type}</td>
                                  <td style={{padding:'0.35rem 0.5rem',whiteSpace:'nowrap'}}>{r.reward_type==='percent'?`${r.reward_value}%`:r.reward_type==='no_reward'?'—':`₹${r.reward_value}`}</td>
                                  <td style={{padding:'0.35rem 0.5rem',color:'#6b7280',fontSize:'0.75rem',whiteSpace:'nowrap'}}>{r.reward_type==='percent'&&r.max_discount?`₹${r.max_discount}`:'—'}</td>
                                  <td style={{padding:'0.35rem 0.5rem',fontWeight:700,color:'#7c3aed'}}>{pct}</td>
                                  <td style={{padding:'0.35rem 0.5rem'}}>{r.weight}</td>
                                  <td style={{padding:'0.35rem 0.5rem',fontSize:'0.75rem',fontWeight:600,color:atLimit?'#ef4444':'#374151',whiteSpace:'nowrap'}}>{todayStr}</td>
                                  <td style={{padding:'0.35rem 0.5rem',whiteSpace:'nowrap'}}>₹{r.min_next_order}</td>
                                  <td style={{padding:'0.35rem 0.5rem',whiteSpace:'nowrap'}}>{r.expires_days}d</td>
                                  <td style={{padding:'0.35rem 0.5rem'}}>
                                    <button
                                      disabled={isToggling}
                                      onClick={()=>handleSpinToggleActive(r)}
                                      style={{...btn(r.active?'#16a34a':'#9ca3af'),padding:'0.18rem 0.45rem',fontSize:'0.7rem',opacity:isToggling?0.55:1,cursor:isToggling?'wait':'pointer',minWidth:38}}
                                      title={r.active?'Deactivate':'Activate'}
                                    >{isToggling?'…':r.active?'ON':'OFF'}</button>
                                  </td>
                                  <td style={{padding:'0.35rem 0.5rem'}}>
                                    <button
                                      style={{...btn('#f59e0b','#1a0800'),padding:'0.18rem 0.45rem',fontSize:'0.7rem'}}
                                      onClick={()=>handleSpinEditStart(r)} title="Edit"
                                    >✏️</button>
                                  </td>
                                  <td style={{padding:'0.35rem 0.5rem'}}>
                                    <button
                                      style={{...btn('#ef4444'),padding:'0.18rem 0.45rem',fontSize:'0.7rem'}}
                                      onClick={()=>handleSpinDeleteOrArchive(r)}
                                      title={(r.daily_usage??0)>0?'Archive (has history)':'Delete'}
                                    >{(r.daily_usage??0)>0?'📦':'🗑'}</button>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    );
                  })()
              }

              {/* ── Add / Edit reward form ─────────────────────────────── */}
              <div id="spin-reward-form" style={{background:'#f8fafc',borderRadius:10,padding:'1rem',marginTop:'0.5rem',border:editingRewardId?'2px solid #E65C00':'2px solid transparent',transition:'border-color 0.2s'}}>
                <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'0.6rem'}}>
                  <div style={{fontWeight:700,fontSize:'0.85rem',color:'#1A0800'}}>
                    {editingRewardId ? '✏️ Edit Reward' : '+ Add New Reward'}
                  </div>
                  {editingRewardId && (
                    <button style={{...btn('#9ca3af'),padding:'0.2rem 0.6rem',fontSize:'0.75rem'}} onClick={()=>{setEditingRewardId(null);setSpinRewardForm(SPIN_FORM_RESET);}}>✕ Cancel</button>
                  )}
                </div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'0.5rem',marginBottom:'0.5rem'}}>
                  <div>
                    <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.2rem'}}>Label *</label>
                    <input value={spinRewardForm.label} onChange={e=>setSpinRewardForm(f=>({...f,label:e.target.value}))} placeholder="e.g. 10% Off" style={{...inp}} />
                  </div>
                  <div>
                    <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.2rem'}}>Type</label>
                    <select value={spinRewardForm.reward_type} onChange={e=>setSpinRewardForm(f=>({...f,reward_type:e.target.value}))} style={{...inp}}>
                      <option value="percent">Percent (%)</option>
                      <option value="fixed">Fixed (₹)</option>
                      <option value="free_item">Free Item</option>
                      <option value="no_reward">No Reward</option>
                    </select>
                  </div>
                  <div>
                    <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.2rem'}}>
                      {spinRewardForm.reward_type==='percent'?'Discount (%)':spinRewardForm.reward_type==='fixed'?'Amount (₹)':'Value'}
                    </label>
                    <input type="number" value={spinRewardForm.reward_value} onChange={e=>setSpinRewardForm(f=>({...f,reward_value:Number(e.target.value)}))} style={{...inp}} />
                  </div>
                  <div>
                    <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.2rem'}}>Weight (higher = more likely)</label>
                    <input type="number" value={spinRewardForm.weight} min={0} onChange={e=>setSpinRewardForm(f=>({...f,weight:Number(e.target.value)}))} style={{...inp}} />
                  </div>
                  {spinRewardForm.reward_type==='percent' && (
                    <div>
                      <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.2rem'}}>
                        Max Discount (₹) <span style={{color:'#ef4444',fontWeight:800}}>*</span> <span style={{color:'#9ca3af',fontWeight:400}}>required</span>
                      </label>
                      <input
                        type="number" min={1}
                        placeholder="e.g. 100"
                        value={spinRewardForm.max_discount ?? ''}
                        onChange={e=>setSpinRewardForm(f=>({...f,max_discount:e.target.value===''?null:Number(e.target.value)}))}
                        style={{...inp,borderColor:!spinRewardForm.max_discount?'#ef4444':''}}
                      />
                    </div>
                  )}
                  <div>
                    <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.2rem'}}>Daily Win Limit <span style={{color:'#9ca3af',fontWeight:400}}>blank = unlimited</span></label>
                    <input
                      type="number" min={1}
                      placeholder="blank = unlimited"
                      value={spinRewardForm.daily_win_limit ?? ''}
                      onChange={e=>setSpinRewardForm(f=>({...f,daily_win_limit:e.target.value===''?null:Number(e.target.value)}))}
                      style={{...inp}}
                    />
                  </div>
                  <div>
                    <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.2rem'}}>Min Next Order (₹)</label>
                    <input type="number" value={spinRewardForm.min_next_order} onChange={e=>setSpinRewardForm(f=>({...f,min_next_order:Number(e.target.value)}))} style={{...inp}} />
                  </div>
                  <div>
                    <label style={{fontSize:'0.72rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.2rem'}}>Expires (days)</label>
                    <input type="number" value={spinRewardForm.expires_days} min={1} onChange={e=>setSpinRewardForm(f=>({...f,expires_days:Number(e.target.value)}))} style={{...inp}} />
                  </div>
                </div>
                {/* Live preview */}
                <div style={{background:'#f0fdf4',border:'1px dashed #86efac',borderRadius:8,padding:'0.5rem 0.75rem',marginBottom:'0.5rem',fontSize:'0.79rem',color:'#166534'}}>
                  <strong>Preview:</strong>{' '}
                  <em>{spinRewardForm.label||'(no label)'}</em> —{' '}
                  {spinRewardForm.reward_type==='percent'
                    ? `${spinRewardForm.reward_value}% off${spinRewardForm.max_discount?` (max ₹${spinRewardForm.max_discount})`:''}${!spinRewardForm.max_discount?' ⚠️ uncapped':''}`
                    : spinRewardForm.reward_type==='fixed' ? `₹${spinRewardForm.reward_value} off`
                    : spinRewardForm.reward_type==='no_reward' ? 'No Reward (filler)'
                    : 'Free Item'}
                  {spinRewardForm.min_next_order>0 ? ` · min ₹${spinRewardForm.min_next_order}` : ''}
                  {' · '}weight {spinRewardForm.weight}
                  {spinRewardForm.daily_win_limit ? ` · max ${spinRewardForm.daily_win_limit}/day` : ' · unlimited/day'}
                </div>
                {/* Profitability warning */}
                {spinRewardForm.reward_type==='percent' && spinRewardForm.reward_value>=25 && !spinRewardForm.max_discount && (
                  <div style={{background:'#fef9c3',border:'1px solid #fcd34d',borderRadius:8,padding:'0.5rem 0.75rem',marginBottom:'0.5rem',fontSize:'0.78rem',color:'#92400e'}}>
                    ⚠️ <strong>{spinRewardForm.reward_value}% off</strong> with no cap could be very costly on large orders. Add a Maximum Discount above to protect margins.
                  </div>
                )}
                <button style={{...btn('#16a34a')}} onClick={handleSpinFormSave}>
                  {editingRewardId ? '💾 Save Changes' : '✅ Add Reward'}
                </button>
              </div>
            </div>

            {/* ── Import preview modal ────────────────────────────────── */}
            {spinImportPreview && (
              <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.55)',zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center',padding:'1rem'}}>
                <div style={{background:'white',borderRadius:14,padding:'1.5rem',maxWidth:760,width:'100%',maxHeight:'82vh',overflowY:'auto',boxShadow:'0 20px 60px rgba(0,0,0,0.3)'}}>
                  <h3 style={{margin:'0 0 0.75rem',fontWeight:800,color:'#1A0800',fontSize:'1.05rem'}}>📋 CSV Import Preview</h3>
                  <div style={{display:'flex',gap:'0.6rem',flexWrap:'wrap',marginBottom:'1rem',fontSize:'0.8rem'}}>
                    <span style={{background:'#dcfce7',color:'#166534',padding:'0.2rem 0.65rem',borderRadius:20,fontWeight:700}}>+{spinImportPreview.newCount} CREATE</span>
                    <span style={{background:'#dbeafe',color:'#1e40af',padding:'0.2rem 0.65rem',borderRadius:20,fontWeight:700}}>~{spinImportPreview.updateCount} UPDATE</span>
                    <span style={{background:'#f3f4f6',color:'#6b7280',padding:'0.2rem 0.65rem',borderRadius:20,fontWeight:700}}>{spinImportPreview.noChangeCount} NO CHANGE</span>
                    {spinImportPreview.errorCount>0 && <span style={{background:'#fee2e2',color:'#991b1b',padding:'0.2rem 0.65rem',borderRadius:20,fontWeight:700}}>⚠️ {spinImportPreview.errorCount} ERRORS</span>}
                  </div>
                  {spinImportPreview.errors.length>0 && (
                    <div style={{background:'#fee2e2',borderRadius:8,padding:'0.75rem',marginBottom:'0.75rem',fontSize:'0.78rem',color:'#991b1b'}}>
                      <strong>Fix these errors in your CSV and re-import:</strong>
                      <ul style={{margin:'0.3rem 0 0 1rem',padding:0}}>
                        {spinImportPreview.errors.map((e,i)=><li key={i}>{e}</li>)}
                      </ul>
                    </div>
                  )}
                  <div style={{overflowX:'auto'}}>
                    <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.75rem'}}>
                      <thead>
                        <tr style={{background:'#f3f4f6'}}>
                          {['Action','Label','Type','Value','Cap','Wt','Chance','Min₹','Exp','Active'].map(h=>(
                            <th key={h} style={{padding:'0.3rem 0.5rem',textAlign:'left',fontWeight:700,color:'#374151',whiteSpace:'nowrap'}}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {spinImportPreview.rows.map((row,i)=>{
                          const bgMap: Record<string,string> = {CREATE:'#f0fdf4',UPDATE:'#eff6ff','NO CHANGE':'#f9fafb',ERROR:'#fef2f2'};
                          const labelMap: Record<string,string> = {CREATE:'+ CREATE',UPDATE:'~ UPDATE','NO CHANGE':'= SAME',ERROR:'✗ ERROR'};
                          return (
                            <tr key={i} style={{borderBottom:'1px solid #f3f4f6',background:bgMap[row.action]??'white'}}>
                              <td style={{padding:'0.3rem 0.5rem',fontWeight:700,fontSize:'0.7rem',whiteSpace:'nowrap'}}>{labelMap[row.action]??row.action}</td>
                              <td style={{padding:'0.3rem 0.5rem'}}>
                                {row.label}
                                {row.error && <span style={{color:'#ef4444',display:'block',fontSize:'0.68rem'}}>{row.error}</span>}
                              </td>
                              <td style={{padding:'0.3rem 0.5rem',whiteSpace:'nowrap'}}>{row.type}</td>
                              <td style={{padding:'0.3rem 0.5rem',whiteSpace:'nowrap'}}>{row.type==='percent'?`${row.value}%`:row.type==='no_reward'?'—':`₹${row.value}`}</td>
                              <td style={{padding:'0.3rem 0.5rem',whiteSpace:'nowrap'}}>{row.max_discount?`₹${row.max_discount}`:'—'}</td>
                              <td style={{padding:'0.3rem 0.5rem'}}>{row.weight}</td>
                              <td style={{padding:'0.3rem 0.5rem',color:'#7c3aed',fontWeight:700}}>{row.chance}</td>
                              <td style={{padding:'0.3rem 0.5rem',whiteSpace:'nowrap'}}>₹{row.min_next_order}</td>
                              <td style={{padding:'0.3rem 0.5rem',whiteSpace:'nowrap'}}>{row.expires_days}d</td>
                              <td style={{padding:'0.3rem 0.5rem'}}>{row.active?'✅':'⭕'}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                  <div style={{display:'flex',gap:'0.5rem',marginTop:'1.1rem',justifyContent:'flex-end'}}>
                    <button style={{...btn('#9ca3af')}} onClick={()=>{setSpinImportPreview(null);setSpinImportRows([]);}}>Cancel</button>
                    <button
                      style={{...btn('#16a34a'),opacity:(spinImportPreview.errorCount>0||spinImportBusy)?0.45:1}}
                      disabled={spinImportPreview.errorCount>0||spinImportBusy}
                      onClick={handleSpinImportConfirm}
                    >{spinImportBusy?'⏳ Importing…':'✅ Confirm Import'}</button>
                  </div>
                </div>
              </div>
            )}
          </>}
        </>}

        {/* ═══════════ REWARDS AUDIT ═══════════ */}
        {section==='rewards_audit' && <>
          <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,fontSize:'1.15rem',marginBottom:'1rem',color:'#1A0800'}}>🎟 Rewards Audit</div>
          <button
            style={{...btn(),marginBottom:'1rem'}}
            onClick={async()=>{
              const r = await fetch('/api/admin/rewards-audit');
              const d = await r.json() as AuditRow[];
              setAuditRows(d);
              setAuditLoaded(true);
            }}
          >{auditLoaded ? '🔄 Refresh' : '📥 Load Audit'}</button>
          {auditLoaded && (
            <div style={{overflowX:'auto'}}>
              {auditRows.length === 0
                ? <p style={{color:'#888',fontSize:'0.85rem'}}>No coupons issued yet.</p>
                : <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.78rem'}}>
                  <thead><tr style={{background:'#fff5ed'}}>
                    {['Issued','Code','Label','Type','Value','Status','Email','Source Order','Redeemed At'].map(h=><th key={h} style={{padding:'0.4rem 0.6rem',textAlign:'left',fontWeight:700,fontSize:'0.68rem',color:'#6B5246',textTransform:'uppercase',whiteSpace:'nowrap' as const}}>{h}</th>)}
                  </tr></thead>
                  <tbody>
                    {auditRows.map(a=>(
                      <tr key={a.id} style={{borderBottom:'1px solid #f5f0e8',background:a.status==='redeemed'?'#f0fdf4':a.status==='expired'?'#fef2f2':'white'}}>
                        <td style={{padding:'0.4rem 0.6rem',whiteSpace:'nowrap' as const}}>{fmtDateTimeShort(a.issued_at)}</td>
                        <td style={{padding:'0.4rem 0.6rem',fontFamily:'monospace',fontWeight:700,color:'#7c3aed'}}>{a.coupon_code}</td>
                        <td style={{padding:'0.4rem 0.6rem'}}>{a.label}</td>
                        <td style={{padding:'0.4rem 0.6rem'}}>{a.reward_type}</td>
                        <td style={{padding:'0.4rem 0.6rem'}}>{a.reward_type==='percent'?`${a.reward_value}%`:`₹${a.reward_value}`}</td>
                        <td style={{padding:'0.4rem 0.6rem'}}>
                          <span style={{padding:'0.2rem 0.5rem',borderRadius:20,fontSize:'0.7rem',fontWeight:700,background:a.status==='redeemed'?'#dcfce7':a.status==='active'?'#dbeafe':a.status==='reserved'?'#fef3c7':'#fee2e2',color:a.status==='redeemed'?'#166534':a.status==='active'?'#1d4ed8':a.status==='reserved'?'#92400e':'#991b1b'}}>{a.status}</span>
                        </td>
                        <td style={{padding:'0.4rem 0.6rem',fontSize:'0.72rem'}}>{a.customer_email}</td>
                        <td style={{padding:'0.4rem 0.6rem'}}>#{(a.source_order as {order_number:number}|null)?.order_number ?? '—'}</td>
                        <td style={{padding:'0.4rem 0.6rem',whiteSpace:'nowrap' as const}}>{a.redeemed_at ? fmtDateTimeShort(a.redeemed_at) : '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              }
            </div>
          )}
        </>}

        {/* ═══════════ KITCHEN ORDER HANDLING ═══════════ */}
        {section==='kitchen' && (
          <div style={{maxWidth:520}}>
            <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,fontSize:'1.15rem',marginBottom:'0.4rem',color:'#1A0800'}}>🔥 Kitchen Order Handling</div>
            <p style={{fontSize:'0.82rem',color:'#555',marginBottom:'1.25rem'}}>
              Controls how each confirmed order reaches the kitchen. This setting is loaded from the database every time the admin panel opens.
            </p>

            {/* Current value chip */}
            <div style={{marginBottom:'1rem',display:'flex',alignItems:'center',gap:'0.5rem'}}>
              <span style={{fontSize:'0.75rem',color:'#888',fontWeight:600}}>Current setting in DB:</span>
              <span style={{
                padding:'0.2rem 0.75rem',borderRadius:20,fontWeight:800,fontSize:'0.78rem',
                background: kitchenMode==='ask'?'#f0fdf4':kitchenMode==='printer'?'#fef9c3':'#eff6ff',
                color: kitchenMode==='ask'?'#15803d':kitchenMode==='printer'?'#854d0e':'#1d4ed8',
                border: '1px solid',
                borderColor: kitchenMode==='ask'?'#86efac':kitchenMode==='printer'?'#fde047':'#bfdbfe',
              }}>
                {kitchenMode==='ask' ? '🤝 Ask Waiter Each Time' : kitchenMode==='printer' ? '🖨️ Printer Only' : '🖥️ Kitchen Display Only'}
              </span>
            </div>

            <div style={{background:'white',borderRadius:14,padding:'1.25rem',boxShadow:'0 2px 12px rgba(0,0,0,0.07)',border:'1px solid #f0e0d0',marginBottom:'1rem'}}>
              <label style={{fontWeight:700,fontSize:'0.82rem',color:'#555',display:'block',marginBottom:'0.5rem'}}>Kitchen Order Handling Mode</label>
              <select
                value={kitchenMode}
                onChange={e=>setKitchenMode(e.target.value as 'ask'|'printer'|'kitchen_display')}
                style={{display:'block',width:'100%',maxWidth:380,padding:'0.6rem 0.75rem',border:'2px solid #e5e7eb',borderRadius:10,fontFamily:'Poppins,sans-serif',fontSize:'0.88rem',marginBottom:'1rem',outline:'none'}}
              >
                <option value="ask">Ask Waiter Each Time — show BOTH Print KOT &amp; Send to Kitchen buttons</option>
                <option value="printer">Printer Only — waiter always prints KOT (no kitchen display button)</option>
                <option value="kitchen_display">Kitchen Display Only — always sends to kitchen display (no print button)</option>
              </select>

              {/* Explanations per mode */}
              {kitchenMode==='ask' && (
                <div style={{background:'#f0fdf4',border:'1px solid #86efac',borderRadius:10,padding:'0.75rem',fontSize:'0.8rem',color:'#166534',marginBottom:'0.75rem'}}>
                  <strong>🤝 Ask Waiter Each Time:</strong> For every new order, the waiter sees two buttons:<br/>
                  <span style={{marginLeft:'0.75rem',display:'inline-block',marginTop:'0.35rem'}}>🖨️ <strong>CONFIRM &amp; PRINT KOT</strong> — routes order to kitchen printer</span><br/>
                  <span style={{marginLeft:'0.75rem',display:'inline-block'}}>🖥️ <strong>CONFIRM &amp; SEND TO KITCHEN</strong> — routes to Kitchen Display screen</span><br/>
                  The waiter chooses the route per order. Exactly one route is used; the other is never triggered.
                </div>
              )}
              {kitchenMode==='printer' && (
                <div style={{background:'#fef9c3',border:'1px solid #fde047',borderRadius:10,padding:'0.75rem',fontSize:'0.8rem',color:'#854d0e',marginBottom:'0.75rem'}}>
                  <strong>🖨️ Printer Only:</strong> Only <strong>CONFIRM &amp; PRINT KOT</strong> is shown. Kitchen Display will NOT show these orders as actionable. Print failure fallback (Send to Kitchen Display) is still available.
                </div>
              )}
              {kitchenMode==='kitchen_display' && (
                <div style={{background:'#eff6ff',border:'1px solid #bfdbfe',borderRadius:10,padding:'0.75rem',fontSize:'0.8rem',color:'#1d4ed8',marginBottom:'0.75rem'}}>
                  <strong>🖥️ Kitchen Display Only:</strong> Only <strong>CONFIRM &amp; SEND TO KITCHEN</strong> is shown. No KOT is printed automatically.
                </div>
              )}

              <button
                onClick={async()=>{
                  setKitchenModeMsg('⏳ Saving…');
                  try {
                    const r = await fetch('/api/admin/restaurant-config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kitchen_mode:kitchenMode})});
                    const d = await r.json() as {ok?:boolean;error?:string};
                    setKitchenModeMsg(d.ok ? `✅ Saved — Kitchen mode is now "${kitchenMode==='ask'?'Ask Waiter Each Time':kitchenMode==='printer'?'Printer Only':'Kitchen Display Only'}"` : `❌ ${d.error ?? 'Error'}`);
                  } catch { setKitchenModeMsg('❌ Network error'); }
                  setTimeout(()=>setKitchenModeMsg(''),4000);
                }}
                style={{background:'#1A0800',color:'white',border:'none',borderRadius:10,padding:'0.7rem 1.5rem',fontWeight:800,cursor:'pointer',fontFamily:'Poppins,sans-serif',fontSize:'0.88rem'}}
              >
                💾 Save Kitchen Mode
              </button>
              {kitchenModeMsg && (
                <div style={{marginTop:'0.6rem',fontSize:'0.82rem',fontWeight:700,color:kitchenModeMsg.includes('✅')?'#16a34a':'#ef4444'}}>
                  {kitchenModeMsg}
                </div>
              )}
            </div>

            <div style={{background:'#f9fafb',borderRadius:12,padding:'1rem',fontSize:'0.78rem',color:'#666',lineHeight:1.6}}>
              <strong style={{color:'#1A0800'}}>How it works:</strong><br/>
              • <strong>Confirm &amp; Print KOT</strong> sets <code>kitchen_route = printer</code>. The Kitchen Display screen automatically hides printer-routed orders.<br/>
              • <strong>Confirm &amp; Send to Kitchen</strong> sets <code>kitchen_route = kitchen_display</code>. The order appears on the Kitchen Display and triggers beep/TTS.<br/>
              • These are mutually exclusive: pressing one button never triggers the other route.<br/>
              • The waiter page refreshes this setting every 5 seconds, so changes take effect immediately without a page reload.
            </div>
          </div>
        )}

      </div>{/* /container */}

      {/* ═══════ ORDER DETAIL MODAL ═══════ */}
      {selOrder && (
        <div className="modal-overlay show" onClick={()=>setSelOrder(null)}>
          <div onClick={e=>e.stopPropagation()} style={{background:'white',borderRadius:16,width:'100%',maxWidth:'min(95vw,600px)',maxHeight:'90dvh',overflow:'auto',boxShadow:'0 20px 60px rgba(0,0,0,0.3)'}}>
            <div style={{background:'linear-gradient(135deg,#1A0800,#E65C00)',color:'white',padding:'1.2rem 1.7rem',display:'flex',justifyContent:'space-between',alignItems:'flex-start',position:'sticky',top:0,zIndex:2,borderRadius:'16px 16px 0 0'}}>
              <div>
                <div style={{fontSize:'0.68rem',opacity:0.7,textTransform:'uppercase',letterSpacing:'0.1em'}}>Order Details</div>
                <div style={{fontSize:'1.05rem',fontWeight:900,fontFamily:"'Playfair Display',serif"}}>{selOrder.id}</div>
                <div style={{fontSize:'0.75rem',opacity:0.8}}>{fmtDateTime(selOrder.timestamp)}</div>
              </div>
              <div style={{display:'flex',gap:'0.5rem',alignItems:'center'}}>
                <span style={{fontSize:'0.7rem',fontWeight:700,padding:'0.18rem 0.55rem',borderRadius:10,background:(STATUS_COLOR[selOrder.status]||'#888')+'44',color:'white',textTransform:'capitalize'}}>{selOrder.status}</span>
                <button onClick={()=>setSelOrder(null)} style={{background:'none',border:'none',color:'white',fontSize:'1.7rem',cursor:'pointer',lineHeight:1}}>×</button>
              </div>
            </div>
            <div style={{padding:'1rem 1.7rem',background:'#FFFAF5',borderBottom:'1px solid #f0e4d7',display:'grid',gridTemplateColumns:'1fr 1fr',gap:'0.45rem 1.5rem'}}>
              {([
                ['Customer',   selOrder.customerName],
                ['Phone',      selOrder.phone || '—'],
                ['Channel',    selOrder.source === 'online' ? '📦 Online Order' : '🍽️ In-Store'],
                ['Type',       selOrder.type === 'dine-in' ? '🍽️ Dine-In' : selOrder.type === 'delivery' ? '🚗 Delivery' : '🏪 Pickup'],
                ['Location',   selOrder.type === 'dine-in' ? `Table ${selOrder.tableId}` : selOrder.deliveryAddress ? selOrder.deliveryAddress : 'Counter Pickup'],
                ['Payment',    selOrder.payment || 'N/A'],
              ] as [string,string][]).map(([l,v])=>(
                <div key={l}><div style={{fontSize:'0.65rem',color:'#999',fontWeight:700,textTransform:'uppercase',letterSpacing:'0.05em'}}>{l}</div><div style={{fontSize:'0.86rem',fontWeight:700,color:'#1A0800'}}>{v}</div></div>
              ))}
              {selOrder.cancelReason && <div style={{gridColumn:'1/-1'}}><div style={{fontSize:'0.65rem',color:'#ef4444',fontWeight:700,textTransform:'uppercase'}}>Cancel Reason</div><div style={{fontSize:'0.86rem',color:'#ef4444',fontWeight:600}}>{selOrder.cancelReason}</div></div>}
              {selOrder.discountReason && <div style={{gridColumn:'1/-1'}}><div style={{fontSize:'0.65rem',color:'#8b5cf6',fontWeight:700,textTransform:'uppercase'}}>Discount Reason</div><div style={{fontSize:'0.86rem',color:'#8b5cf6',fontWeight:600}}>{selOrder.discountReason}</div></div>}
            </div>
            <div style={{padding:'1rem 1.7rem'}}>
              <div style={{fontSize:'0.75rem',fontWeight:700,color:'#6B5246',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:'0.5rem'}}>Items Ordered</div>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:'0.83rem'}}>
                <thead><tr style={{background:'#f5f0e8'}}>{['#','Item','Qty','Unit','Total'].map(h=><th key={h} style={{padding:'0.48rem 0.65rem',textAlign:'left',fontSize:'0.7rem',fontWeight:700,color:'#6B5246',textTransform:'uppercase'}}>{h}</th>)}</tr></thead>
                <tbody>
                  {(selOrder.items||[]).map((item,i)=>(
                    <tr key={i} style={{borderBottom:'1px solid #f5f0e8'}}>
                      <td style={{padding:'0.52rem 0.65rem',color:'#bbb'}}>{i+1}</td>
                      <td style={{padding:'0.52rem 0.65rem',fontWeight:600}}>{item.name}</td>
                      <td style={{padding:'0.52rem 0.65rem',textAlign:'center',fontWeight:700}}>{item.qty}</td>
                      <td style={{padding:'0.52rem 0.65rem'}}>₹{item.price}</td>
                      <td style={{padding:'0.52rem 0.65rem',fontWeight:700}}>₹{item.subtotal||(item.price*item.qty)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div style={{textAlign:'right',marginTop:'0.65rem'}}>
                <div style={{fontSize:'0.83rem',color:'#555'}}>Subtotal: <strong>₹{selOrder.subtotal||selOrder.total}</strong></div>
                {(selOrder.discount||0)>0 && <div style={{fontSize:'0.83rem',color:'#16a34a'}}>Discount: <strong>-₹{selOrder.discount}</strong></div>}
                <div style={{fontSize:'0.98rem',fontWeight:900,color:'#E65C00',borderTop:'2px solid #f0f0f0',paddingTop:'0.4rem',marginTop:'0.3rem'}}>Total: ₹{selOrder.total}</div>
              </div>
            </div>
            {(selOrder.timeline?.length ?? 0) > 0 && (
              <div style={{padding:'0.75rem 1.7rem 1.4rem',borderTop:'1px solid #f0e4d7'}}>
                <div style={{fontSize:'0.75rem',fontWeight:700,color:'#6B5246',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:'0.6rem'}}>⏱ Order Timeline</div>
                {(selOrder.timeline || []).map((ev,i)=>(
                  <div key={i} style={{display:'flex',gap:'0.65rem',alignItems:'flex-start',marginBottom:'0.35rem'}}>
                    <div style={{width:9,height:9,borderRadius:'50%',background:'#E65C00',marginTop:3,flexShrink:0}}/>
                    <div>
                      <span style={{fontWeight:700,textTransform:'capitalize',color:'#333',fontSize:'0.8rem'}}>{ev.eventType?.replace(/_/g,' ')}</span>
                      {ev.by&&<span style={{color:'#888',fontSize:'0.73rem'}}> by {ev.by}</span>}
                      {ev.note&&<div style={{fontSize:'0.72rem',color:'#888',fontStyle:'italic'}}>{ev.note}</div>}
                      <div style={{fontSize:'0.7rem',color:'#bbb'}}>{ev.at ? fmtTime(ev.at) : ''}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ═══════ MENU ADD/EDIT MODAL ═══════ */}
      {menuModal.open && (
        <div className="modal-overlay show" onClick={()=>setMenuModal({open:false,item:emptyItem(),isEdit:false})}>
          <div onClick={e=>e.stopPropagation()} style={{background:'white',borderRadius:16,width:'100%',maxWidth:'min(95vw,510px)',maxHeight:'92dvh',overflow:'auto',boxShadow:'0 20px 60px rgba(0,0,0,0.3)'}}>
            <div style={{background:'linear-gradient(135deg,#1A0800,#E65C00)',color:'white',padding:'1.1rem 1.6rem',display:'flex',justifyContent:'space-between',alignItems:'center',borderRadius:'16px 16px 0 0',position:'sticky',top:0,zIndex:2}}>
              <span style={{fontFamily:"'Playfair Display',serif",fontWeight:900,fontSize:'1.05rem'}}>{menuModal.isEdit?'✏️ Edit Menu Item':'➕ Add New Item'}</span>
              <button onClick={()=>setMenuModal({open:false,item:emptyItem(),isEdit:false})} style={{background:'none',border:'none',color:'white',fontSize:'1.5rem',cursor:'pointer',lineHeight:1}}>×</button>
            </div>
            <div style={{padding:'1.4rem'}}>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'0.85rem',marginBottom:'0.85rem'}}>
                <div>
                  <label style={{fontSize:'0.76rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.28rem'}}>Category *</label>
                  <select value={menuModal.item.category||'Biryani'} onChange={e=>setMenuModal(m=>({...m,item:{...m.item,category:e.target.value}}))} style={{...inp}}>
                    {CATEGORIES.map(c=><option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{fontSize:'0.76rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.28rem'}}>Badge</label>
                  <select value={menuModal.item.badge||''} onChange={e=>setMenuModal(m=>({...m,item:{...m.item,badge:e.target.value}}))} style={{...inp}}>
                    <option value="">— None —</option>
                    {Object.entries(BADGE_LABEL).map(([k,v])=><option key={k} value={k}>{v}</option>)}
                  </select>
                </div>
              </div>
              <div style={{marginBottom:'0.85rem'}}>
                <label style={{fontSize:'0.76rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.28rem'}}>Item Name *</label>
                <input value={menuModal.item.name||''} onChange={e=>setMenuModal(m=>({...m,item:{...m.item,name:e.target.value}}))} placeholder="e.g. Hyderabadi Chicken Biryani" style={{...inp}} />
              </div>
              <div style={{marginBottom:'0.85rem'}}>
                <label style={{fontSize:'0.76rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.28rem'}}>Description</label>
                <textarea value={menuModal.item.desc||''} onChange={e=>setMenuModal(m=>({...m,item:{...m.item,desc:e.target.value}}))} placeholder="Short appetizing description…" rows={2} style={{...inp,resize:'vertical' as const}} />
              </div>
              <div style={{marginBottom:'0.85rem'}}>
                <label style={{fontSize:'0.76rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.28rem'}}>Pricing Variants * <span style={{fontWeight:400,color:'#999'}}>(e.g. Half / Full / 1 Piece)</span></label>
                {modalVariants.map((v,i)=>(
                  <div key={i} style={{display:'flex',gap:'0.4rem',marginBottom:'0.4rem',alignItems:'center'}}>
                    <input value={v.name} onChange={e=>updateVariantRow(i,'name',e.target.value)} placeholder="Name (e.g. Half)" style={{...inp,flex:2,padding:'0.45rem 0.6rem'}} />
                    <div style={{position:'relative',flex:1}}>
                      <span style={{position:'absolute',left:'0.5rem',top:'50%',transform:'translateY(-50%)',color:'#888',fontSize:'0.82rem'}}>₹</span>
                      <input type="number" value={v.price} onChange={e=>updateVariantRow(i,'price',e.target.value)} placeholder="0" min="1" style={{...inp,paddingLeft:'1.4rem',padding:'0.45rem 0.4rem 0.45rem 1.4rem'}} />
                    </div>
                    {modalVariants.length>1&&<button onClick={()=>removeVariantRow(i)} style={{background:'#fef2f2',border:'1px solid #fca5a5',color:'#ef4444',borderRadius:6,cursor:'pointer',padding:'0.35rem 0.5rem',fontSize:'0.85rem',flexShrink:0}}>🗑</button>}
                  </div>
                ))}
                <button onClick={addVariantRow} style={{width:'100%',background:'#f0fdf4',border:'1px dashed #16a34a',color:'#16a34a',borderRadius:8,cursor:'pointer',padding:'0.4rem',fontSize:'0.8rem',fontWeight:700,fontFamily:'Poppins,sans-serif',marginTop:'0.2rem'}}>＋ Add Variant</button>
              </div>
              <div style={{marginBottom:'1.1rem'}}>
                <label style={{fontSize:'0.76rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.28rem'}}>Image <span style={{fontWeight:400,color:'#999'}}>(paste URL or upload)</span></label>
                <div style={{display:'flex',gap:'0.4rem',alignItems:'center',marginBottom:'0.35rem'}}>
                  <input value={menuModal.item.img||''} onChange={e=>setMenuModal(m=>({...m,item:{...m.item,img:e.target.value}}))} placeholder="https://images.unsplash.com/…" style={{...inp,flex:1}} />
                  <label style={{...btn('#8b5cf6'),cursor:'pointer' as const,whiteSpace:'nowrap' as const,flexShrink:0,fontSize:'0.78rem',opacity:imgUploading?0.6:1,display:'inline-flex',alignItems:'center' as const}}>
                    {imgUploading?'⏳':'📤 Upload'}
                    <input type="file" accept="image/*" style={{display:'none'}} disabled={imgUploading} onChange={e=>{const f=e.target.files?.[0];if(f){void uploadMenuImage(f);e.target.value='';}}} />
                  </label>
                </div>
                {menuModal.item.img && (
                  <div style={{width:'100%',height:'130px',borderRadius:8,overflow:'hidden',background:'#f5f0e8'}}>
                    <img src={menuModal.item.img} alt="preview" style={{width:'100%',height:'100%',objectFit:'cover'}} onError={e=>{(e.target as HTMLImageElement).style.display='none';}} />
                  </div>
                )}
              </div>
              <div style={{display:'flex',gap:'0.65rem'}}>
                <button onClick={()=>setMenuModal({open:false,item:emptyItem(),isEdit:false})} style={{...btn('#e5e7eb','#555'),flex:1}}>Cancel</button>
                <button onClick={saveItem} style={{...btn(),flex:2}}>{menuModal.isEdit?'💾 Save Changes':'✅ Add to Menu'}</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ═══════ CANCEL MODAL ═══════ */}
      {cancelModal.open && (
        <div className="modal-overlay show" onClick={()=>setCancelModal({open:false,orderId:''})}>
          <div onClick={e=>e.stopPropagation()} style={{background:'white',borderRadius:16,width:'100%',maxWidth:'min(95vw,390px)',padding:'1.75rem',boxShadow:'0 20px 60px rgba(0,0,0,0.3)'}}>
            <h3 style={{fontFamily:"'Playfair Display',serif",color:'#ef4444',marginBottom:'0.4rem',fontSize:'1.1rem'}}>❌ Cancel Order</h3>
            <p style={{fontSize:'0.82rem',color:'#666',marginBottom:'0.9rem'}}>Cannot be undone. Order stays in the Cancellation Log.</p>
            <label style={{fontSize:'0.75rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.28rem'}}>Reason *</label>
            <textarea value={cancelReason} onChange={e=>setCancelReason(e.target.value)} placeholder="e.g. Customer request, wrong order…" rows={3} style={{...inp,marginBottom:'0.9rem',resize:'none' as const}} />
            <div style={{display:'flex',gap:'0.65rem'}}>
              <button onClick={()=>setCancelModal({open:false,orderId:''})} style={{...btn('#e5e7eb','#555'),flex:1}}>Back</button>
              <button onClick={doCancel} style={{...btn('#ef4444'),flex:2}}>Confirm Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════ DISCOUNT MODAL ═══════ */}
      {discountModal.open && (
        <div className="modal-overlay show" onClick={()=>setDiscountModal({open:false,orderId:''})}>
          <div onClick={e=>e.stopPropagation()} style={{background:'white',borderRadius:16,width:'100%',maxWidth:'min(95vw,390px)',padding:'1.75rem',boxShadow:'0 20px 60px rgba(0,0,0,0.3)'}}>
            <h3 style={{fontFamily:"'Playfair Display',serif",color:'#8b5cf6',marginBottom:'0.4rem',fontSize:'1.1rem'}}>🏷️ Apply Discount</h3>
            <p style={{fontSize:'0.82rem',color:'#666',marginBottom:'0.9rem'}}>Owner PIN required. Every discount is logged permanently.</p>
            <label style={{fontSize:'0.75rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.28rem'}}>Discount Amount (₹)</label>
            <input type="number" value={discAmt} onChange={e=>setDiscAmt(e.target.value)} placeholder="e.g. 50" style={{...inp,marginBottom:'0.75rem'}} />
            <label style={{fontSize:'0.75rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.28rem'}}>Reason</label>
            <input value={discNote} onChange={e=>setDiscNote(e.target.value)} placeholder="e.g. Loyalty customer, complaint…" style={{...inp,marginBottom:'0.75rem'}} />
            <label style={{fontSize:'0.75rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.28rem'}}>Owner PIN</label>
            <input type="password" value={pinInput} onChange={e=>setPinInput(e.target.value)} placeholder="••••" maxLength={4} style={{...inp,letterSpacing:'0.35em',textAlign:'center' as const,marginBottom:'0.25rem'}} />
            {pinMsg && <div style={{fontSize:'0.76rem',color:'#ef4444',marginBottom:'0.5rem'}}>{pinMsg}</div>}
            <div style={{display:'flex',gap:'0.65rem',marginTop:'0.75rem'}}>
              <button onClick={()=>setDiscountModal({open:false,orderId:''})} style={{...btn('#e5e7eb','#555'),flex:1}}>Cancel</button>
              <button onClick={doDiscount} style={{...btn('#8b5cf6'),flex:2}}>Apply Discount</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════ PIN MANAGER ═══════ */}
      {showPinMgr && (
        <div className="modal-overlay show" onClick={()=>{setShowPinMgr(false);setNewPin('');setNewPinMsg('');setAdminPinOld('');}}>
          <div onClick={e=>e.stopPropagation()} style={{background:'white',borderRadius:16,width:'100%',maxWidth:'min(95vw,350px)',padding:'1.75rem',boxShadow:'0 20px 60px rgba(0,0,0,0.3)'}}>
            <h3 style={{fontFamily:"'Playfair Display',serif",marginBottom:'0.3rem',fontSize:'1.1rem'}}>🔑 Change Owner PIN</h3>
            <p style={{fontSize:'0.8rem',color:'#666',marginBottom:'0.9rem'}}>Used to authorise discounts. Enter your current PIN to change it.</p>
            <label style={{fontSize:'0.75rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.28rem'}}>Current PIN</label>
            <input type="password" inputMode="numeric" value={adminPinOld} onChange={e=>setAdminPinOld(e.target.value.replace(/\D/g,''))} placeholder="Current PIN" maxLength={8} style={{...inp,letterSpacing:'0.35em',textAlign:'center' as const,marginBottom:'0.6rem'}} />
            <label style={{fontSize:'0.75rem',fontWeight:700,color:'#555',display:'block',marginBottom:'0.28rem'}}>New 4-digit PIN</label>
            <input type="password" inputMode="numeric" value={newPin} onChange={e=>setNewPin(e.target.value.replace(/\D/g,''))} placeholder="New PIN" maxLength={8} style={{...inp,letterSpacing:'0.35em',textAlign:'center' as const,marginBottom:'0.25rem'}} />
            {newPinMsg && <div style={{fontSize:'0.76rem',color:newPinMsg.includes('✓')||newPinMsg.includes('✅')?'#16a34a':'#ef4444',marginBottom:'0.5rem'}}>{newPinMsg}</div>}
            <button onClick={async ()=>{
              if (!adminPinOld) { setNewPinMsg('❌ Enter your current PIN'); return; }
              if (newPin.length < 4) { setNewPinMsg('❌ New PIN must be at least 4 digits'); return; }
              setNewPinMsg('⏳ Updating…');
              try {
                const res = await fetch('/api/auth/change-pin', {
                  method: 'POST', headers: {'Content-Type':'application/json'},
                  body: JSON.stringify({ currentPin: adminPinOld, newPin }),
                });
                const result = await res.json() as { ok: boolean; error?: string };
                if (!result.ok) { setNewPinMsg(`❌ ${result.error ?? 'Failed'}`); return; }
                setNewPinMsg('✅ PIN updated!');
                setTimeout(()=>{ setShowPinMgr(false); setNewPin(''); setNewPinMsg(''); setAdminPinOld(''); }, 1500);
              } catch { setNewPinMsg('❌ Server error'); }
            }} style={{...btn(),width:'100%',marginTop:'0.5rem'}}>Update PIN</button>
          </div>
        </div>
      )}

    </div>
  );
}
